"""Build versioned, reproducible publication and source kits; verify QA input hashes."""
import hashlib,json,zipfile
from pathlib import Path
import build
ROOT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def package():
 release=build.metadata();v=release['version'];qa=json.loads((ROOT/'qa_release.json').read_text())
 assert qa['app_version']==v
 for path,digest in qa['source_sha256'].items():assert sha((ROOT/path).read_bytes())==digest,path+' changed after QA'
 web=build.build_web();offline=build.build();web['version.json']=(json.dumps({**release,'index_sha256':sha(web['index.html']),'offline_sha256':sha(offline),'core_assets_version':v},ensure_ascii=False,indent=2)+'\n').encode()
 web[f'RELEASE-{v}.md']=(ROOT/'release_docs'/f'RELEASE-{v}.md').read_bytes()
 pub=ROOT.parent/'publish';pub.mkdir(exist_ok=True)
 for name,body in web.items():path=pub/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(body)
 files=list(dict.fromkeys(build.JS+build.CSS+['build.py','package_release.py','shell.html','data.json','release.json','qa_release.json','campaign-harness.cjs','qa_play120.cjs','qa_render120.cjs']))
 files += [p.name for p in ROOT.glob('verify_*.cjs')]
 files += [str(p.relative_to(ROOT)) for p in (ROOT/'release_docs').glob('*') if p.is_file()]
 files += ['assets/'+p for p in ['citadel-victory-v1.2.0.webp','og-atlas-v1.1.3.png','atlas-icon.svg','atlas-metrics-v0.1.0.css','atlas-metrics-v0.1.0.js','atlas-integration-v1.1.4.js']]
 files += ['qa120/campaign-runs.json','qa120/render_gl.py','qa120/finale.txt','qa120/campaign.txt','qa120/geography.txt','qa120/mobile.txt','qa_web.json','qa_comfort.json','test-support/tournament-rules.mjs','qa130-calm.json','qa130-normal.json','qa132-navigation.json','qa132-orbits.json','qa_mobile.json']
 kit=ROOT.parent/f'CMPON_Atlas_v{v}_source.zip'
 from datetime import date
 d=date.fromisoformat(release['released_on'])
 with zipfile.ZipFile(kit,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name in sorted(set(files)):
   info=zipfile.ZipInfo('source/'+name,(d.year,d.month,d.day,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,(ROOT/name).read_bytes())
 (pub/'assets'/kit.name).write_bytes(kit.read_bytes())
 off=ROOT.parent/f'CMPON_Atlas_v{v}_offline.html';off.write_bytes(offline)
 checks={str(p.relative_to(pub)):sha(p.read_bytes()) for p in pub.rglob('*') if p.is_file()}
 (ROOT.parent/'publication-manifest.json').write_text(json.dumps(checks,indent=2)+'\n')
 print(json.dumps({'version':v,'publish':str(pub),'source_kit':str(kit),'offline':str(off),'web_bytes':len(web['index.html']),'script_bytes':len(web['assets/atlas-v'+v+'.js']),'archive_bytes':kit.stat().st_size},ensure_ascii=False,indent=2))
if __name__=='__main__':package()
