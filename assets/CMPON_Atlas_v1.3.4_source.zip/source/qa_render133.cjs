// Render production scene geometry/shaders and HUD without browser automation.
const h=require('./campaign-harness.cjs'),{run,plain,fs,root,createCanvas,context,node}=h;
fs.mkdirSync(root+'/qa133',{recursive:true});fs.mkdirSync(root+'/qa120',{recursive:true});
run(`ARCADE.sound=false;ARCADE.fx=true;globalThis.e=new RequirementArcade(417147);e.start(true);e.beginFinale();e.beginMRG();ARCADE.engine=e;ARCADE.canvas=document.getElementById('arcade-canvas');`);
function out(name,setup,w=1280,height=720){
 run(`e.beginMRG();${setup}`);context.innerWidth=w;node('arcade-canvas').width=w;node('arcade-canvas').height=height;node('arcade-canvas').getBoundingClientRect=()=>({width:w,height,left:0,top:0});
 const scene=run('spaceScene(e,e.elapsed,true)'),meshes=run('SPACE_MESH'),used=[...new Set(scene.map(x=>x.mesh))];
 const payload={vertex:run('SPACE_VERTEX'),fragment:run('SPACE_FRAGMENT'),skyVertex:run('SPACE_SKY_VERTEX'),skyFragment:run('SPACE_SKY_FRAGMENT'),postVertex:run('SPACE_POST_VERTEX'),postFragment:run('SPACE_POST_FRAGMENT'),camera:plain(run('spaceCamera(e,e.elapsed)')),scene:plain(scene).map(x=>({...x,model:Object.values(x.model)})),meshes:Object.fromEntries(used.map(k=>[k,{p:Array.from(meshes[k].p),n:Array.from(meshes[k].n)}]))};
 if(w===1280)fs.writeFileSync(root+'/qa120/'+name+'.json',JSON.stringify(payload));
 const canvas=createCanvas(w,height);context.qaCtx=canvas.getContext('2d');run(`drawFinaleHUD(qaCtx,e,spaceCamera(e,e.elapsed),${w},${height})`);fs.writeFileSync(root+'/qa133/'+name+'-hud.png',canvas.toBuffer('image/png'));
 if(w<1280){const c=createCanvas(w,height);context.qaScene=c.getContext('2d');run(`spaceDrawCPU(qaScene,spaceScene(e,e.elapsed,true),spaceCamera(e,e.elapsed),${w},${height})`);context.qaScene.drawImage(canvas,0,0);fs.writeFileSync(root+'/qa133/'+name+'.png',c.toBuffer('image/png'))}
 console.log(name,scene.length,plain(run('({pos:e.board.pos,phase:e.finale.phase,telegraph:e.finale.telegraph,open:e.finale.open})')));
}
out('mrg133-warning',`e.finale.attackClock=0;for(let i=0;i<25;i++)e.step(1/60,{})`);
out('mrg133-jump',`e.finale.attackClock=0;for(let i=0;i<101;i++)e.step(1/60,{fire:true});for(let i=0;i<27;i++)e.step(1/60,{moveX:1,boost:true,fire:true})`);
out('mrg133-defeat',`e.board.pos=[-13,5,0];e.finale.mrg.hp=0;for(let i=0;i<70;i++)e.step(1/60,{})`);
out('mrg133-portrait',`e.finale.pattern=1;e.finale.attackClock=0;for(let i=0;i<40;i++)e.step(1/60,{})`,390,460);
out('mrg133-landscape',`e.finale.attackClock=0;for(let i=0;i<112;i++)e.step(1/60,{fire:true});for(let i=0;i<24;i++)e.step(1/60,{boost:true,fire:true})`,592,244);
out('mrg133-compact',`e.finale.attackClock=0;for(let i=0;i<35;i++)e.step(1/60,{})`,340,168);
