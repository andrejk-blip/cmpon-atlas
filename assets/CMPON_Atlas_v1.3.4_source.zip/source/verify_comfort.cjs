const {fs,assert,root,run,plain,node,event,context,doc,store}=require('./campaign-harness.cjs');
context.innerWidth=390;context.innerHeight=744;context.visualViewport={height:744,addEventListener(){}};context.location={hash:'#game',protocol:'file:'};
doc.documentElement={style:{setProperty(){}}};
run('ARCADE.forceCPU=true;initialize();arcadeAction("arcade-start");arcadeAction("citadel-launch")');
const click=(action,value)=>event('click',{target:{tagName:'BUTTON',closest(){return {dataset:{action,value}}}}});
function pointer(id,type,props={}){let prevented=false;for(const f of node(id).handlers[type]||[])f({pointerId:7,pointerType:'touch',button:0,clientX:48,clientY:48,preventDefault(){prevented=true},...props});return prevented}
node('arcade-stick').getBoundingClientRect=()=>({left:0,top:0,width:96,height:96});
assert(run('ARCADE.engine.assist'),'Phone defaults to the learning flight');assert(run('ARCADE.engine.autopilot'));
pointer('arcade-stick','pointerdown');assert(run('ARCADE.engine.autopilot'),'Center contact is not manual steering');
pointer('arcade-stick','pointermove',{clientX:80});assert(!run('ARCADE.engine.autopilot'));
pointer('arcade-stick','pointerup');assert(run('ARCADE.engine.autopilot'),'Assist returns when the joystick is released');
click('citadel-primary');assert(!run('ARCADE.engine.autopilot'));pointer('arcade-stick','pointerdown',{clientX:80});pointer('arcade-stick','pointerup');assert(!run('ARCADE.engine.autopilot'),'Explicit manual mode is respected');click('citadel-primary');
run('ARCADE.engine.assist=false');pointer('arcade-stick','pointerdown',{clientX:80});pointer('arcade-stick','pointerup');assert(!run('ARCADE.engine.autopilot'),'Combat mode keeps manual steering');
assert(pointer('arcade-fire-touch','pointerdown',{pointerId:22}));assert(run('arcadeInput().fire'));assert(node('arcade-fire-touch').classList.contains('is-held'));
pointer('arcade-fire-touch','pointerup',{pointerId:90});assert(run('arcadeInput().fire'),'An unrelated finger must not release fire');
assert(pointer('arcade-fire-touch','contextmenu'));assert(pointer('arcade-fire-touch','selectstart'));
pointer('arcade-fire-touch','pointercancel',{pointerId:22});assert(!run('arcadeInput().fire'));assert(!node('arcade-fire-touch').classList.contains('is-held'));
const html=run('renderArcade()'),ids=Array.from(html.matchAll(/\bid="([^"]+)"/g),m=>m[1]);assert.equal(new Set(ids).size,ids.length,'No duplicate audio or control IDs');
const css=fs.readFileSync(root+'/comfort.css','utf8');assert(css.includes('.arcade-touch *'));assert(css.includes('-webkit-user-select:none'));assert(css.includes('-webkit-touch-callout:none'));
run('ARCADE.engine.beginBoarding()');assert(!run('ARCADE.engine.board.guide'));click('citadel-primary');assert(run('ARCADE.engine.board.guide'));pointer('arcade-stick','pointerdown',{clientX:80});pointer('arcade-stick','pointerup');assert(!run('ARCADE.engine.board.guide'));
// All actual questions, answers, wrong-answer recovery and source pages.
let questions=0;
for(let i=0;i<8;i++){
 run('ARCADE.engine.beginStage('+Math.floor(i/2)+');ARCADE.engine.launch();ARCADE.engine.lesson={reqId:ARCADE.engine.plan[ARCADE.engine.stage]['+(i%2?2:0)+'],caseIndex:'+i+',readClock:0,attempts:0,feedback:null,solved:false};ARCADE.engine.status="lesson";ARCADE.overlayToken="";updateArcadeOverlay()');
 let h=node('arcade-overlay').innerHTML;assert(h.includes('review-question'));assert.equal((h.match(/data-action="citadel-lesson-answer"/g)||[]).length,4);assert(!h.includes('lesson-document'));
 click('citadel-review-source');assert(node('arcade-overlay').innerHTML.includes('review-reader'));assert(!node('arcade-overlay').innerHTML.includes('citadel-lesson-answer'));click('citadel-review-question');
 const correct=run('CITADEL_LESSONS['+i+'].correct');click('citadel-lesson-answer',String((correct+1)%4));assert(node('arcade-overlay').innerHTML.includes('review-result'));assert(!node('arcade-overlay').innerHTML.includes('citadel-lesson-answer'));
 click('citadel-lesson-retry');assert.equal(run('ARCADE.engine.lesson.attempts'),1);assert(node('arcade-overlay').innerHTML.includes('review-question'));
 click('citadel-lesson-answer',String(correct));assert(run('ARCADE.engine.lesson.solved'));assert(node('arcade-overlay').innerHTML.includes('citadel-lesson-next'));questions++;
}
for(let i=0;i<12;i++){
 run('ARCADE.engine.beginStage('+Math.floor(i/3)+');ARCADE.engine.beginBoarding();ARCADE.engine.board.question='+i+';ARCADE.engine.status="remark";ARCADE.engine.remarkFeedback=null;ARCADE.overlayToken="";updateArcadeOverlay()');
 assert.equal((node('arcade-overlay').innerHTML.match(/data-action="citadel-answer"/g)||[]).length,3);
 const correct=run('CITADEL_REMARKS['+i+'].correct');click('citadel-answer',String((correct+1)%3));assert(node('arcade-overlay').innerHTML.includes('review-result'));click('citadel-remark-next');assert(node('arcade-overlay').innerHTML.includes('review-question'));click('citadel-answer',String(correct));assert(node('arcade-overlay').innerHTML.includes('review-result'));questions++;
}
let paginated=0;for(const [w,h]of [[320,436],[390,620],[568,212],[844,256]])for(const r of plain(run('DATA.rows'))){const pages=plain(run('reviewTextPages('+JSON.stringify(r.text)+','+w+','+h+')'));assert.equal(pages.join(''),r.text);assert(pages.length>0&&pages.every(p=>p.length>0));paginated++}
// Web Audio mock validates graph lifetime and scheduling, not a listening test.
const audioNodes=[];
class Param{constructor(){this.value=0}setValueAtTime(v){this.value=v}linearRampToValueAtTime(v){this.value=v}exponentialRampToValueAtTime(v){this.value=v}setTargetAtTime(v){this.value=v}cancelScheduledValues(){}}
class AudioNode{constructor(){this.gain=new Param();this.frequency=new Param();this.pan=new Param();this.Q=new Param();this.delayTime=new Param();this.threshold=new Param();this.knee=new Param();this.ratio=new Param();this.attack=new Param();this.release=new Param();audioNodes.push(this)}connect(){}disconnect(){this.disconnected=true}start(t){this.started=t}stop(t){this.stopped=t}}
class AudioContext{constructor(){this.currentTime=0;this.state='running';this.destination=new AudioNode()}createGain(){return new AudioNode()}createOscillator(){return new AudioNode()}createStereoPanner(){return new AudioNode()}createDynamicsCompressor(){return new AudioNode()}createBiquadFilter(){return new AudioNode()}createDelay(){return new AudioNode()}resume(){this.state='running';return Promise.resolve()}}
context.AudioContext=AudioContext;
run('ARCADE.engine.beginStage(0);ARCADE.engine.launch();SPACE_AUDIO.music=true;ARCADE.sound=true;spaceAudioUnlock();spaceAudioSync()');assert(run('SPACE_AUDIO.ready'));assert.equal(run('SPACE_AUDIO.theme'),'orbit0');assert(run('SPACE_AUDIO.voices.size>0'));
const themeSignatures=new Set();for(const key of plain(run('Object.keys(SPACE_THEMES)'))){const theme=plain(run('SPACE_THEMES['+JSON.stringify(key)+']'));themeSignatures.add(JSON.stringify([theme.bpm,theme.root,theme.chords,theme.motif]));for(let i=0;i<64;i++){const notes=plain(run('spaceScoreStep(SPACE_THEMES['+JSON.stringify(key)+'],'+i+')'));assert(notes.every(n=>n.amp<=.16&&n.duration>0&&['sine','triangle'].includes(n.type)))}}
assert.equal(themeSignatures.size,16);
run('ARCADE.engine.beginBoarding();spaceAudioSync()');assert.equal(run('SPACE_AUDIO.theme'),'deck0');run('ARCADE.engine.phase="escort";spaceAudioSync()');assert.equal(run('SPACE_AUDIO.theme'),'hyper0');
run('ARCADE.engine.phase="boarding";ARCADE.engine.board.question=0;ARCADE.engine.status="remark";spaceAudioSync()');assert(run('SPACE_AUDIO.track.volume<.1'),'Reading ducks the soundtrack');
let count=audioNodes.filter(n=>n.started!==undefined).length;run('arcadeTone("shot");arcadeTone("shot");arcadeTone("shot")');assert.equal(audioNodes.filter(n=>n.started!==undefined).length,count+1,'Rapid plasma events share a quieter rate limit');
click('arcade-sound');assert(!run('ARCADE.sound'));assert(run('SPACE_AUDIO.music'));count=audioNodes.length;run('arcadeTone("shot")');assert.equal(audioNodes.length,count);
click('arcade-music');assert(!run('SPACE_AUDIO.music'));assert.equal(run('SPACE_AUDIO.track'),null);assert.equal(run('SPACE_AUDIO.fx.gain.value'),0);assert.equal(JSON.parse(store.get('cmpon.citadel.audio.v1')).music,false);
run('SPACE_AUDIO.music=true;ARCADE.sound=true;spaceAudioRead()');assert(!run('SPACE_AUDIO.music'));assert(!run('ARCADE.sound'));
click('arcade-music');assert(run('SPACE_AUDIO.music'));doc.hidden=true;run('spaceAudioSync()');assert.equal(run('SPACE_AUDIO.track'),null);doc.hidden=false;run('spaceAudioSync()');assert(run('SPACE_AUDIO.track'));
run('STATE.view="map";spaceAudioSync()');assert.equal(run('SPACE_AUDIO.track'),null);for(const n of audioNodes)if(n.onended)n.onended();assert.equal(run('SPACE_AUDIO.voices.size'),0,'Oscillator resources are released');
const report={version:'1.3.4',centerTouchKeepsAutopilot:true,learningFlightReturnsAutopilot:true,explicitManualModeRetained:true,groundGuideOptIn:true,holdFirePointerOwnership:true,selectionAndCalloutSuppressed:true,uniqueControlIDs:true,questionAndFeedbackViews:questions,sourcePaginationLossless:paginated,originalMusicThemes:themeSignatures.size,separateMusicAndEffects:true,preferencesPersist:true,readingDucksMusic:true,hiddenAndAtlasStopMusic:true,shotRateLimit:true,voiceResourceCleanup:true,browserLayoutQA:'unavailable',physicalIPhoneQA:'not_performed',audioListeningQA:'not_performed'};
fs.writeFileSync(root+'/qa_comfort.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
