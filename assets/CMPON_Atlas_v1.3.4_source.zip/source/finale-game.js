// Operation MRG. Independent checkpoints preserve the four completed editions.
const FINALE_TRIALS=[
 {title:'Шлюз доказательств',q:'Матрица связывает ФТ с источником, но подтверждающая цитата относится только к части функции. Что загружать?',choices:['Полное соответствие: ссылка уже есть.','Разделить подтверждённую часть и трактовку; проверить основание.','Удалить ФТ без решения владельца.'],correct:1,why:'Точная ссылка должна подтверждать заявленный смысл. В учебном продолжении владелец проверил спорную часть и зафиксировал решение.'},
 {title:'Полигон испытаний',q:'Все положительные проверки пройдены. Обязательный тест отказа для запрещённой роли отсутствует в протоколе.',choices:['Дополнить разрешённое испытание и зафиксировать ожидаемый отказ.','Считать отсутствие ошибки доказательством запрета.','Скрыть пропущенный тест.'],correct:0,why:'Нужны оба сценария: разрешённое действие и отказ без полномочий. Учебный тест выполнен на согласованных данных, ожидаемый отказ подтверждён.'},
 {title:'Печать согласования',q:'Испытания завершены, но контрольная сумма пакета отличается от согласованной редакции.',choices:['Загрузить, потому что название совпадает.','Переименовать пакет в согласованный.','Сверить состав и решения, повторить затронутые проверки, выпустить проверенный пакет.'],correct:2,why:'Исполняться должен именно проверенный и согласованный состав. В учебном продолжении версии сверены, проверки повторены, контрольная сумма подтверждена.'}
];
const FINALE_DECK={name:'Логово · архив нулевой редакции',short:'ЛОГОВО',theme:'security',accent:'#7ff4cd',warm:'#c29dff',zones:['Посадочный шлюз','Лабиринт источников','Полигон испытаний','Сектор главного компьютера'],
 rects:[[-2,2,2,6,0],[-1,1,-3,1,0],[-6,1,-5,-3,1],[-7,-5,-12,-4,1],[-6,3,-13,-11,1],[2,4,-20,-12,2],[-4,3,-21,-19,2],[-5,-3,-29,-20,2],[-4,5,-30,-28,3],[4,6,-37,-29,3],[0,6,-38,-36,3],[-1,1,-44,-37,3],[-10,-6,-9,-7,1],[-10,-9,-13,-8,1],[4,9,-17,-15,2],[8,10,-22,-16,2],[-9,-4,-26,-24,2],[6,10,-34,-32,3]],
 spawn:[0,0,20],terminals:[[-24,0,-44],[12,0,-76],[20,0,-140]],exit:[0,0,-168],centers:[[-24,0,-30],[12,0,-62],[20,0,-128]],covers:[[-26,-26,.7,1.1],[10,-58,.6,1],[22,-122,.6,1]],doors:[[0,4,5.5,.65],[-24,-38,5.5,.65],[12,-70,5.5,.65],[20,-134,5.5,.65]]};
CITADEL_DECKS.push(FINALE_DECK);
function finaleSteer(e,input,goal,standOff=0,maxSpeed=24){
 const p=e.player,d=V3.sub(goal,p.pos),dist=V3.len(d),yaw=Math.atan2(d[0],-d[2]),pitch=arcadeClamp(Math.atan2(d[1],Math.hypot(d[0],d[2])),-1.4,1.4),dy=Math.atan2(Math.sin(yaw-p.yaw),Math.cos(yaw-p.yaw)),dp=pitch-p.pitch,basis=flightBasis(p.yaw,p.pitch);
 // Keep a slow turning arc instead of switching thrust abruptly between 0 and 24.
 // Actual acceleration remains in the movement integrator, including target changes.
 const alignment=Math.max(0,V3.dot(basis.f,V3.norm(d)));
 let speed=Math.min(maxSpeed,Math.max(0,(dist-standOff)*1.25))*(.18+.82*alignment*alignment);
 if(!e.finale){
  // Check the current heading as well as the planned route: momentum during a
  // turn must never carry the ship into the station or a nearby asteroid.
  const look=V3.add(p.pos,V3.scale(basis.f,4+Math.max(0,p.speed)*.4));
  const hullAhead=citadelHullHit(e,p.pos,look,4),hullBraking=hullAhead&&(!citadelHullHit(e,p.pos,p.pos,4)||citadelHullHit(e,look,look,4));
  const rockBraking=e.asteroids.some(a=>{
   const away=V3.sub(p.pos,a.pos),radius=a.r+4;
   // Inside the safety margin, allow an outward course to clear it. The solid
   // collision radius is smaller; stopping every outward ray would deadlock.
   if(V3.len(away)<radius&&V3.dot(away,basis.f)>=0)return false;
   return flightSegment(p.pos,look,a.pos,radius)!==null;
  });
  if(hullBraking||rockBraking)speed=0;
 }
 return {...input,turn:arcadeClamp(dy*3,-1,1),pitch:arcadeClamp(dp*3,-1,1),boost:false,brake:speed<7,cruiseSpeed:speed}
}
const MRG_PLATFORMS=[[-35,20,1],[-18,-9,5],[-3,6,7],[10,17,4]];
const MRG_ATTACKS=[
 {title:'ВОЛНА — ПРЫГАЙ',detail:'Оранжевый разряд идёт по полу. Перепрыгни или поднимись на платформу.',color:'#ffb572'},
 {title:'ВЕЕР — ДВИГАЙСЯ',detail:'Заряды летят веером. Смещайся между ними и стреляй в открытое ядро.',color:'#cbabff'},
 {title:'ЛУЧ — СМЕНИ ВЫСОТУ',detail:'Линия уже зафиксирована. Прыгни; с платформы можно спуститься вниз.',color:'#ff8eaf'}
];
class RequirementArcade extends RequirementExpeditionBase{
 constructor(seed,emit){super(seed,emit);this.finale=null;this.navWatch=null;this.missileFlash=0;this.caseBank=1}
 beginStage(n){this.finale=null;this.navWatch=null;super.beginStage(n);this.stageStart.caseBank=this.caseBank??1}
 checkpoint(){return {...super.checkpoint(),caseBank:this.caseBank??1}}
 missile(){if(this.finale?.phase==='mrg')return this.mrgGrenade();const n=this.bullets.length,ok=super.missile();if(ok){const b=this.player,basis=flightBasis(b.yaw,b.pitch);for(const m of this.bullets.slice(n)){m.pos=V3.add(b.pos,V3.add(V3.scale(basis.r,b.missiles%2?3.3:-3.3),V3.scale(basis.f,3)));m.trail=[m.pos.slice()];m.life=7;m.r=1.1;m.color='#ffe5ad'}this.missileFlash=1;this.notify('РАКЕТА УШЛА','Яркий янтарный след → захваченная цель')}return ok}
 hit(enemy,amount){if(this.finale&&this.finale.phase==='boss'){if(enemy.dead)return;enemy.hp-=amount;enemy.hit=.16;if(enemy.hp<=0){enemy.dead=true;this.score+=enemy.core?600:3500;this.explosions.push({pos:enemy.pos.slice(),life:1.2,max:1.2,color:'#ffd39c'});this.emit('destroy');this.player.missiles=Math.min(16,this.player.missiles+2);this.player.hp=Math.min(100,this.player.hp+12);this.selectedTarget=null;this.detour=null;if(!enemy.core)this.beginBreach();else if(!this.enemies.some(x=>!x.dead)){this.say('Опоры щита разрушены. Открыто центральное ядро «Параллакса»!','alert',true);this.emit('boss')}}return}const wasSelected=!enemy.dead&&enemy.id===this.selectedTarget;super.hit(enemy,amount);if(enemy.dead&&wasSelected){this.selectedTarget=null;this.detour=null;this.navWatch=null}}
 guidance(input){if(!this.autopilot)return input;if(this.phase==='escort')return super.guidance(input);const t=this.navTarget();if(!t){this.selectedTarget=null;this.detour=null;this.navWatch=null;return {...input,turn:0,pitch:0,cruiseSpeed:0,boost:false,brake:true}}
  const key=t.id??t.reqId??this.phase,now=this.elapsed,p=this.player;let watch=this.navWatch;
  if(!watch||watch.key!==key){this.detour=null;watch=this.navWatch={key,at:now,pos:p.pos.slice(),goal:t.pos.slice(),recover:0}}
  if(V3.len(V3.sub(watch.goal,t.pos))>26){this.detour=null;watch.goal=t.pos.slice()}
  if(now-watch.at>3){if(V3.len(V3.sub(p.pos,watch.pos))<2&&V3.len(V3.sub(t.pos,p.pos))>55){this.detour=null;watch.recover++;this.navRecoveries=(this.navRecoveries||0)+1}watch.at=now;watch.pos=p.pos.slice()}
  if(this.finale)return finaleSteer(this,input,t.pos,this.finale.phase==='boss'?44:0,22);
  if(this.phase==='orientation'){const edge=V3.sub(t.pos,V3.scale(V3.norm(V3.sub(t.pos,p.pos)),26));if(!citadelHullHit(this,p.pos,edge,3.2))return finaleSteer(this,input,t.pos,22,24)}
  const goal=citadelHullResolve(this,t.pos,t.pos,10).pos;let waypoint=citadelDetour(this,p.pos,goal);
  // Plan around a rock as a waypoint; steering noise used to cancel target turns indefinitely.
  for(const a of this.asteroids){if(flightSegment(p.pos,waypoint,a.pos,a.r+7)===null)continue;const dir=V3.norm(V3.sub(waypoint,p.pos)),side=V3.norm(V3.cross(dir,Math.abs(dir[1])>.9?[1,0,0]:[0,1,0]));const choices=[1,-1].map(s=>V3.add(a.pos,V3.scale(side,(a.r+15)*s)));const alt=choices.filter(q=>!citadelHullHit(this,p.pos,q,7)).sort((a,b)=>V3.len(V3.sub(a,p.pos))+V3.len(V3.sub(waypoint,a))-V3.len(V3.sub(b,p.pos))-V3.len(V3.sub(waypoint,b)))[0];if(alt)waypoint=alt;break}
  if(V3.len(V3.sub(waypoint,p.pos))<1&&V3.len(V3.sub(goal,p.pos))>35){waypoint=V3.add(p.pos,[0,p.pos[1]>=this.station.pos[1]?25:-25,0]);this.detour=null}
  const direct=V3.len(V3.sub(waypoint,goal))<1,combat=this.phase==='battle'&&this.navMode!=='module';return finaleSteer(this,input,waypoint,direct&&combat?38:0,24)
 }
 target(){if(this.finale&&['boss','breach'].includes(this.finale.phase)){const target=this.navTarget();if(!target?.id)return null;const d=V3.sub(target.pos,this.player.pos);return V3.dot(flightBasis(this.player.yaw,this.player.pitch).f,V3.norm(d))>.84?target:null}return super.target()}
 navTarget(){if(this.finale){if(this.finale.phase==='boss'){const cores=this.enemies.filter(x=>!x.dead);const target=cores.find(x=>x.id===this.selectedTarget)||cores.sort((a,b)=>V3.len(V3.sub(a.pos,this.player.pos))-V3.len(V3.sub(b.pos,this.player.pos)))[0]||(!this.boss?.dead?this.boss:null);this.selectedTarget=target?.id??null;return target}if(this.finale.phase==='breach')return {pos:[0,0,-142],name:'Окно в корпусе · вход',id:null};return null}return super.navTarget()}
 finishBoarding(){if(this.finale?.phase==='maze'){if(this.board.completed.length<3)return false;this.beginMRG();return true}if(this.stage!==3)return super.finishBoarding();if(this.board.completed.length!==3||this.decisions.filter(x=>x.stage===3).length!==2)return false;this.score+=Math.round(this.stationHp*8+this.nodes.reduce((s,n)=>s+n.integrity,0)*3);this.beginFinale();return true}
 beginFinale(){this.finale={phase:'boss',checkpoint:'boss',time:0,attack:0,telegraph:0,tests:[],comic:0,answer:null};this.status='finalebrief';this.phase='finale';this.board=null;this.escort=null;this.crash=null;this.player.hp=100;this.say('Пакет согласован. Но путь к исполнению перекрыл «Параллакс». Разруши щупальца-опоры, пробей ядро и доставь ФТ к МРГ.','order',true);finalePersist(this);this.emit('state',this.status)}
 launchFinale(){if(this.status!=='finalebrief')return;this.finale.phase='boss';this.finale.time=0;this.phase='finale';this.status='playing';this.autopilot=true;this.selectedTarget=null;this.board=null;this.crash=null;this.escort=null;this.asteroids=[];this.bullets=[];this.hostile=[];this.explosions=[];Object.assign(this.player,{pos:[0,0,10],yaw:0,pitch:0,bank:0,speed:0,hp:100,energy:100,missiles:12+this.upgrades.rockets*3,invulnerable:2,shotCooldown:0,missileCooldown:0,pulseCooldown:0});const hp=this.assist?1400:1800;this.enemies=[[-23,15,-125],[23,15,-125],[-23,-15,-125],[23,-15,-125]].map((pos,i)=>({id:++this.entityId,pos,vel:[0,0,0],r:5.8,hp,maxHp:hp,core:true,name:'Опора щита '+(i+1),color:'#ffbc83',hit:0,dead:false}));const life=this.assist?4600:6000;this.boss={id:++this.entityId,pos:[0,0,-139],vel:[0,0,0],r:12,hp:life,maxHp:life,name:'Параллакс · ядро',color:'#cd97ff',hit:0,dead:false};this.emit('boss');this.emit('state','playing')}
 beginBreach(){const f=this.finale;f.phase='breach';f.time=0;f.checkpoint='breach';this.boss=null;this.enemies=[];this.hostile=[];this.bullets=[];this.selectedTarget=null;this.player.hp=Math.max(60,this.player.hp);this.autopilot=true;this.navWatch=null;this.say('Корпус открыт! Лети в золотое окно по центру. Автокурс проведёт через проём.','success',true);this.notify('ОКНО ОТКРЫТО','Пролёт внутрь → высадка в логово');finalePersist(this)}
 beginFinalLanding(){this.finale.phase='landing';this.finale.time=0;this.finale.start=this.player.pos.slice();this.phase='finale';this.status='docking';this.autopilot=false;this.bullets=[];this.hostile=[];this.emit('dock');this.emit('state','docking')}
 beginBoarding(){if(this.finale){if(this.finale.phase==='upload'){this.finishFinale();return}this.beginLair();return}super.beginBoarding()}
 beginLair(){const f=this.finale;f.phase='maze';f.checkpoint='maze';f.time=0;f.tests=[];f.answer=null;this.phase='boarding';this.status='boarding';this.crash=null;this.boss=null;this.dock=null;this.escort=null;const deck=stationMakeDeck(4),d=deck.definition;this.board={...deck,pos:d.spawn.slice(),previous:d.spawn.slice(),camera:d.spawn.slice(),yaw:Math.PI,hp:100,energy:100,cooldown:0,pulseCooldown:0,pulseWave:0,invulnerable:2,time:0,kills:0,enemies:[],bullets:[],hostile:[],sparks:[],terminal:0,completed:[],question:null,answered:false,returning:false,guide:false,guideRoute:null,terminals:d.terminals.map(p=>p.slice()),exit:d.exit.slice(),intro:1.5,zone:0,lastZone:0,zoneBanner:4,terminalGrace:0,guideHint:10};stationBuildNav(this.board);this.spawnBoardWave(this.assist?5:7);this.say('Пакет ФТ у тебя. Три шлюза: доказательства, испытания, согласование. Двигайся сам или включи G — проводник.','order',true);finalePersist(this);this.emit('state','boarding')}
 boardInteract(){if(this.finale?.phase!=='maze')return this.finale?false:super.boardInteract();const b=this.board;if(b.completed.length===3){if(V3.len(V3.sub(b.pos,b.exit))<3.2)this.beginMRG();return true}const point=b.terminals[b.completed.length];if(V3.len(V3.sub(b.pos,point))<2.9&&stationLine(b,b.pos,point,.15)){this.status='finalcheck';this.finale.answer=null;this.emit('terminal');this.emit('state','finalcheck');return true}return false}
 answerFinale(index){if(this.status!=='finalcheck'||this.finale.answer!==null||!Number.isInteger(index)||index<0||index>2)return false;const q=FINALE_TRIALS[this.board.completed.length];this.finale.answer=index;const ok=index===q.correct;this.emit('answer',ok);return ok}
 continueFinaleCheck(){if(this.status!=='finalcheck'||this.finale.answer===null)return;const b=this.board,q=FINALE_TRIALS[b.completed.length];if(this.finale.answer!==q.correct){this.finale.answer=null;return}const i=b.completed.length;b.completed.push(i);this.finale.tests.push(i);this.score+=700;this.finale.answer=null;this.status='boarding';b.guideRoute=null;b.guideWatch=null;b.hostile=[];b.bullets=[];b.enemies=[];b.hp=Math.min(100,b.hp+30);b.energy=100;b.terminalGrace=.8;if(b.completed.length<3)this.spawnBoardWave(this.assist?5:8);else b.returning=true;this.say(b.completed.length<3?'Проверка пройдена. Следующий шлюз отмечен на карте. G — проводник.':'Все проверки пройдены. Донеси пакет к главному компьютеру МРГ.','success',true);citadelOutcomeNotice(this,citadelFinalCase(i));this.emit('state','boarding')}
 beginMRG(){
  const f=this.finale;Object.assign(f,{phase:'mrg',checkpoint:'mrg',tests:[0,1,2],time:0,attack:0,telegraph:0,attackClock:2,pattern:-1,open:false,exposedFor:0,beamTime:0,defeatTime:0});
  this.phase='boarding';this.status='boarding';this.crash=null;this.player.missiles=9;this.flash=0;this.shake=0;
  const life=this.assist?6200:8200;f.mrg={hp:life,maxHp:life,pos:[24,8,0],hit:0,stage:0};
  const b=this.board||{};Object.assign(b,{pos:[-25,1,0],previous:[-25,1,0],camera:[0,0,0],hp:100,energy:100,yaw:Math.PI/2,vy:0,vx:0,grounded:true,jumpHeld:false,jumpBuffer:0,coyote:.12,dropHeld:false,dropTimer:0,jumpFX:0,landFX:0,landAt:[-25,0,0],guideJumpUntil:0,cooldown:0,pulseCooldown:0,pulseWave:0,invulnerable:2,time:0,kills:0,guide:false,guideHint:10,enemies:[],bullets:[],hostile:[],sparks:[],completed:[0,1,2],terminals:[[-5,0,0],[5,0,0],[20,0,0]],exit:[24,0,0]});this.board=b;
  this.say('Последний рубеж. A/D — движение, W или Shift — прыжок; держи кнопку для высокого прыжка. Вниз — спуститься с платформы. Пережди атаку и бей в золотое ядро. G — помощь.','order',true);finalePersist(this);this.emit('boss');this.emit('state','boarding')
 }
 mrgGrenade(){if(this.status!=='boarding'||this.finale?.phase!=='mrg'||this.player.missiles<=0||this.board.grenadeCooldown>0)return false;this.player.missiles--;this.board.grenadeCooldown=1.3;this.board.bullets.push({pos:V3.add(this.board.pos,[1,.7,0]),vel:V3.scale(V3.norm(V3.sub(this.finale.mrg.pos,this.board.pos)),36),life:3,damage:160,grenade:true});this.emit('missile');return true}
 mrgDamage(n){const b=this.board;if(b.invulnerable>0)return;b.hp=Math.max(0,b.hp-n*(this.assist?.5:1)*Math.pow(.8,this.upgrades.armor));b.invulnerable=.8;this.flash=.3;this.emit('damage');if(b.hp<=0){this.status='lost';this.lossReason='МРГ перехватил носитель. Прыгайте через напольные волны, уходите с отмеченной линии и стреляйте в открытое ядро.';this.emit('state','lost')}}
 stepMRG(dt,input){
  const f=this.finale,b=this.board,m=f.mrg;f.time+=dt;b.time+=dt;this.elapsed+=dt;
  this.flash=Math.max(0,this.flash-dt);this.shake=Math.max(0,this.shake-dt);this.captainClock=Math.max(0,this.captainClock-dt);
  for(const k of ['cooldown','pulseCooldown','invulnerable','grenadeCooldown','jumpFX','landFX','dropTimer'])b[k]=Math.max(0,(b[k]||0)-dt);
  m.hit=Math.max(0,m.hit-dt);f.beamTime=Math.max(0,(f.beamTime||0)-dt);
  // The defeated core gets its own visible, pausable resolution before upload.
  if(m.hp<=0){
   if(!(f.defeatTime>0)){f.defeatTime=3;f.open=true;f.telegraph=0;f.beamTime=0;b.hostile=[];b.bullets=[];b.guide=false;b.vx=0;this.say('Цикл правок остановлен. МРГ освобождён! Передаём согласованный пакет на исполнение.','success',true);this.emit('boss')}
   f.defeatTime=Math.max(.0001,f.defeatTime-dt);b.previous=b.pos.slice();f.shellOpen=Math.min(1,(f.shellOpen||0)+dt*2);
   if(!b.grounded){const oldY=b.pos[1];b.vy-=36*dt;b.pos[1]+=b.vy*dt;let floor=1;for(const [lo,hi,y]of MRG_PLATFORMS)if(b.pos[0]>=lo&&b.pos[0]<=hi&&oldY>=y&&b.pos[1]<=y)floor=Math.max(floor,y);if(b.pos[1]<=floor){b.pos[1]=floor;b.vy=0;b.grounded=true;b.landFX=.28;b.landAt=[b.pos[0],floor-1,0]}}
   if(f.defeatTime<=.001)this.beginUpload();return;
  }
  f.exposedFor=Math.max(0,(f.exposedFor||0)-dt);f.open=f.exposedFor>0;
  let dx=arcadeClamp(input.moveX||0,-1,1),jump=!!input.jump||(input.moveZ||0)<-.4||!!input.boost,drop=(input.moveZ||0)>.5;
  if(b.guide){
   const desired=-15+Math.sin(f.time*.55)*9;dx=arcadeClamp((desired-b.pos[0])*.6,-1,1);drop=false;
   const wave=b.hostile.some(x=>x.wave&&x.pos[0]>b.pos[0]&&x.pos[0]-b.pos[0]<12&&b.pos[1]<4);
   const nearby=b.hostile.some(x=>!x.wave&&x.pos[0]>b.pos[0]&&x.pos[0]-b.pos[0]<8&&Math.abs(x.pos[1]-b.pos[1]-.5)<2.5);
   if(b.grounded&&(wave||nearby||f.pattern===2&&f.telegraph>0&&f.telegraph<.4))b.guideJumpUntil=b.time+.36;
   jump=b.time<(b.guideJumpUntil||0);
  }
  b.previous=b.pos.slice();b.vx=dx*10;b.pos[0]=arcadeClamp(b.pos[0]+b.vx*dt,-32,17);
  b.jumpBuffer=jump&&!b.jumpHeld?.16:Math.max(0,(b.jumpBuffer||0)-dt);
  b.coyote=b.grounded?.12:Math.max(0,(b.coyote||0)-dt);
  if(drop&&!b.dropHeld&&b.grounded&&b.pos[1]>1.1){b.dropTimer=.22;b.pos[1]-=.08;b.vy=-4;b.grounded=false;b.coyote=0;b.jumpBuffer=0}
  b.dropHeld=drop;
  if(b.jumpBuffer>0&&b.coyote>0&&!b.dropTimer){b.vy=22.4;b.grounded=false;b.coyote=0;b.jumpBuffer=0;b.jumpFX=.26;b.jumpAt=[b.pos[0],b.pos[1]-1,0];this.emit('flip')}
  if(!jump&&b.jumpHeld&&b.vy>0)b.vy*=.5;
  b.jumpHeld=jump;const oldY=b.pos[1],impact=b.vy;const wasGrounded=b.grounded;
  b.vy-=dt*36;b.pos[1]+=b.vy*dt;b.grounded=false;
  let surface=-Infinity;
  for(const [lo,hi,y]of MRG_PLATFORMS)if(b.pos[0]>=lo&&b.pos[0]<=hi&&b.vy<=0&&oldY>=y-.001&&b.pos[1]<=y&&(!b.dropTimer||y===1))surface=Math.max(surface,y);
  if(Number.isFinite(surface)){b.pos[1]=surface;b.vy=0;b.grounded=true}
  if(b.pos[1]<1){b.pos[1]=1;b.vy=0;b.grounded=true}
  if(b.grounded&&!wasGrounded&&impact<-3){b.landFX=.28;b.landAt=[b.pos[0],b.pos[1]-1,0]}
  if(input.pulse&&b.pulseCooldown<=0){b.hostile=[];b.pulseCooldown=7;b.invulnerable=1.6;b.pulseWave=1;this.emit('pulse')}
  b.pulseWave=Math.max(0,b.pulseWave-dt);
  if(input.missile)this.mrgGrenade();
  if(input.fire&&b.cooldown<=0){b.cooldown=.14*Math.pow(.9,this.upgrades.weapons);const pos=V3.add(b.pos,[.8,.6,0]),dir=V3.norm(V3.sub(m.pos,pos));b.bullets.push({pos,vel:V3.scale(dir,65),life:1.5,damage:21*(1+.25*this.upgrades.weapons)});this.emit('shot')}
  if(!f.open&&f.telegraph<=0){
   f.attackClock=(f.attackClock??.6)-dt;
   if(f.attackClock<=0){f.pattern=((f.pattern??-1)+1)%3;f.telegraph=this.assist?1.55:1.3;f.aimY=b.pos[1]+.5;this.say(MRG_ATTACKS[f.pattern].detail,'alert',true)}
  }
  if(f.telegraph>0){
   f.telegraph=Math.max(0,f.telegraph-dt);
   if(f.telegraph===0){
    const stage=m.stage;
    if(f.pattern===0)b.hostile.push({pos:[21,1.7,0],vel:[-17-stage*2,0,0],life:4,wave:true,r:1.4,damage:16,color:'#ffb572'});
    else if(f.pattern===1){const aim=Math.atan2(b.pos[1]+.5-m.pos[1],b.pos[0]-m.pos[0]),count=5+stage*2;for(let i=0;i<count;i++){const a=aim+(i-(count-1)/2)*.19;b.hostile.push({pos:m.pos.slice(),vel:[Math.cos(a)*(14+stage*2),Math.sin(a)*(14+stage*2),0],life:5,r:.4,damage:10,color:'#cbabff'})}}
    else f.beamTime=.38;
    f.exposedFor=this.assist?4:3.5;f.open=true;f.attackClock=.7;
   }
  }
  f.shellOpen=(f.shellOpen||0)+((f.open?1:0)-(f.shellOpen||0))*Math.min(1,dt*7);
  if(f.beamTime>0&&Math.abs(b.pos[1]+.5-f.aimY)<1.25)this.mrgDamage(22);
  for(const shot of b.bullets){const from=shot.pos;shot.pos=V3.add(shot.pos,V3.scale(shot.vel,dt));shot.life-=dt;
   if(flightSegment(from,shot.pos,m.pos,3.6)!==null){shot.life=0;if(f.open){m.hp=Math.max(0,m.hp-shot.damage);m.hit=.16;if(b.time-(f.lastCoreSound||0)>.16){f.lastCoreSound=b.time;this.emit('destroy','core')}}}
  }
  for(const shot of b.hostile){const from=shot.pos;shot.pos=V3.add(shot.pos,V3.scale(shot.vel,dt));shot.life-=dt;if(flightSegment(from,shot.pos,V3.add(b.pos,[0,.5,0]),shot.r+.7)!==null){shot.life=0;this.mrgDamage(shot.damage)}}
  b.bullets=b.bullets.filter(x=>x.life>0);b.hostile=b.hostile.filter(x=>x.life>0);
  const stage=Math.min(2,Math.floor((1-m.hp/m.maxHp)*3));
  if(stage>m.stage){m.stage=stage;b.hp=Math.min(100,b.hp+18);this.player.missiles+=2;f.phaseFlash=1;this.emit('boss')}
  f.phaseFlash=Math.max(0,(f.phaseFlash||0)-dt);
 }
 beginUpload(award=true){if(this.finale.tests.length!==3||['upload','victory'].includes(this.finale.phase))return false;this.finale.phase='upload';this.finale.checkpoint='upload';this.finale.time=0;this.status='docking';this.board.hostile=[];this.board.bullets=[];if(award)this.score+=7000;this.say('МРГ освобождён от цикла правок. Загружаем согласованные ФТ на исполнение. Команда ЦСИИ, это наша победа.','success',true);finalePersist(this);this.emit('terminal');this.emit('state','docking');return true}
 finishFinale(){if(this.finale?.phase!=='upload')return;this.finale.phase='victory';this.finale.checkpoint='victory';this.finale.comic=0;this.status='won';this.phase='debrief';this.emit('state','won');finalePersist(this);this.emit('victory')}
 retryFinale(calm=false){const cp=this.finale.checkpoint;if(Number.isFinite(this.finale.checkpointScore))this.score=this.finale.checkpointScore;this.assist=calm||this.assist;this.crash=null;this.hostile=[];this.bullets=[];this.navWatch=null;if(cp==='boss'){this.beginFinale();this.launchFinale()}else if(cp==='breach'){this.launchFinaleFromCheckpoint();this.beginBreach()}else if(cp==='maze')this.beginLair();else if(cp==='mrg'){this.beginMRG()}else if(cp==='upload'||cp==='victory'){this.beginMRG();this.finale.mrg.hp=0;this.beginUpload(false)}this.emit('state',this.status)}
 launchFinaleFromCheckpoint(){this.status='finalebrief';this.launchFinale()}
 stepFinalSpace(dt,input){const f=this.finale,p=this.player;f.time+=dt;this.elapsed+=dt;this.flash=Math.max(0,this.flash-dt);this.captainClock=Math.max(0,this.captainClock-dt);for(const k of ['shotCooldown','missileCooldown','pulseCooldown','invulnerable'])p[k]=Math.max(0,p[k]-dt);const control=this.guidance(input);p.yaw+=(control.turn||0)*1.28*dt;p.pitch=arcadeClamp(p.pitch+(control.pitch||0)*1.05*dt,-1.4,1.4);p.bank+=( -(control.turn||0)*.35-p.bank)*dt*4;p.speed+=((Number.isFinite(control.cruiseSpeed)?control.cruiseSpeed:input.boost?42:input.brake?5:20)-p.speed)*Math.min(1,dt*5);p.pos=V3.add(p.pos,V3.scale(flightBasis(p.yaw,p.pitch).f,p.speed*dt));p.pos[0]=arcadeClamp(p.pos[0],-110,110);p.pos[1]=arcadeClamp(p.pos[1],-75,75);p.pos[2]=arcadeClamp(p.pos[2],f.phase==='boss'?-104:-155,75);this.lock=this.target()?.id||null;if(input.fire)this.fire();if(input.missile)this.missile();if(input.pulse&&p.pulseCooldown<=0){this.hostile=[];p.pulseCooldown=8;p.invulnerable=1.2;this.emit('pulse')}
  if(f.phase==='breach'){if(p.pos[2]<-126){if(Math.abs(p.pos[0])<10&&Math.abs(p.pos[1])<9){this.beginFinalLanding();return}p.pos[2]=-125;p.speed=0;this.damage(18);this.say('Вход только через золотое окно в центре корпуса. G — автокурс.','alert',true)}return}
  const alive=this.enemies.filter(x=>!x.dead);for(const x of [...alive,this.boss].filter(Boolean))x.hit=Math.max(0,x.hit-dt);f.attack-=dt;if(f.attack<=0){f.attack=this.assist?2.5:1.7;const origin=alive.length?alive[Math.floor(f.time)%alive.length].pos:this.boss.pos;const dir=V3.norm(V3.sub(p.pos,origin));for(let i=-1;i<=1;i++){const vel=V3.scale(V3.norm(V3.add(dir,[i*.13,Math.sin(f.time)*.05,0])),this.assist?24:32);this.hostile.push({pos:origin.slice(),vel,life:8,r:1,damage:7,color:'#e5a0ff'})}if(!alive.length){f.telegraph=1.1;f.aim=p.pos.slice()}}
  if(f.telegraph>0){f.telegraph-=dt;if(f.telegraph<=0&&V3.len(V3.sub(f.aim,p.pos))<7)this.damage(10)}
  for(const s of this.bullets){const from=s.pos;if(s.type==='missile'){let target=[...this.enemies,this.boss].find(x=>x&&!x.dead&&x.id===s.target);if(!target){target=this.navTarget();s.target=target?.id}if(target)s.vel=V3.scale(V3.norm(V3.lerp(V3.norm(s.vel),V3.norm(V3.sub(target.pos,s.pos)),Math.min(1,dt*5))),92)}s.pos=V3.add(s.pos,V3.scale(s.vel,dt));s.life-=dt;for(const x of (alive.length?alive:[this.boss]).filter(Boolean))if(!x.dead&&flightSegment(from,s.pos,x.pos,x.r)!==null){s.life=0;this.hit(x,s.damage);break}}
  for(const s of this.hostile){const from=s.pos;s.pos=V3.add(s.pos,V3.scale(s.vel,dt));s.life-=dt;if(flightSegment(from,s.pos,p.pos,2.8)!==null){s.life=0;this.damage(s.damage)}}this.bullets=this.bullets.filter(x=>x.life>0);this.hostile=this.hostile.filter(x=>x.life>0);this.enemies=this.enemies.filter(x=>!x.dead);for(const x of this.explosions)x.life-=dt;this.explosions=this.explosions.filter(x=>x.life>0)
 }
 step(delta,input={}){const dt=arcadeClamp(Number.isFinite(delta)?delta:0,0,.04);this.missileFlash=Math.max(0,(this.missileFlash||0)-dt);if(this.finale&&this.status!=='crashing'&&this.status!=='paused'){const f=this.finale;if(this.status==='playing'&&['boss','breach'].includes(f.phase))this.stepFinalSpace(dt,input);else if(this.status==='docking'&&f.phase==='landing'){f.time+=dt;this.elapsed+=dt;const t=arcadeClamp(f.time/(ARCADE.fx?13:4),0,1);this.player.pos=V3.lerp(f.start,[0,-3,-245],stationSmooth(t));this.player.yaw=0;this.player.pitch=0;this.player.bank=Math.sin(t*Math.PI*2)*.18;if(t>=1)this.beginLair()}else if(this.status==='boarding'&&f.phase==='maze'){f.time+=dt;super.step(delta,input)}else if(this.status==='boarding'&&f.phase==='mrg')this.stepMRG(dt,input);else if(this.status==='docking'&&f.phase==='upload'){f.time+=dt;this.elapsed+=dt;if(f.time>8)this.finishFinale()}}else super.step(delta,input);
  if(this.status==='playing')for(const b of this.bullets)if(b.type==='missile'){b.trail=b.trail||[];b.trail.push(b.pos.slice());if(b.trail.length>18)b.trail.shift();if(!this.finale){const target=this.enemies.find(x=>!x.dead&&x.id===b.target)||(!this.boss?.dead&&this.boss?.id===b.target?this.boss:null);if(!target){const next=this.enemies.filter(x=>!x.dead).sort((a,c)=>V3.len(V3.sub(a.pos,b.pos))-V3.len(V3.sub(c.pos,b.pos)))[0]||this.boss;if(next)b.target=next.id}}}
 }
 objective(){if(!this.finale)return super.objective();const f=this.finale,b=this.board;if(f.phase==='boss')return {title:this.enemies.some(x=>!x.dead)?'Разрушьте 4 опоры щупалец':'Уничтожьте открытое ядро',detail:'Пробел — огонь · Q / ПКМ — ракета · E — щит · G — автокурс.',progress:(4-this.enemies.filter(x=>!x.dead).length)+' / 4 ОПОРЫ'};if(f.phase==='breach')return {title:'Пролетите в золотое окно',detail:'Проём в центре корпуса. Автокурс включён; за окном начнётся высадка.',progress:'ПРОРЫВ В ЛОГОВО'};if(f.phase==='landing')return {title:'Высадка в логово',detail:'Доставляем проверенный архив в посадочный шлюз.',progress:Math.min(100,Math.round(f.time/(ARCADE.fx?13:4)*100))+'% · ВЫСАДКА'};if(f.phase==='maze')return {title:b.completed.length<3?FINALE_TRIALS[b.completed.length].title:'Донесите ФТ к МРГ',detail:'Пакет ФТ с вами. Следуйте золотой линии. G — включить проводник.',progress:b.completed.length+' / 3 ПРОВЕРКИ'};if(f.phase==='mrg')return {title:f.mrg.hp<=0?'МРГ освобождён!':f.telegraph>0?MRG_ATTACKS[f.pattern].title:f.open?'Золотое ядро открыто — огонь!':'МРГ готовит атаку',detail:f.telegraph>0?MRG_ATTACKS[f.pattern].detail:'A/D — движение · W / Shift — прыжок · S — вниз · пробел — огонь · E — щит.',progress:'ФАЗА '+(f.mrg.stage+1)+' / 3 · МРГ '+Math.ceil(Math.max(0,f.mrg.hp/f.mrg.maxHp*100))+'%'};if(f.phase==='upload')return {title:'ФТ загружаются на исполнение',detail:'Проверки пройдены. Целостность подтверждена. Команда ЦСИИ на связи.',progress:Math.min(100,Math.round(f.time/8*100))+'% · ЗАГРУЗКА'};return {title:'Команда ЦСИИ победила',detail:'Согласованный пакет передан на исполнение.',progress:'ОПЕРАЦИЯ ЗАВЕРШЕНА'}}
}
