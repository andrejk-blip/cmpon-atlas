const {run,plain,assert,fs}=require('./campaign-harness.cjs');
run(`ARCADE.sound=false;ARCADE.forceCPU=true;initialize();setView('arcade');
function orbitRun(seed,assist,hz){
 const e=new RequirementArcade(seed);ARCADE.engine=e;e.emit=arcadeEvent;e.start(assist);e.launch();
 let lessons=0,killAt=0,longestKillGap=0,largestKillSpeedDrop=0,kills=0;
 for(let i=0;i<hz*180;i++){
  if(e.status==='lesson'){e.answerLesson(citadelLessonCase(e,e.lesson.caseIndex).correct);e.continueLesson();lessons++;continue}
  if(e.status!=='playing')break;
  const beforeKills=e.totalKills,beforeSpeed=e.player.speed;e.step(1/hz,{fire:true});
  if(e.totalKills!==beforeKills){longestKillGap=Math.max(longestKillGap,e.elapsed-killAt);killAt=e.elapsed;kills=e.totalKills;largestKillSpeedDrop=Math.max(largestKillSpeedDrop,beforeSpeed-e.player.speed)}
 }
 return {seed,assist,hz,status:e.status,phase:e.phase,seconds:e.elapsed,firstPickup:e.firstActionTime,lessons,kills,longestKillGap,largestKillSpeedDrop,station:e.stationHp,hp:e.player.hp};
}
`);
const rows=[];
for(const [seed,assist,hz]of [[417147,true,60],[417147,false,60],[417147,true,25],[417,true,60],[417,false,60]]){
 const r=plain(run(`orbitRun(${seed},${assist},${hz})`));console.log(r);rows.push(r);
 assert.equal(r.status,'docking','First orbit must complete with production HUD callbacks');assert.equal(r.kills,20);assert.equal(r.lessons,2);assert(r.seconds<120);assert(r.firstPickup<3);
 // Only the regular 4/s acceleration limit may reduce speed in a kill frame.
 assert(r.largestKillSpeedDrop<=24*4/hz+.01,'No instantaneous kill-induced speed clamp');
}
fs.writeFileSync('qa132-orbits.json',JSON.stringify(rows,null,2));
console.log('PASS: five complete first orbits, real HUD/overlay events, both modes, 25/60 Hz, both lessons and automatic docking');
