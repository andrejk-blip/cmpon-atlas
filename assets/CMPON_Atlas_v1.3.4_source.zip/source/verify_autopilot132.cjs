const {run,plain,assert,fs}=require('./campaign-harness.cjs');
run(`
function navFixture(goal=[0,0,-140],uiReadsTarget=false){
 const e=new RequirementArcade(417147);e.start(true);e.launch();
 e.phase='battle';e.wave=3;e.waveSpawned=e.waveTotal();e.waveClock=0;e.asteroids=[];e.station.pos=[1000,0,0];e.modules().forEach(m=>m.dead=true);
 Object.assign(e.player,{pos:[0,0,0],yaw:0,pitch:0,speed:22});e.enemyStep=()=>{};e.checkStage=()=>{};
 e.enemies=[{id:100,pos:[0,0,-80],vel:[0,0,0],hp:20,r:3,warp:0,dead:false,color:'#fff',points:100,role:'fighter'},
 {id:101,pos:goal,vel:[0,0,0],hp:100000,r:3,warp:0,dead:false,color:'#fff',points:100,role:'fighter'}];
 e.selectedTarget=100;e.detour=[-50,55,25];e.navWatch={key:100,at:0,pos:[0,0,0],goal:[0,0,-80],recover:0};
 if(uiReadsTarget)e.emit=()=>e.navTarget();return e;
}
`);
// Killing a selected ship used to clamp speed from 22 to 4 instantly.
for(const uiReads of [false,true]){
 run(`globalThis.e=navFixture([0,0,-140],${uiReads});e.hit(e.enemies[0],50)`);
 assert.equal(run('e.player.speed'),22,'A kill must not abruptly change flight speed');
 assert.equal(run('e.detour'),null,'Clear the destroyed target route even if a HUD callback selects the next ship');
 run('globalThis.c=e.guidance({fire:true})');
 assert.equal(run('e.selectedTarget'),101);assert.equal(run('e.player.speed'),22,'Selecting a target must not bypass acceleration');
 assert(run('c.cruiseSpeed>20'));assert(run('c.fire'));
 run('e.step(1/60,{})');assert(run('e.player.speed>21'));
}
run('e=navFixture();e.autopilot=false;e.hit(e.enemies[0],50)');assert.equal(run('e.player.speed'),22,'Manual flight must keep momentum after a kill');
// Turning to the side, behind and above should keep moving, then reach firing distance.
const turns=[];
for(const hz of [25,60])for(const goal of [[0,0,130],[130,0,0],[0,110,-60]]){
 run(`e=navFixture(${JSON.stringify(goal)});e.hit(e.enemies[0],50);var stopped=0,maxStopped=0,arrived=false;for(var i=0;i<${hz}*15;i++){e.step(1/${hz},{});if(e.player.speed<.2&&V3.len(V3.sub(e.player.pos,e.enemies[0].pos))>55){stopped+=1/${hz};maxStopped=Math.max(maxStopped,stopped)}else stopped=0;if(V3.len(V3.sub(e.player.pos,e.enemies[0].pos))<50){arrived=true;break}}`);
 assert(run('arrived'),'Retarget must converge at '+hz+' Hz, goal '+goal);assert(run('maxStopped<.1'),'No stop during an unobstructed turn');
 turns.push({hz,goal,seconds:run('e.elapsed'),maxStopped:run('maxStopped')});
}
// Empty waves are deliberately stationary; no runaway flight into empty space.
run('e=navFixture();e.enemies=[];e.player.speed=24;for(var i=0;i<180;i++)e.step(1/60,{boost:true})');
assert(run('e.player.speed<.001'));assert(run('V3.len(e.player.pos)<6.1'));assert.equal(run('e.detour'),null);
// A forward collision overrides the moving-turn cruise speed.
run('e=navFixture([0,0,-160]);e.station.pos=[0,0,0];e.player.pos=[0,0,-42];e.player.yaw=Math.PI;e.selectedTarget=101;var ahead=V3.add(e.player.pos,[0,0,14]);var blocked=citadelHullHit(e,e.player.pos,ahead,4);c=e.guidance({})');
assert(run('!!blocked'),'Fixture must face a solid station surface');assert.equal(run('c.cruiseSpeed'),0,'Brake before a station surface while turning away');
// Being inside the conservative braking margin must still allow an outward course.
run('e=navFixture();e.asteroids=[{pos:[0,0,0],r:10}];e.player.pos=[13,0,0];e.player.yaw=Math.PI/2;c=finaleSteer(e,{},[100,0,0])');assert(run('c.cruiseSpeed>0'),'Allow escape from an asteroid safety margin');
run('e.player.yaw=-Math.PI/2;c=finaleSteer(e,{},[-100,0,0])');assert.equal(run('c.cruiseSpeed'),0,'An inward course must still brake');
fs.writeFileSync('qa132-navigation.json',JSON.stringify({turns,killMomentum:true,reentrantHud:true,manualMomentum:true,idleStop:true,obstacleBraking:true,safetyMarginEscape:true},null,2));
console.log('PASS: smooth kill/target handoff, reentrant HUD, manual momentum, six retarget paths at 25/60 Hz, idle stop and collision braking');
