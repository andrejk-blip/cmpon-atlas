const h=require('./campaign-harness.cjs'),{run,plain,fs,root,createCanvas,context,node}=h;
fs.mkdirSync(root+'/qa134',{recursive:true});
run(`ARCADE.sound=false;ARCADE.fx=true;globalThis.e=new RequirementArcade(417147);e.start(true);ARCADE.engine=e;ARCADE.canvas=document.getElementById('arcade-canvas');`);
function capture(name,setup){
 run(setup);const scene=run('spaceScene(e,e.elapsed,true)'),meshes=run('SPACE_MESH'),used=[...new Set(scene.map(x=>x.mesh))];
 const payload={vertex:run('SPACE_VERTEX'),fragment:run('SPACE_FRAGMENT'),skyVertex:run('SPACE_SKY_VERTEX'),skyFragment:run('SPACE_SKY_FRAGMENT'),postVertex:run('SPACE_POST_VERTEX'),postFragment:run('SPACE_POST_FRAGMENT'),camera:plain(run('spaceCamera(e,e.elapsed)')),scene:plain(scene).map(x=>({...x,model:Object.values(x.model)})),meshes:Object.fromEntries(used.map(k=>[k,{p:Array.from(meshes[k].p),n:Array.from(meshes[k].n)}]))};
 fs.writeFileSync(root+'/qa120/'+name+'.json',JSON.stringify(payload));
 const canvas=createCanvas(1280,720);context.qaCtx=canvas.getContext('2d');run(`if(e.finale?.phase==='mrg')drawFinaleHUD(qaCtx,e,spaceCamera(e,e.elapsed),1280,720);else drawBoardHUD(qaCtx,e,spaceCamera(e,e.elapsed),1280,720);`);fs.writeFileSync(root+'/qa134/'+name+'-hud.png',canvas.toBuffer('image/png'));
 console.log(name,scene.length);
}
capture('deck134',`e.beginStage(1);e.beginBoarding();e.board.pos=e.board.terminals[0].map((v,i)=>v+(i===2?6:0));e.board.camera=e.board.pos.slice();e.board.intro=0;e.board.completed=[3];e.board.enemies=[];e.spawnBoardWave(5);`);
capture('mrg134',`e.beginFinale();e.beginMRG();e.finale.open=3;e.finale.shellOpen=1;e.board.pos=[-25,1.45,0];e.finale.openFor=2;`);
