const {run,plain,assert,fs}=require('./campaign-harness.cjs');
run(`function mrgFixture(){const e=new RequirementArcade(417147);e.start(true);e.beginFinale();e.beginMRG();e.finale.attackClock=999;e.board.invulnerable=999;return e}`);
// The jump button should jump, without unexpectedly accelerating horizontal travel.
run('globalThis.e=mrgFixture();e.step(1/60,{moveX:1,boost:true});globalThis.jumpDx=e.board.pos[0]+25');
run('globalThis.walk=mrgFixture();walk.step(1/60,{moveX:1})');
assert(Math.abs(run('jumpDx-(walk.board.pos[0]+25)'))<.001,'Jump must not act as an extra horizontal boost');
const jumps=[];
for(const hz of [25,60]){
 run(`e=mrgFixture();var peak=1;for(var i=0;i<${hz}*2;i++){e.step(1/${hz},{boost:i<${hz}});peak=Math.max(peak,e.board.pos[1])}`);
 assert(run('peak>7.1'),'All raised platforms must be reachable');assert(run('e.board.grounded'));assert.equal(run('e.board.pos[1]'),1);jumps.push({hz,peak:run('peak')});
}
// Buffered input just before touching down must become the next jump.
run('e=mrgFixture();e.board.pos=[-25,1.03,0];e.board.grounded=false;e.board.coyote=0;e.board.vy=-3;e.step(1/60,{boost:true});e.step(1/60,{boost:true})');assert(run('e.board.vy>10'),'Buffer the press just before landing');
// A late jump at the edge must still be accepted briefly.
run('e=mrgFixture();e.board.pos=[-8.99,5,0];e.board.grounded=true;e.step(1/60,{moveX:1});e.step(1/60,{boost:true})');assert(run('e.board.vy>10'),'Allow a short jump grace period at a ledge');
// Damage feedback used to stay white for the rest of the fight.
run('e=mrgFixture();e.board.invulnerable=0;e.mrgDamage(10);for(var i=0;i<60;i++)e.step(1/60,{})');assert.equal(run('e.flash'),0);
// The warning must finish before its attack; every attack exposes the core afterwards.
run('e=mrgFixture();e.finale.attackClock=0;e.step(1/60,{});var warned=e.finale.telegraph;var earlyShots=e.board.hostile.length;for(var i=0;i<30;i++)e.step(1/60,{})');assert(run('warned>=1'));assert.equal(run('earlyShots'),0);assert(!run('e.finale.open'));
run('for(var i=0;i<120;i++)e.step(1/60,{})');assert(run('e.finale.open'));
// Defeat is visible, remains pausable, and awards the upload exactly once.
run('e=mrgFixture();e.finale.mrg.hp=0;e.step(1/60,{});var beforeScore=e.score;e.pause();var frozen=e.finale.defeatTime;e.step(.04,{});');assert.equal(run('e.finale.defeatTime'),run('frozen'));
run('e.resume();for(var i=0;i<210;i++)e.step(1/60,{})');assert.equal(run('e.finale.phase'),'upload');assert.equal(run('e.score-beforeScore'),7000);run('e.beginUpload()');assert.equal(run('e.score-beforeScore'),7000);
// Short tap versus hold; all one-way platforms remain stable and support a drop-through.
run('e=mrgFixture();var tapPeak=1;for(var i=0;i<120;i++){e.step(1/60,{boost:i<3});tapPeak=Math.max(tapPeak,e.board.pos[1])}');assert(run('tapPeak<5'));
for(const x of [-13,1,13]){run(`e=mrgFixture();e.board.pos[0]=${x};for(var i=0;i<150;i++)e.step(1/60,{boost:i<70});var landed=e.board.pos[1];for(var i=0;i<120;i++)e.step(1/60,{})`);assert.equal(run('e.board.pos[1]'),run('landed'));assert(run('landed>1'));run('for(var i=0;i<100;i++)e.step(1/60,{moveZ:1})');assert.equal(run('e.board.pos[1]'),1);}
// Authentic previous-version fixtures: scores and stage survive the update; derived routes rebuild.
const old=JSON.parse(fs.readFileSync('test-support/saves-1.3.2.json','utf8'));
for(const key of ['ground','mrg']){
 run(`globalThis.saved=${JSON.stringify(old[key])};e=cupUnpack(saved,{seed:417147,mode:'calm'},()=>{});`);assert.equal(run('e.score'),12345);
 if(key==='ground'){run('var goal=e.board.terminals[e.board.completed.length];var path=stationPath(e.board,e.board.pos,goal)');assert(run('path.length>0'));}
 else {run('e.board.invulnerable=999;for(var i=0;i<1200;i++)e.step(1/60,{})');assert(run('e.board.pos.every(Number.isFinite)&&Number.isFinite(e.finale.attackClock)&&Number.isFinite(e.board.vy)'));assert.equal(run('e.finale.phase'),'mrg');}
}
fs.writeFileSync('qa133-mrg.json',JSON.stringify({jumps,horizontalSpeedStable:true,jumpBuffer:true,ledgeGrace:true,hitFlashClears:true,readableAttackCycle:true,defeatPauseAndSingleAward:true,variableJumpHeight:true,allPlatformLandingsAndDrops:true,previousVersionSaveCompatibility:true},null,2));
console.log('PASS: responsive jump, ledge grace, landing buffer, stable movement, hit feedback, attack warnings and defeat sequence');
