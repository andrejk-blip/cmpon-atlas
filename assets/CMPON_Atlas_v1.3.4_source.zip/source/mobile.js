/* Mobile navigation, viewport and touch UI. No changes to mission rules or data. */
const MOBILE={menu:false,command:false,commandPaused:false,guideReturn:false,autoFire:false,viewportFrame:0,landscape:null};
function isMobileLayout(){return Number.isFinite(globalThis.innerWidth)?globalThis.innerWidth<=960:!!globalThis.matchMedia?.('(max-width: 960px)').matches}
function mobilePause(){if(ARCADE.engine&&['playing','boarding','docking','crashing'].includes(ARCADE.engine.status)){ARCADE.engine.pause();clearArcadeInput();updateArcadeOverlay();return true}clearArcadeInput();return false}
function setMobileMenu(open,restoreFocus=true){
 MOBILE.menu=!!open&&isMobileLayout();
 if(MOBILE.menu&&MOBILE.command)closeMobileCommand(false);
 document.getElementById('site-rail')?.classList.toggle('menu-open',MOBILE.menu);
 document.body.classList.toggle('mobile-menu-open',MOBILE.menu);
 const toggle=document.getElementById('mobile-menu-toggle');toggle?.setAttribute('aria-expanded',String(MOBILE.menu));document.getElementById('mobile-game-menu')?.setAttribute('aria-expanded',String(MOBILE.menu));
 const backdrop=document.getElementById('mobile-nav-backdrop');if(backdrop)backdrop.hidden=!MOBILE.menu;
 const workspace=document.getElementById('workspace');if(workspace)workspace.inert=MOBILE.menu;
 if(MOBILE.menu){mobilePause();document.querySelector('#nav [aria-current="page"]')?.focus({preventScroll:true})}
 else if(restoreFocus)(document.getElementById(STATE.view==='arcade'&&ARCADE.expanded?'mobile-game-menu':'mobile-menu-toggle')||toggle)?.focus({preventScroll:true});
}
function syncMobileNavigation(){
 const toggle=document.getElementById('mobile-menu-toggle');toggle?.setAttribute('aria-expanded',String(MOBILE.menu));document.getElementById('mobile-game-menu')?.setAttribute('aria-expanded',String(MOBILE.menu));
 document.getElementById('mobile-play')?.setAttribute('aria-label',STATE.view==='arcade'?'Открыть игру «Цитадель ЦСИИ»':'Играть в «Цитадель ЦСИИ»');
}
function mobileNavigate(view){
 setMobileMenu(false,false);MOBILE.command=false;
 if(STATE.view!==view)setView(view,true);
 else if(view==='arcade'&&!ARCADE.expanded)arcadeAction('arcade-expand');
 if(isMobileLayout())globalThis.scrollTo?.({top:0,behavior:'auto'});
 document.getElementById(view==='arcade'?'arcade-pause':'content')?.focus({preventScroll:true});
}
function mobileAction(action,value){
 if(action==='mobile-menu'){setMobileMenu(!MOBILE.menu);return true}
 if(action==='mobile-menu-close'){setMobileMenu(false);return true}
 if(action==='mobile-play'){mobileNavigate('arcade');return true}
 if(action==='mobile-command'){
  if(MOBILE.command){closeMobileCommand(true);return true}
  MOBILE.command=true;MOBILE.commandPaused=mobilePause();
  document.getElementById('arcade-layout')?.classList.add('mobile-command-open');
  document.getElementById('mobile-command-toggle')?.setAttribute('aria-expanded','true');
  document.getElementById('arcade-screen')?.setAttribute('aria-hidden','true');
  const screen=document.getElementById('arcade-screen');if(screen)screen.inert=true;
  document.getElementById('mobile-command-close')?.focus({preventScroll:true});updateMobileArcade();return true;
 }
 if(action==='mobile-guide'){MOBILE.guideReturn=false;
  const e=ARCADE.engine;if(!e)return true;const status=e.status==='paused'?e.resumeStatus:e.status;
  if(status==='boarding'&&e.board){e.board.guide=!e.board.guide;e.board.guideRoute=null}
  else if(status==='playing'){e.autopilot=!e.autopilot;ARCADE.mouse=null}
  updateMobileArcade();return true;
 }
 if(action==='mobile-flight-command'){
  const allowed=['citadel-target','citadel-crystal','arcade-pulse'];if(!allowed.includes(value))return true;
  const e=ARCADE.engine,status=e?.status==='paused'?e.resumeStatus:e?.status;
  if(!['playing','boarding'].includes(status))return true;
  closeMobileCommand(true);if(e.status==='paused')e.resume();
  arcadeAction(value);return true;
 }
 if(action==='mobile-sound'){arcadeAction('arcade-sound');updateMobileArcade();return true}
 if(action==='mobile-autofire'){MOBILE.autoFire=!MOBILE.autoFire;updateMobileArcade();return true}
 return false;
}
function closeMobileCommand(resume){
 const owned=MOBILE.commandPaused;MOBILE.command=false;MOBILE.commandPaused=false;
 document.getElementById('arcade-layout')?.classList.remove('mobile-command-open');
 document.getElementById('mobile-command-toggle')?.setAttribute('aria-expanded','false');
 const screen=document.getElementById('arcade-screen');if(screen){screen.inert=false;screen.setAttribute('aria-hidden','false')}
 if(resume&&owned&&ARCADE.engine?.status==='paused'){ARCADE.engine.resume();updateArcadeOverlay()}
 document.getElementById('mobile-command-toggle')?.focus({preventScroll:true});
}
function placeMobileControls(){
 const screen=document.getElementById('arcade-screen'),touch=document.getElementById('arcade-touch'),field=document.getElementById('arcade-canvas')?.parentElement;
 if(!screen||!touch||!field)return;
 if(isMobileLayout()&&touch.parentElement!==screen)field.insertAdjacentElement?.('afterend',touch);
 else if(!isMobileLayout()&&touch.parentElement!==field)field.appendChild?.(touch);
}
function updateMobileViewport(){
 const height=Math.round(globalThis.visualViewport?.height||globalThis.innerHeight||800);
 document.documentElement?.style?.setProperty?.('--mobile-vh',height+'px');
 const landscape=(globalThis.innerWidth||390)>(globalThis.innerHeight||height),rotated=MOBILE.landscape!==null&&MOBILE.landscape!==landscape;
 MOBILE.landscape=landscape;
 if(!isMobileLayout()){if(MOBILE.menu)setMobileMenu(false,false);if(MOBILE.command)closeMobileCommand(false)}
 if(STATE.view==='arcade'&&ARCADE.canvas){
  if(rotated&&isMobileLayout())mobilePause();
  placeMobileControls();
  if(isMobileLayout()&&!ARCADE.expanded)arcadeAction('arcade-expand');
  ARCADE.overlayToken='';updateArcadeOverlay();resizeArcade();updateMobileArcade();
 }
}
function setupMobile(){
 const hash=globalThis.location?.hash?.slice(1);if(hash==='game'||hash==='arcade')STATE.view='arcade';
 updateMobileViewport();
 const resized=()=>{if(MOBILE.viewportFrame)cancelAnimationFrame(MOBILE.viewportFrame);MOBILE.viewportFrame=requestAnimationFrame(()=>{MOBILE.viewportFrame=0;updateMobileViewport()})};
 globalThis.addEventListener?.('resize',resized);globalThis.visualViewport?.addEventListener('resize',resized);
 globalThis.addEventListener?.('hashchange',()=>{const id=globalThis.location?.hash?.slice(1);if(id==='game'||id==='arcade')mobileNavigate('arcade')});
 document.addEventListener('keydown',ev=>{
  if(MOBILE.command){if(ev.key==='Escape'){ev.preventDefault();mobileAction('mobile-command');return}if(ev.key==='Tab'){const panel=document.getElementById('arcade-mobile-panel'),list=Array.from(panel?.querySelectorAll?.('button,a,input,select')||[]).filter(el=>!el.disabled&&el.getClientRects().length),first=list[0],last=list[list.length-1];if(ev.shiftKey&&document.activeElement===first){ev.preventDefault();last?.focus()}else if(!ev.shiftKey&&document.activeElement===last){ev.preventDefault();first?.focus()}}return}if(!MOBILE.menu)return;if(ev.key==='Escape'){ev.preventDefault();setMobileMenu(false);return}
  if(ev.key==='Tab'){const list=Array.from(document.querySelectorAll('#site-rail a,#site-rail button')).filter(el=>el.getClientRects().length);const first=list[0],last=list[list.length-1];if(ev.shiftKey&&document.activeElement===first){ev.preventDefault();last?.focus()}else if(!ev.shiftKey&&document.activeElement===last){ev.preventDefault();first?.focus()}}
 });
}
function mobileArcadeMarkup(html){
 const actions='<div class="arcade-touch-actions"><button id="arcade-fire-touch" aria-label="Огонь: удерживайте для стрельбы"><svg viewBox="0 0 32 32" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2"><circle cx="16" cy="16" r="8"/><path d="M16 2v8m0 12v8M2 16h8m12 0h8"/><circle cx="16" cy="16" r="2" fill="currentColor"/></svg><small aria-hidden="true">ОГОНЬ</small></button><button data-action="arcade-missile" aria-label="Запустить ракету">РАКЕТА</button><button id="arcade-boost-touch" aria-label="Удерживать для ускорения">ФОРСАЖ</button><button class="desktop-touch-extra" data-action="arcade-pulse">ИМПУЛЬС</button><button class="desktop-touch-extra" data-action="arcade-flip">РАЗВОРОТ</button></div>';
 const toolbox=`<section class="mobile-toolbox" aria-label="Управление игрой"><h3>Управление и радар</h3><p>Игра на паузе. Джойстик — курс, «Огонь» — удерживать для стрельбы. Переключатель «Автокурс» над полем ведёт к цели. В учебном полёте курс восстанавливается после отпускания джойстика. На базе проводник включается только по вашей команде.</p><div class="mobile-tool-grid"><button id="mobile-autofire" data-action="mobile-autofire" aria-pressed="false">Автоогонь</button><button id="mobile-guide" data-action="mobile-guide" aria-pressed="false">Автокурс</button><button id="mobile-target" data-action="mobile-flight-command" data-value="citadel-target">Следующая цель ↗</button><button id="mobile-crystal" data-action="mobile-flight-command" data-value="citadel-crystal">К кристаллу ↗</button><button id="mobile-pulse" data-action="mobile-flight-command" data-value="arcade-pulse">Импульс ↗</button><button id="mobile-sound" data-action="mobile-sound" aria-pressed="true">Звук</button></div><p>↗ — выполнить действие и продолжить бой.</p><div class="mobile-goal-summary"><b id="mobile-goal-title"></b><p id="mobile-goal-detail"></p><small id="mobile-goal-progress"></small></div></section>`;
 return html.replace(/<div class="arcade-touch-actions">[\s\S]*?<\/div>/,actions)
 .replace('<div class="arcade-topline">','<div class="arcade-topline"><button class="mobile-only" id="mobile-game-menu" data-action="mobile-menu" aria-label="Меню атласа" aria-controls="nav" aria-expanded="false">☰</button>')
 .replace('<button data-action="arcade-pause"','<button class="mobile-only" id="mobile-command-toggle" data-action="mobile-command" aria-expanded="false" aria-controls="arcade-mobile-panel">Управление</button><button data-action="arcade-pause"')
 .replace('<aside class="arcade-command">','<aside class="arcade-command" id="arcade-mobile-panel"><button class="mobile-only" id="mobile-command-close" data-action="mobile-command">Вернуться в игру ×</button>'+toolbox);
}
function mobileOverlayMarkup(html,e){
 if(!isMobileLayout())return html;
 if(['lesson','remark','finalcheck'].includes(e.status))return html;
 html=mobileFriendlyText(html);
 html=html.replaceAll('Поток замечаний → перехватить пробелом','Поток замечаний → кнопка «Огонь»').replaceAll('G ведёт к отмеченной цели. WASD — ручной курс.','«Автокурс» ведёт к цели. Джойстик включает ручное управление.').replaceAll('C — курс на кристалл.','«К кристаллу» — в панели «Управление».').replaceAll('Пробел — огонь · Tab — сменить угрозу','«Огонь» — стрельба · «Цель» — сменить угрозу').replaceAll('WASD — манёвр · G — автокурс · ПКМ / Q — ракета.','Джойстик — манёвр · «Автокурс» — помощь · «Ракета» — пуск.').replaceAll('E рассеивает снаряды','«Импульс» рассеивает снаряды');
 if(['menu','briefing','paused'].includes(e.status))html=html.replace(/(<button class="(?:arcade-play|arcade-secondary)"[^>]*data-action="(?:arcade-start|citadel-launch|arcade-resume)"[\s\S]*?<\/button>)/,'$1<p class="mobile-controls-help">Слева — джойстик. Справа — огонь, ракета и форсаж. Кнопки находятся за пределами игрового поля. Автокурс включён при вылете. В учебном режиме отпустите джойстик — автокурс вернётся. Автоогонь и радар — в «Управлении».</p>');
 if(['menu','briefing','paused'].includes(e.status))html=html.replace('<p class="mobile-controls-help">','<div class="mobile-orientation-hint"><span aria-hidden="true">↻</span><div><b>Удобнее горизонтально</b><small>Поверните телефон — поле станет шире. Вертикально тоже можно играть.</small></div></div><p class="mobile-controls-help">');
 return html;
}
function mountMobileArcade(){
 MOBILE.command=false;MOBILE.commandPaused=false;placeMobileControls();
 if(isMobileLayout()&&!ARCADE.expanded)arcadeAction('arcade-expand');
 const field=ARCADE.canvas?.parentElement;
 if(field&&globalThis.ResizeObserver){ARCADE.mobileObserver?.disconnect();ARCADE.mobileObserver=new ResizeObserver(resizeArcade);ARCADE.mobileObserver.observe(field)}
 updateMobileArcade();
}
function mobileFriendlyText(text){
 return String(text).replaceAll('Двигайся WASD. Если нужна помощь с маршрутом — нажми G или «Вести к терминалу». Проводник сейчас выключен.','Двигайся джойстиком. «Проводник» над полем ведёт к терминалу; включается по твоей команде.').replaceAll('G ведёт к замечанию · Tab меняет цель · C ведёт к кристаллу.','«Автокурс» — к замечанию. Смена цели и кристаллы — в панели «Управление».')
 .replaceAll('WASD — ручной курс; G — автокурс.','Джойстик — ручной курс; «Автокурс» — помощь.').replaceAll('WASD — движение.','Джойстик — движение.')
 .replaceAll('Пробел — перехват, E — импульс, G — проводник.','«Огонь» — перехват, «Проводник» — маршрут. Импульс — в панели «Управление».')
 .replaceAll('G включает проводник к шлюзу следующей редакции.','«Проводник» ведёт к шлюзу следующей редакции.')
 .replaceAll('G — автокурс.','«Автокурс» — автокурс.').replaceAll('Q — ракета · E — импульс вблизи.','«Ракета» — пуск; импульс — в панели «Управление».')
 .replaceAll('F — стыковка вблизи; G — довести автоматически.','У шлюза стыковка начнётся сама; «Автокурс» поможет добраться.')
 .replaceAll('золотая дорожка → терминал → F','золотая дорожка → терминал → разбор').replaceAll('Пробел — огонь','«Огонь» — стрельба').replaceAll(': пробел',': «Огонь»');
}
function updateMobileArcade(){
 const e=ARCADE.engine;if(!e)return;
 const screen=document.getElementById('arcade-screen');if(screen)screen.dataset.gameStatus=e.status;
 const inside=citadelInside(e),status=e.status==='paused'?e.resumeStatus:e.status,active=['playing','boarding'].includes(status);
 const auto=document.getElementById('mobile-autofire');if(auto){auto.setAttribute('aria-pressed',String(MOBILE.autoFire));auto.textContent=MOBILE.autoFire?'Автоогонь включён':'Автоогонь выключен'}
 const guide=document.getElementById('mobile-guide');if(guide){const on=inside?!!e.board?.guide:!!e.autopilot;guide.disabled=!active;guide.setAttribute('aria-pressed',String(on));guide.textContent=(inside?'Проводник':'Автокурс')+(on?' включён':' выключен')}
 spaceAudioControls();const sound=document.getElementById('mobile-sound');if(sound){sound.setAttribute('aria-pressed',String(ARCADE.sound));sound.textContent=ARCADE.sound?'Звук включён':'Звук выключен'}
 for(const id of ['mobile-target','mobile-crystal','mobile-pulse']){const button=document.getElementById(id);if(button)button.disabled=!active||(id!=='mobile-pulse'&&status!=='playing')||(id==='mobile-crystal'&&(e.phase==='escort'||!e.modules().some(p=>!p.dead)))}
 const goal=e.objective();for(const [id,text]of [['mobile-goal-title',goal.title],['mobile-goal-detail',goal.detail],['mobile-goal-progress',goal.progress]]){const el=document.getElementById(id);if(el)el.textContent=mobileFriendlyText(text)}
 const close=document.getElementById('mobile-command-close');if(close)close.textContent=MOBILE.commandPaused?'Продолжить игру ×':'Закрыть панель ×';
 if(isMobileLayout()){
  const primary=document.getElementById('citadel-primary');if(primary){const on=inside?!!e.board?.guide:!!e.autopilot;primary.textContent=(inside?'Проводник':'Автокурс')+(on?' ✓':' ○');primary.setAttribute('aria-pressed',String(on));primary.setAttribute('aria-label',(inside?'Проводник к терминалу или выходу':'Автокурс к текущей цели')+': '+(on?'включён. Выключить':'выключен. Включить'))}
  const title=document.getElementById('citadel-objective-title');if(title)title.textContent=mobileFriendlyText(title.textContent).replace('Перехватите отмеченное замечание: «Огонь»','Перехватите замечание').replace('Соберите зелёный кристалл впереди','Соберите зелёный кристалл');
  const captain=document.getElementById('captain-message');if(captain)captain.textContent=mobileFriendlyText(captain.textContent);
  const detail=document.getElementById('citadel-objective-detail');if(detail)detail.textContent=mobileFriendlyText(detail.textContent);
  ARCADE.canvas?.setAttribute('aria-label','Игровое поле. Управление вынесено за его пределы: джойстик слева, огонь и ракеты справа.');
 }
}
function drawMobileGameHUD(c,e,cam,w,h){
 c.clearRect(0,0,w,h);const cssW=ARCADE.canvas?.getBoundingClientRect().width||w,scale=w/cssW,W=w/scale,H=h/scale,p=e.player;
 c.save();c.scale(scale,scale);c.textBaseline='middle';c.font='12px Arial';
 if(['menu','briefing','lesson','remark','paused','stageclear','won','lost','escortclear'].includes(e.status)){c.restore();return}
 const inside=citadelInside(e),hp=inside?(e.board.hp??p.hp):p.hp;
 c.fillStyle='#061727ce';c.fillRect(6,6,Math.min(228,W-12),30);c.fillStyle=hp<30?'#ff9d8d':'#d0fff0';c.font='bold 11px Arial';c.fillText('ЩИТ '+Math.ceil(hp)+'%',13,17);c.fillStyle='#ffe0a4';c.fillText('РАКЕТЫ '+p.missiles,94,17);c.fillStyle='#9bb9c9';c.font='10px Arial';c.fillText('ЭН '+Math.ceil(p.energy)+'%',172,17);c.fillStyle='#37596a';c.fillRect(13,28,206,2);c.fillStyle=hp<30?'#ff9d8d':'#8ee1c4';c.fillRect(13,28,206*Math.max(0,hp)/100,2);
 function mark(pos,label,color,offscreen=false){
  const q=spaceProject(pos,cam,W,H),margin=20,top=48,bottom=Math.max(top,H-24);let px=q.x,py=q.y;
  const edge=q.z<=0||px<margin||px>W-margin||py<top||py>bottom;
  if(edge){if(!offscreen)return;const d=V3.sub(pos,cam.pos),dx=V3.dot(d,cam.r),dy=-V3.dot(d,cam.u),a=Math.atan2(dy||.1,dx||.1);px=W/2+Math.cos(a)*Math.max(8,W/2-margin);py=(top+bottom)/2+Math.sin(a)*Math.max(8,(bottom-top)/2);c.save();c.translate(px,py);c.rotate(a);c.fillStyle=color;c.beginPath();c.moveTo(7,0);c.lineTo(-5,-5);c.lineTo(-5,5);c.closePath();c.fill();c.restore()}
  else{c.strokeStyle=color;c.lineWidth=1.5;c.strokeRect(px-8,py-8,16,16)}
  c.fillStyle=color;c.font='bold 10px Arial';c.textAlign=px<W/2?'left':'right';c.fillText(label,px+(px<W/2?10:-10),Math.max(top,py-15));c.textAlign='left';
 }
 if(inside&&e.board){const b=e.board;for(const enemy of b.enemies||[])if(!enemy.dead)mark(enemy.pos,'', '#ffb1a1');const idx=b.completed.length;if(idx<3)mark(b.terminals[idx],'ТЕРМИНАЛ '+(idx+1),'#ffe2a4',true);else mark(b.exit,'ВЫХОД','#9bf1c3',true)}
 else{
  const basis=flightBasis(p.yaw,p.pitch),aim=spaceProject(V3.add(p.pos,V3.scale(basis.f,130)),cam,W,H);c.strokeStyle=e.lock?'#ffe0a4':'#d0eef0';c.lineWidth=1.5;for(const d of [-1,1]){arcadeLine(c,aim.x+d*7,aim.y,aim.x+d*16,aim.y);arcadeLine(c,aim.x,aim.y+d*7,aim.x,aim.y+d*16)}
  const module=(e.pickups||[]).filter(item=>!item.dead&&item.type==='requirement').sort((a,b)=>V3.len(V3.sub(a.pos,p.pos))-V3.len(V3.sub(b.pos,p.pos)))[0];if(module&&(['orientation','retrieve'].includes(e.phase)||e.navMode==='module'))mark(module.pos,'ФТ · '+Math.round(V3.len(V3.sub(module.pos,p.pos)))+' м','#9cf6cf',true);
  const target=e.enemies.find(x=>!x.dead&&(x.id===e.selectedTarget||x.id===e.lock))||e.boss;if(target)mark(target.pos,'ЦЕЛЬ','#ffbfad',true);
 }
 if(e.phase==='escort'&&e.escort){const escort=e.escort;c.fillStyle='#091b2bea';c.fillRect(6,39,Math.min(264,W-12),24);c.fillStyle='#caeee5';c.font='bold 11px Arial';c.fillText('КОНВОЙ '+Math.round(escort.distance*100)+'%  ·  СОЮЗНИКИ '+escort.allies.filter(a=>!a.dead).length+'/3',13,51)}
 if(e.status==='crashing'||e.status==='docking'){c.fillStyle='#061727bb';c.fillRect(0,H*.36,W,62);c.fillStyle=e.status==='crashing'?'#ffb9a6':'#caedf0';c.font='bold 20px Arial';c.textAlign='center';c.fillText(e.status==='crashing'?'АВАРИЙНАЯ ЭВАКУАЦИЯ':'ЗАХОД В ЦИТАДЕЛЬ',W/2,H*.36+31)}
 c.restore();
}
