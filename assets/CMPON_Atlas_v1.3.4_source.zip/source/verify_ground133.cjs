const {run,plain,assert,fs}=require('./campaign-harness.cjs');
run(`function groundFixture(stage=2){const e=new RequirementArcade(417147);e.start(true);e.beginStage(Math.min(3,stage));if(stage===4){e.beginFinale();e.beginLair()}else e.beginBoarding();e.board.enemies=[];for(const d of e.board.doors)d.open=1;return e}`);
const positions=[{stage:2,p:[9.5219810269773,0,-66.10789753869176]},{stage:4,p:[40.3363865185529,0,-86.68691889662296]},{stage:4,p:[40.15879019536078,0,-129.23515363503247]},{stage:4,p:[32.56980038434267,0,-69.16488843690604]}];
const results=[];
for(const fixture of positions){
 run(`globalThis.e=groundFixture(${fixture.stage});e.board.pos=${JSON.stringify(fixture.p)};e.board.camera=e.board.pos.slice();e.board.guide=true;`);
 assert(run('stationWalkable(e.board,e.board.pos,.65)'),'Fixture is a valid player position');
 assert(run('stationPath(e.board,e.board.pos,e.board.terminals[0]).length>0'),'A traversable side corridor needs a route: '+fixture.stage);
 run(`var stalled=0,maxStalled=0;for(var i=0;i<60*100&&e.status==='boarding';i++){const old=e.board.pos.slice();e.step(1/60,{});if(V3.len(V3.sub(old,e.board.pos))<.001)stalled+=1/60;else stalled=0;maxStalled=Math.max(maxStalled,stalled)}`);
 assert(['remark','finalcheck'].includes(run('e.status')),'Pioneer must reach a terminal from a side corridor');assert(run('maxStalled<2'));
 results.push({...fixture,seconds:run('e.board.time'),maxStalled:run('maxStalled')});
}
// An empty/stale cached route must recover without toggling the guide or reloading.
run(`e=groundFixture(0);e.board.guide=true;e.board.guideRoute=[];e.board.guideGoal=0;for(var i=0;i<60*15&&e.status==='boarding';i++)e.step(1/60,{})`);assert.equal(run('e.status'),'remark');
// The user's guide choice survives a review; new landings still wait for input.
run('e.answer(citadelRemarkCase(e,e.board.question).correct);e.continueRemark()');assert(run('e.board.guide'));
run('e.beginBoarding();var initial=e.board.pos.slice();for(var i=0;i<60;i++)e.step(1/60,{})');assert(!run('e.board.guide'));assert.deepStrictEqual(plain(run('e.board.pos')),plain(run('initial')));
fs.writeFileSync('qa133-ground.json',JSON.stringify({sideCorridors:results,emptyRouteRecovery:true,guideChoicePreserved:true,manualLanding:true},null,2));
console.log('PASS: narrow side corridors, stale empty route, guide choice and manual landing');
