const h=require('./campaign-harness.cjs'),baseline=require('./test-support/review-contract-1.3.3.json');
const {run,plain,assert,fs,root,node,context,event}=h;
fs.mkdirSync(root+'/qa134',{recursive:true});
run(`ARCADE.sound=false;ARCADE.fx=false;ARCADE.forceCPU=true;initialize();globalThis.e=new RequirementArcade(417147);e.start(true);ARCADE.engine=e;`);
let comparisons=0;const samples=[],seen=new Set();
for(let seed=0;seed<30;seed++)for(const kind of ['lesson','remark'])for(let i=0;i<(kind==='lesson'?8:12);i++){
 const call=(kind==='lesson'?'citadelLessonCase':'citadelRemarkCase')+'({seed:'+seed+',caseBank:1},'+i+')',q=plain(run(call)),before=baseline.cases[kind+'.'+seed+'.'+i];
 assert.deepStrictEqual(q.choices,before.choices,'Active cup answer text/order');assert.equal(q.correct,before.correct);assert.equal(q.decision,before.decision);comparisons++;
 assert(q.outcome.title&&q.outcome.before&&q.outcome.after&&q.outcome.label);assert.equal(q.sourceKind,'synthetic');assert(Number.isInteger(q.origin));
 if(seen.has(q.caseId))continue;seen.add(q.caseId);
 run(`e=new RequirementArcade(${seed});e.start(true);e.beginStage(${Math.floor(i/(kind==='lesson'?2:3))});ARCADE.engine=e;`);
 if(kind==='lesson')run(`e.launch();e.lesson={reqId:e.plan[e.stage][${i%2?2:0}],caseIndex:${i},stage:e.stage,readClock:0,attempts:0,feedback:null,solved:false};e.status='lesson';`);
 else run(`e.beginBoarding();e.board.question=${i};e.status='remark';`);
 const question=run('citadelReviewHTML(e)');assert(!/FT-\d/.test(question),'No random FT attribution in case');assert(question.includes(q.caseId));
 samples.push({id:q.caseId,kind,view:'question',html:question,q});
 const method=kind==='lesson'?'answerLesson':'answer';assert(run(`e.${method}(${q.correct})`));
 const score=run('e.score'),count=run('citadelResolvedCases(e).length');assert(!run(`e.${method}(${q.correct})`));assert.equal(run('e.score'),score);assert.equal(run('citadelResolvedCases(e).length'),count);
 const result=run('citadelReviewHTML(e)');assert(result.includes('СТАЛО В УЧЕБНОМ ПАКЕТЕ'));assert(result.includes(q.outcome.after));assert(!/data-action="(?:citadel-answer|citadel-lesson-answer)"/.test(result));
 samples.push({id:q.caseId,kind,view:'result',html:result,q});
}
assert.equal(seen.size,60);
for(let n=0;n<3;n++){const seed=Array.from({length:20},(_,i)=>i).find(x=>run(`citadelVariantIndex({seed:${x}},10)===${n}`));assert.equal(run(`citadelRemarkCase({seed:${seed},caseBank:1},2).resolution`),'linked')}
for(const [kind,i,phrase,origin]of [['lesson',0,'Менеджер',2],['lesson',6,'ФЗ предложил',0]]){
 let q;for(let seed=0;seed<20;seed++){const c=plain(run(`citadelLessonCase({seed:${seed},caseBank:1},${i})`));if(c.situation.includes(phrase))q=c}assert.equal(q.origin,origin);
}
for(let i=0;i<3;i++){
 run(`e=new RequirementArcade(417147);e.start(true);e.beginFinale();e.finale.phase='landing';e.beginBoarding();e.board.completed=Array.from({length:${i}},(_,i)=>i);e.finale.tests=e.board.completed.slice();e.status='finalcheck';ARCADE.engine=e;`);
 const q=plain(run(`citadelFinalCase(${i})`));samples.push({id:q.caseId,kind:'final',view:'question',html:run('citadelReviewHTML(e)'),q});
 run(`e.answerFinale(${(q.correct+1)%3})`);assert(run('citadelReviewHTML(e)').includes('Пакет не изменён'));run('e.continueFinaleCheck()');assert.equal(run('e.board.completed.length'),i);
 run(`e.answerFinale(${q.correct})`);samples.push({id:q.caseId,kind:'final',view:'result',html:run('citadelReviewHTML(e)'),q});
 const prior=run('e.score');run('e.continueFinaleCheck()');assert.equal(run('e.score'),prior+700);assert.equal(run('e.finale.tests.length'),i+1);assert.equal(run('e.toast.title'),q.outcome.title);
}
// The review expands to the viewport, but cannot bleed into the records panel.
run(`e.beginStage(0);e.beginBoarding();e.board.question=0;e.status='remark';ARCADE.overlayToken='';updateArcadeOverlay()`);assert(node('arcade-overlay').classList.contains('review-open'));
run(`CUP.panel='records';CUP.uiRevision++;updateArcadeOverlay()`);assert(!node('arcade-overlay').classList.contains('review-open'));run(`CUP.panel='';ARCADE.overlayToken='';updateArcadeOverlay()`);assert(node('arcade-overlay').classList.contains('review-open'));
run(`e.status='boarding';ARCADE.overlayToken='';updateArcadeOverlay()`);assert(!node('arcade-overlay').classList.contains('review-open'));
const report=run(`e.completedRemarks=[2];citadelDecisionReport(e,true)`);assert(report.includes('Связано с исходным решением'));assert(!report.includes('<table'));
// Readability edits do not touch colliders, camera or enemy attributes except color.
const drones=plain(run('CITADEL_DRONES')),beforeDrones=JSON.parse(JSON.stringify(baseline.drones));
for(const k of Object.keys(drones)){delete drones[k].color;delete beforeDrones[k].color}assert.deepStrictEqual(drones,beforeDrones);
assert.equal(require('crypto').createHash('sha256').update(fs.readFileSync(root+'/data.json')).digest('hex'),baseline.dataSha256);
fs.writeFileSync(root+'/qa134/review-samples.json',JSON.stringify(samples,null,2));
const result={version:'1.3.4',cases:60,finalChecks:3,answerContractComparisons:comparisons,randomFTAttributionRemoved:true,duplicateResolutionLinked:true,authorCorrections:true,wrongAnswerDoesNotCommit:true,repeatedAnswerNoExtraReward:true,viewportReviewIsolation:true,recordsPanelIsolation:true,sourceFTUnchanged:true,enemyStatsUnchanged:true};
fs.writeFileSync(root+'/qa134/reviews.json',JSON.stringify(result,null,2));console.log(result);
