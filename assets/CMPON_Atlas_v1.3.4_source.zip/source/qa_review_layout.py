"""Offline CSS layout QA (WeasyPrint). Not a browser or physical device test.
Media queries are selected explicitly because this renderer targets paged media.
Only viewport placement is adapted; review and global application rules are real.
"""
import json,re,logging,sys
from pathlib import Path
import tinycss2
from weasyprint import HTML
import build
logging.getLogger('weasyprint').setLevel(logging.ERROR)
ROOT=Path(__file__).resolve().parent
samples=json.loads((ROOT/'qa134/review-samples.json').read_text())
rules=tinycss2.parse_stylesheet('\n'.join((ROOT/f).read_text() for f in build.CSS),skip_comments=True,skip_whitespace=True)
def matches(q,w,h):
 for part in q.split(','):
  if re.search(r'\bprint\b|prefers-reduced-motion|hover:',part):continue
  ok=True
  for side,key,num in re.findall(r'\((min|max)-(width|height):\s*(\d+)px\)',part):
   v=w if key=='width' else h;ok&=v>=int(num) if side=='min' else v<=int(num)
  if 'orientation:portrait' in part:ok&=h>=w
  if 'orientation:landscape' in part:ok&=w>h
  if ok:return True
 return False
def css_for(items,w,h):
 out=[]
 for rule in items:
  if rule.type=='at-rule' and rule.lower_at_keyword=='media':
   if matches(tinycss2.serialize(rule.prelude),w,h):out.append(css_for(tinycss2.parse_rule_list(rule.content,skip_whitespace=True,skip_comments=True),w,h))
  elif rule.type=='qualified-rule':out.append(tinycss2.serialize([rule]))
 return '\n'.join(out)
def render(sample,w,h):
 inset=5 if w<=600 or h<=600 else 12
 css=css_for(rules,w,h)+f'''\n@page{{size:{w}px {h}px;margin:0}}html,body{{padding:0!important;margin:0;width:{w}px;height:{h}px;background:#071521}}.arcade-layout #arcade-overlay.review-open{{display:block!important;position:absolute!important;inset:auto!important;left:{inset}px!important;top:{inset}px!important;right:auto!important;bottom:auto!important;width:{w-2*inset}px!important;height:{h-2*inset}px!important;}}'''
 css=css.replace('var(--mobile-vh)',str(h)+'px').replace('var(--mobile-nav-height)','48px')
 source='<html lang="ru"><meta charset="utf-8"><style>'+css+'</style><body><div class="arcade-layout"><div id="arcade-overlay" class="arcade-overlay review-open">'+sample['html']+'</div></div></body></html>'
 doc=HTML(string=source,base_url=str(ROOT),media_type='screen').render()
 # Parent boxes, not line fragments, establish element geometry.
 boxes=[]
 for b in doc.pages[0]._page_box.descendants():
  el=b.element
  if el is None:continue
  if el.tag=='button' and b.__class__.__name__ in ['FlexBox','BlockBox','GridBox']:
   boxes.append({'x':round(b.border_box_x(),2),'y':round(b.border_box_y(),2),'w':round(b.border_width(),2),'h':round(b.border_height(),2),'action':el.get('data-action'),'text':' '.join(el.itertext())})
 bad=[b for b in boxes if b['x']<0 or b['x']+b['w']>w+.5 or b['y']<0 or b['y']+b['h']>h+.5 or b['h']<30]
 return doc,{'id':sample['id'],'view':sample['view'],'viewport':[w,h],'pages':len(doc.pages),'buttons':boxes,'bad':bad}
# Longest prompt/answer, longest result for each location and the three finale checks.
selected=[]
for kind in ['lesson','remark','final']:
 for view in ['question','result']:
  subset=[s for s in samples if s['kind']==kind and s['view']==view]
  selected.extend(sorted(subset,key=lambda s:len(re.sub('<[^>]+>','',s['html'])),reverse=True)[:3])
selected=list({(x['id'],x['view']):x for x in selected}.values())
viewports=[(1440,900),(390,744),(320,568),(844,390),(568,320)]
rows=[]
for w,h in viewports:
 for n,s in enumerate(selected):
  doc,row=render(s,w,h);rows.append(row)
  if n in [0,3,6,9,12,15]:doc.write_pdf(ROOT/f'qa134/card-{w}x{h}-{s["id"]}-{s["view"]}.pdf')
summary={'engine':'WeasyPrint 70, offline CSS layout; browser not tested','cases':len(rows),'overflow':sum(bool(r['bad']) for r in rows),'rows':rows}
(ROOT/'qa134/layout.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='rows'}))
for row in rows:
 if row['bad']:print(row['id'],row['view'],row['viewport'],row['bad'])
