/* Regression model: innerHTML replacement really disconnects inputs and drops focus.
   Virtual keyboard events are simulated; this is not a physical Safari test. */
const path=require('path');
const h=require(path.join(process.env.CMPON_INPUT_TEST_SOURCE||__dirname,'campaign-harness.cjs'));
const {run,context,assert,node,doc,listeners,event,frames,globalEvents,fs,root}=h;
(async()=>{
 context.innerWidth=390;context.innerHeight=844;context.location={protocol:'file:',hash:'#arcade'};
 const viewportEvents={};context.visualViewport={height:844,addEventListener(k,fn){viewportEvents[k]=fn}};
 doc.documentElement={style:{setProperty(k,v){this[k]=v}}};
 const overlay=node('arcade-overlay'),inputs=new Map();let markup='',writes=0;
 const decode=s=>s.replaceAll('&quot;','"').replaceAll('&#39;',"'").replaceAll('&lt;','<').replaceAll('&gt;','>').replaceAll('&amp;','&');
 Object.defineProperty(overlay,'innerHTML',{get(){return markup},set(html){
  markup=html;writes++;
  for(const input of inputs.values()){input.isConnected=false;if(doc.activeElement===input)doc.activeElement=doc.body;}
  inputs.clear();
  for(const match of html.matchAll(/<input\b[^>]*>/g)){
   const id=match[0].match(/id="([^"]+)"/)?.[1];if(!['cup-name','cup-new-name'].includes(id))continue;
   const input={id,tagName:'INPUT',value:decode(match[0].match(/value="([^"]*)"/)?.[1]||''),isConnected:true,selectionStart:0,selectionEnd:0,
    focus(){doc.activeElement=this},setSelectionRange(a,b){this.selectionStart=a;this.selectionEnd=b}};
   inputs.set(id,input);
  }
 }});
 doc.getElementById=id=>['cup-name','cup-new-name'].includes(id)?inputs.get(id)||null:node(id);
 doc.querySelector=s=>s.startsWith('#cup-')?doc.getElementById(s.slice(1)):null;
 run("STATE.view='arcade';ARCADE.engine=new RequirementArcade(417147);ARCADE.canvas=document.getElementById('arcade-canvas');ARCADE.expanded=true;setupTournament();setupMobile();");
 context.location.protocol='https:';run("ARCADE.overlayToken='';updateArcadeOverlay();");
 let input=inputs.get('cup-name');assert(input,'online name form rendered');input.focus();
 const frame=()=>{const callbacks=[...frames.values()];frames.clear();callbacks.forEach(f=>f(1));};
 const resize=(height,layoutHeight=context.innerHeight)=>{context.visualViewport.height=height;context.innerHeight=layoutHeight;globalEvents.resize();viewportEvents.resize();frame();};
 const stable=(expected=input)=>{assert.strictEqual(inputs.get(expected.id),expected,'resize must retain the exact input node');assert.strictEqual(doc.activeElement,expected,'keyboard focus must remain');assert(expected.isConnected);};
 const initialWrites=writes;
 for(const height of [810,660,510,420,344]){resize(height);stable();}
 assert.equal(writes,initialWrites,'opening keyboard must not replace the overlay');
 assert.equal(doc.documentElement.style['--mobile-vh'],'344px','visible height still updates');
 input.value='Андрей «Орбита» 🚀';event('input',{target:input});input.setSelectionRange(7,13);
 for(const height of [320,360,344]){resize(height,height);stable();run('cupRefreshUI();updateArcadeOverlay();');stable();}
 assert.equal(run('MOBILE.landscape'),false,'keyboard height is not device rotation');
 assert.equal(input.value,'Андрей «Орбита» 🚀');assert.equal(input.selectionStart,7);assert.equal(input.selectionEnd,13);
 event('compositionstart',{target:input});input.value='Андрей 王';event('input',{target:input,isComposing:true});resize(330);stable();event('compositionend',{target:input});
 // A pending redraw or autofill must not tear out the active editor.
 input.value='Пилот "ЦСИИ"';run("ARCADE.overlayToken='';updateArcadeOverlay();");stable();
 assert.equal(run('CUP.nameDraft'),input.value,'autofill value captured before deferred redraw');
 // Rotate with the keyboard open, then cross the responsive breakpoint.
 context.screen={orientation:{type:'landscape-primary'}};context.innerWidth=844;resize(210,390);stable();
 assert.equal(run('MOBILE.landscape'),true);
 context.innerWidth=1024;resize(510,768);stable();context.innerWidth=844;resize(210,390);stable();
 context.screen.orientation.type='portrait-primary';context.innerWidth=390;resize(344,844);stable();
 // Blur may permit deferred redraw, but draft text must survive keyboard closing.
 event('focusout',{target:input});doc.activeElement=doc.body;resize(844,844);
 assert.equal(inputs.get('cup-name').value,'Пилот "ЦСИИ"');
 // Real form submit/rename handlers; local service only, no public records.
 const calls=[];let player=null,failEntry=true,failRename=false,saveRevision=0;
 context.fetch=async(url,o={})=>{
  const p=String(url).split('/api/tournament/')[1],body=o.body?JSON.parse(o.body):null;calls.push({p,body});
  const ok=d=>new Response(JSON.stringify(d),{status:200});
  if(p==='enter'){if(failEntry)return new Response(JSON.stringify({error:'Не удалось подключиться'}),{status:503});player={id:'local-mobile-pilot',name:body.name};return ok({player,token:'local-test-token'});}
  if(p==='config')return ok({cups:[{id:'local-cup',title:'Локальный тест',state:'active',mode:'calm',seed:417147,endsAt:1793566800000}],gameVersion:'1.3.0'});
  if(p==='me')return ok({player,runs:[]});
  if(p==='start')return ok({run:{id:'local-run',playerId:player.id,cupId:'local-cup',mode:'calm',seed:417147,progress:0,revision:0,clock:0,status:'active',gameVersion:'1.3.0'}});
  if(p==='save')return ok({run:{revision:++saveRevision}});
  if(p==='profile'){if(failRename)return new Response(JSON.stringify({error:'Проверьте имя и повторите'}),{status:400});player={...player,name:body.name};return ok({player});}
  throw Error('Unexpected route '+p);
 };
 context.FormData=class{constructor(form){this.value=inputs.get(form.id==='cup-entry-form'?'cup-name':'cup-new-name').value;}get(){return this.value;}};
 const submit=async id=>{const button={disabled:false};await listeners.submit.at(-1)({target:{id,querySelectorAll:()=>[button]},preventDefault(){}});assert(!button.disabled);};
 input=inputs.get('cup-name');input.focus();await submit('cup-entry-form');stable();assert.equal(input.value,'Пилот "ЦСИИ"');assert(node('cup-message').textContent.includes('Не удалось'));
 failEntry=false;await submit('cup-entry-form');await run('cupFlush()');
 assert.equal(run('CUP.player.name'),'Пилот "ЦСИИ"');assert.equal(run('CUP.run.id'),'local-run');assert.equal(calls.filter(c=>c.p==='enter').length,2);assert.equal(calls.filter(c=>c.p==='start').length,1);
 run("cupOpenPanel('rename');");input=inputs.get('cup-new-name');assert.equal(doc.activeElement,input);
 input.value='Капитан <ЦСИИ>';event('input',{target:input});input.setSelectionRange(8,14);
 for(const height of [620,400,280]){resize(height,height);run('cupRefreshUI();updateArcadeOverlay();');stable();}
 assert.equal(input.selectionStart,8);assert.equal(input.selectionEnd,14);
 await run('cupRefresh()');stable();assert.equal(input.value,'Капитан <ЦСИИ>','profile refresh preserves rename draft');
 failRename=true;await submit('cup-rename-form');stable();assert.equal(input.value,'Капитан <ЦСИИ>');assert(node('cup-message').textContent.includes('Проверьте'));
 // Blur/autofill/change and a later redraw keep the edited name, not the old profile.
 input.value='Капитан Автозаполнение';event('change',{target:input});event('focusout',{target:input});doc.activeElement=doc.body;run('cupRefreshUI();');
 input=inputs.get('cup-new-name');assert.equal(input.value,'Капитан Автозаполнение');input.focus();
 failRename=false;await submit('cup-rename-form');await run('cupFlush()');
 assert.equal(run('CUP.player.name'),'Капитан Автозаполнение');assert.equal(run('CUP.run.id'),'local-run');assert.equal(run('CUP.panel'),null);
 run("cupOpenPanel('rename');");assert.equal(inputs.get('cup-new-name').value,'Капитан Автозаполнение');
 input=inputs.get('cup-new-name');input.value='Не сохранять';event('input',{target:input});run("cupClosePanel();cupOpenPanel('rename');");assert.equal(inputs.get('cup-new-name').value,'Капитан Автозаполнение','cancel does not rename player');
 run('cupClosePanel();');doc.activeElement=doc.body;
 // Legacy iOS orientation and no orientation API: height-only changes never fake a turn.
 delete context.screen;context.orientation=0;context.innerWidth=390;resize(300,300);assert.equal(run('MOBILE.landscape'),false);
 context.orientation=90;context.innerWidth=844;resize(210,390);assert.equal(run('MOBILE.landscape'),true);
 delete context.orientation;context.innerWidth=390;resize(844,844);resize(280,280);assert.equal(run('MOBILE.landscape'),false);
 const report={app_version:'1.3.5',baseline:'1.3.4 fails on first keyboard resize (input node replaced)',keyboardResizeRetainsNodeAndFocus:true,caretSelectionPreserved:true,cyrillicEmojiQuotesAndComposition:true,autofillDrafts:true,rotationAndBreakpointWithKeyboard:true,keyboardDoesNotImpersonateRotation:true,backgroundProfileRefreshDuringRename:true,entryNetworkErrorRetainsFocusAndDraft:true,formSubmitStartsOneRun:true,renameValidationRetainsFocusAndDraft:true,renameSuccessKeepsRun:true,cancelRename:true,realBrowserQA:false,physicalIPhoneQA:false,publicRecordsAdded:false};
 fs.mkdirSync(root+'/qa135',{recursive:true});fs.writeFileSync(root+'/qa135/name-input.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));
})().catch(e=>{console.error(e);process.exitCode=1});
