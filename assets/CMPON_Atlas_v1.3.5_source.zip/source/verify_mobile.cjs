const {fs,assert,root,run,plain,node,event,context,doc,createCanvas}=require('./campaign-harness.cjs');
context.innerWidth=390;context.innerHeight=844;context.visualViewport={height:844,addEventListener(){}};context.location={hash:'#game',protocol:'file:'};context.scrollTo=()=>{};
doc.documentElement={style:{setProperty(k,v){this[k]=v}}};
// Minimal parent/child model checks real reparenting code, not just string presence.
const field=node('mobile-field'),screen=node('arcade-screen'),touch=node('arcade-touch');
field.parentElement=screen;touch.parentElement=field;node('arcade-canvas').parentElement=field;
field.insertAdjacentElement=(where,el)=>{assert.equal(where,'afterend');el.parentElement=field.parentElement};
field.appendChild=el=>{el.parentElement=field};
node('arcade-canvas').getBoundingClientRect=()=>({left:0,top:0,width:390,height:460});
run('ARCADE.sound=false;ARCADE.forceCPU=true;initialize()');
assert.equal(run('STATE.view'),'arcade','Direct #game entry');assert(run('ARCADE.expanded'));assert(node('arcade-layout').classList.contains('is-expanded'));
assert(node('content').innerHTML.includes('id="mobile-autofire"'));assert(node('content').innerHTML.includes('id="mobile-command-toggle"'));assert(node('arcade-overlay').innerHTML.includes('Слева — джойстик'));
assert.equal(run('ARCADE.canvas.width'),390);assert.equal(run('ARCADE.canvas.height'),460);assert.equal(touch.parentElement,screen,'Touch dock lives outside the game field');run('placeMobileControls()');assert.equal(touch.parentElement,screen);
assert.equal(run('ARCADE.hud.height'),460);assert.equal(doc.documentElement.style['--mobile-vh'],'844px');
const click=(action,value)=>event('click',{target:{tagName:'BUTTON',closest(){return {dataset:{action,value}}}}});
click('mobile-menu');assert(run('MOBILE.menu'));assert(node('workspace').inert);assert(!node('mobile-nav-backdrop').hidden);assert.equal(node('mobile-menu-toggle').attrs['aria-expanded'],'true');
click('mobile-menu-close');assert(!run('MOBILE.menu'));assert(!node('workspace').inert);
click('mobile-menu');click('view','requirements');assert.equal(run('STATE.view'),'requirements');assert(!run('MOBILE.menu'));assert(!node('workspace').inert);
click('mobile-play');assert.equal(run('STATE.view'),'arcade');assert(run('ARCADE.expanded'));
click('arcade-start');assert.equal(run('ARCADE.engine.status'),'briefing');click('citadel-launch');assert.equal(run('ARCADE.engine.status'),'playing');
// In-game records pause the flight and cannot be bypassed by touch commands.
click('cup-records');assert.equal(run('CUP.panel'),'records');assert.equal(run('ARCADE.engine.status'),'paused');assert.equal(screen.dataset.gameStatus,'paused');assert(!touch.classList.contains('flight-active'));
click('mobile-command');assert(!run('MOBILE.command'));click('mobile-flight-command','citadel-crystal');assert.equal(run('ARCADE.engine.status'),'paused');
click('cup-close');assert.equal(run('ARCADE.engine.status'),'playing');assert.equal(screen.dataset.gameStatus,'playing');assert(touch.classList.contains('flight-active'));
function pointer(id,type,props={}){for(const f of node(id).handlers[type]||[])f({pointerType:'touch',pointerId:11,button:0,clientX:75,clientY:52,preventDefault(){},...props})}
node('arcade-stick').getBoundingClientRect=()=>({left:0,top:0,width:104,height:104});
pointer('arcade-stick','pointerdown');pointer('arcade-fire-touch','pointerdown',{pointerId:22});let input=plain(run('arcadeInput()'));assert(input.turn>0);assert(input.fire);assert(!run('ARCADE.engine.autopilot'));
pointer('arcade-fire-touch','pointercancel',{pointerId:22});assert(!run('arcadeInput().fire'));assert(run('ARCADE.joystick')!==null);pointer('arcade-stick','pointercancel');assert.equal(run('ARCADE.joystick'),null);
click('arcade-missile');assert(run('arcadeInput().missile'));assert(!run('arcadeInput().missile'));click('arcade-pulse');assert(run('arcadeInput().pulse'));
click('mobile-autofire');assert(run('arcadeInput().fire'));click('mobile-autofire');assert(!run('arcadeInput().fire'));
click('mobile-command');assert.equal(run('ARCADE.engine.status'),'paused');assert(node('arcade-layout').classList.contains('mobile-command-open'));assert(screen.inert);
const oldGuide=run('ARCADE.engine.autopilot');click('mobile-guide');assert.equal(run('ARCADE.engine.autopilot'),!oldGuide);assert.equal(run('ARCADE.engine.status'),'paused');
click('mobile-command');assert.equal(run('ARCADE.engine.status'),'playing');assert(!screen.inert);
click('arcade-pause');click('mobile-command');click('mobile-command');assert.equal(run('ARCADE.engine.status'),'paused','A manually paused game stays paused');click('arcade-resume');
click('mobile-command');click('mobile-flight-command','citadel-crystal');assert.equal(run('ARCADE.engine.status'),'playing');assert.equal(run('ARCADE.engine.navMode'),'module');assert(!run('MOBILE.command'));assert(!screen.inert);
click('mobile-command');click('mobile-flight-command','arcade-pulse');assert(run('arcadeInput().pulse'));assert(!run('MOBILE.command'));
click('mobile-command');click('mobile-menu');assert(run('MOBILE.menu'));assert(!run('MOBILE.command'));assert(!screen.inert);click('mobile-menu-close');click('arcade-resume');
click('mobile-menu');assert.equal(run('ARCADE.engine.status'),'paused');event('keydown',{key:'Escape',code:'Escape'});assert(!run('MOBILE.menu'));assert.equal(run('ARCADE.engine.status'),'paused','Escape closes navigation without resuming behind it');click('arcade-resume');
// Ground movement stays opt-in; a touch command enables the guide.
run('ARCADE.engine.beginBoarding();updateArcadeHUD();updateArcadeOverlay()');assert(!run('ARCADE.engine.board.guide'));const pos=plain(run('ARCADE.engine.board.pos'));run('ARCADE.engine.step(1/60,{})');assert.deepStrictEqual(plain(run('ARCADE.engine.board.pos')),pos);
click('mobile-command');click('mobile-guide');assert(run('ARCADE.engine.board.guide'));assert.equal(run('ARCADE.engine.status'),'paused');click('mobile-command');assert.equal(run('ARCADE.engine.status'),'boarding');pointer('arcade-stick','pointerdown');assert(!run('ARCADE.engine.board.guide'));input=plain(run('arcadeInput()'));assert(input.moveX>0);pointer('arcade-stick','pointercancel');
// Real renderer/HUD at portrait and landscape dimensions, including resize by height only.
const viewports=[[320,364],[390,460],[430,536],[340,168],[592,244],[680,274]];
for(const [w,h]of viewports){node('arcade-canvas').getBoundingClientRect=()=>({left:0,top:0,width:w,height:h});context.innerWidth=w;run('resizeArcade()');assert.equal(run('ARCADE.canvas.width'),w);assert.equal(run('ARCADE.canvas.height'),h);assert.equal(run('ARCADE.hud.height'),h);run('arcadeFrame(16)');assert.equal(run('ARCADE.ctx.canvas.height'),h);}
node('arcade-canvas').getBoundingClientRect=()=>({left:0,top:0,width:390,height:490});run('resizeArcade()');assert.equal(run('ARCADE.hud.height'),490);
// Native CPU renders demonstrate projection in both orientations (not browser screenshots).
context.innerWidth=390;run('ARCADE.engine.beginStage(0);ARCADE.engine.launch()');
for(const [w,h,name]of [[390,460,'portrait'],[592,244,'landscape']]){
 context.innerWidth=w;node('arcade-canvas').getBoundingClientRect=()=>({left:0,top:0,width:w,height:h});run('resizeArcade();arcadeFrame(32)');
 const out=createCanvas(w,h),ctx=out.getContext('2d');ctx.drawImage(node('arcade-canvas'),0,0);ctx.drawImage(node('arcade-hud-canvas'),0,0);fs.writeFileSync(root+'/qa_mobile_'+name+'.png',out.toBuffer('image/png'));
}
run('ARCADE.engine.status="stageclear";ARCADE.engine.upgradeChoice="rockets";ARCADE.engine.beginEscort();ARCADE.engine.launch();ARCADE.engine.spawnEscortEnemy(2);ARCADE.engine.player.missileCooldown=0;ARCADE.engine.selectedTarget=ARCADE.engine.enemies[0].id');
const ammo=run('ARCADE.engine.player.missiles');click('arcade-missile');run('ARCADE.engine.step(1/60,arcadeInput());arcadeFrame(48)');assert.equal(run('ARCADE.engine.player.missiles'),ammo-1,'Touch missile during escort');
run('ARCADE.engine.beginStage(0);ARCADE.engine.launch();ARCADE.engine.collect(ARCADE.engine.modules()[0]);ARCADE.engine.openNextLesson();updateArcadeOverlay()');assert.equal(run('ARCADE.engine.status'),'lesson');assert(!node('arcade-touch').classList.contains('flight-active'));
click('citadel-lesson-answer',String(run('CITADEL_LESSONS[ARCADE.engine.lesson.caseIndex].correct')));click('citadel-lesson-next');assert.equal(run('ARCADE.engine.status'),'playing');
// Rotate while touching controls: pause, clear stuck input, preserve the mission.
context.innerWidth=390;context.innerHeight=844;run('updateMobileViewport()');run('ARCADE.keys.add("Space");ARCADE.joystick={x:1,y:0}');
context.innerWidth=844;context.innerHeight=390;context.visualViewport.height=390;run('updateMobileViewport()');assert.equal(doc.documentElement.style['--mobile-vh'],'390px');assert.equal(run('ARCADE.engine.status'),'paused');assert(!run('ARCADE.keys.has("Space")'));assert.equal(run('ARCADE.joystick'),null);
click('arcade-resume');context.visualViewport.height=350;run('updateMobileViewport()');assert.equal(run('ARCADE.engine.status'),'playing','Safari toolbar resizing does not interrupt a flight');
context.innerWidth=1280;context.innerHeight=800;run('updateMobileViewport()');assert.equal(touch.parentElement,field,'Restore desktop touch control placement');context.innerWidth=390;run('updateMobileViewport()');assert.equal(touch.parentElement,screen);
assert(!/[GQEC] —|WASD|Tab/.test(run('mobileFriendlyText(ARCADE.engine.objective().detail)')));
assert(node('content').innerHTML.includes('id="mobile-game-menu"'));assert(node('content').innerHTML.includes('mobile-toolbox'));assert(node('arcade-overlay').innerHTML.includes('Удобнее горизонтально'));

// Final arena: the real touch jump holds and releases without changing run speed.
run('ARCADE.engine.beginFinale();ARCADE.engine.beginMRG();updateFinaleHUD();clearArcadeInput()');assert.equal(node('arcade-boost-touch').textContent,'ПРЫЖОК');
pointer('arcade-boost-touch','pointerdown',{pointerId:33});assert(run('arcadeInput().boost'));run('for(let i=0;i<25;i++)ARCADE.engine.step(1/60,arcadeInput())');assert(run('ARCADE.engine.board.pos[1]>6'));
pointer('arcade-boost-touch','pointercancel',{pointerId:33});assert(!run('arcadeInput().boost'));assert(!node('arcade-boost-touch').classList.contains('is-held'));
assert(node('mobile-goal-detail').textContent.includes('вниз'));

const report={version:'1.3.5',mrgTouchJumpAndCancel:true,inGameRecordsPauseTouchControls:true,controlsOutsideCanvas:true,desktopPlacementRestored:true,rotationPausesAndClearsInput:true,toolbarResizeDoesNotPause:true,commandPanelInertAndPauseOwnership:true,panelActionsExecute:true,mobileTextNoKeyboardHints:true,directGameLink:true,menuOpenCloseAndSectionChoice:true,touchLaunch:true,multitouchFireAndJoystick:true,pointerCancelCleanup:true,touchMissileEscort:true,autoFire:true,radarPauseResume:true,menuPauseAndEscape:true,groundOptIn:true,lessonTouchAnswer:true,viewportSizes:viewports,heightOnlyResize:true,portraitAndLandscapeNativeRender:true,browserVisualQA:'unavailable',physicalIPhoneQA:'not_performed'};
fs.writeFileSync(root+'/qa_mobile.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
