"""Build the offline atlas and game. Python 3 standard library only."""
import argparse
import base64
import json
import re
from urllib.parse import urlparse
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CSS = ['style.css', 'review-space.css', 'geography.css', 'arcade.css', 'campaign.css', 'mobile.css', 'comfort.css', 'finale.css', 'tournament.css']
JS = ['app.js', 'reviews.js', 'cosmos.js', 'arcade-engine.js', 'learning.js',
      'campaign.js', 'learning-variety.js', 'station-game.js', 'expedition-game.js', 'finale-game.js', 'space3d.js',
      'campaign-visuals.js', 'space-cinematic.js', 'station-visuals.js',
      'expedition-visuals.js', 'finale-visuals.js', 'captain-animated-asset.js', 'arcade.js', 'space-audio.js', 'training-ui.js',
      'campaign-ui.js', 'clarity-ui.js', 'expedition-ui.js', 'mobile.js', 'finale-ui.js', 'tournament.js']


def metadata():
    release = json.loads((ROOT / 'release.json').read_text(encoding='utf-8'))
    if not re.fullmatch(r'\d+\.\d+\.\d+(?:-[a-zA-Z0-9.-]+)?', release['version']):
        raise ValueError('Use an application version such as 1.0.1 or 1.1.0-rc.1')
    url = urlparse(release['public_url'])
    if url.scheme != 'https' or not url.netloc or url.query or url.fragment or not release['public_url'].endswith('/'):
        raise ValueError('public_url must be an absolute HTTPS directory URL ending in /')
    date.fromisoformat(release['released_on'])
    return release


def build():
    release = metadata()
    shell = (ROOT / 'shell.html').read_text(encoding='utf-8')
    shell = shell.replace('@@APP_VERSION@@', release['version'])
    shell = shell.replace('@@PUBLIC_URL@@', release['public_url'])
    shell = shell.replace('@@RELEASE_DATE@@', date.fromisoformat(release['released_on']).strftime('%d.%m.%Y'))
    html = (shell.replace('/*CSS*/', '\n'.join((ROOT / p).read_text(encoding='utf-8') for p in CSS))
            .replace('/*DATA*/', (ROOT / 'data.json').read_text(encoding='utf-8').replace('<', '\\u003c'))
            .replace('/*RELEASE*/', json.dumps(release, ensure_ascii=False).replace('<', '\\u003c'))
            .replace('/*JS*/', '\n'.join((ROOT / p).read_text(encoding='utf-8') for p in JS)
                     + '\nif(!globalThis.ATLAS_TEST)initialize();'))
    html = html.replace('./assets/citadel-victory-v1.2.0.webp', 'data:image/webp;base64,' + base64.b64encode((ROOT/'assets/citadel-victory-v1.2.0.webp').read_bytes()).decode())
    return html.encode('utf-8')


def build_web():
    """Keep crawler-facing HTML small; preserve the standalone offline build."""
    release = metadata()
    version = release['version']
    shell = (ROOT / 'shell.html').read_text(encoding='utf-8')
    shell = shell.replace('@@APP_VERSION@@', version).replace('@@PUBLIC_URL@@', release['public_url'])
    shell = shell.replace('@@RELEASE_DATE@@', date.fromisoformat(release['released_on']).strftime('%d.%m.%Y'))
    css_name = f'assets/atlas-v{version}.css'
    js_name = f'assets/atlas-v{version}.js'
    css = '\n'.join((ROOT / p).read_text(encoding='utf-8') for p in CSS)
    data = (ROOT / 'data.json').read_text(encoding='utf-8').replace('<', '\\u003c')
    js = "'use strict';\ndocument.getElementById('atlas-data').textContent=JSON.stringify(" + data + ');\n'
    js += '\n'.join((ROOT / p).read_text(encoding='utf-8') for p in JS)
    js += '\nif(!globalThis.ATLAS_TEST)initialize();\n'
    html = (shell.replace('<style>/*CSS*/</style>', f'<link rel="stylesheet" href="./{css_name}">')
            .replace('/*DATA*/', '')
            .replace('/*RELEASE*/', json.dumps(release, ensure_ascii=False).replace('<', '\\u003c'))
            .replace('<script>/*JS*/</script>', f'<script defer src="./{js_name}"></script>'))
    html = html.replace('</head>', '<link rel="stylesheet" href="./assets/atlas-metrics-v0.1.0.css">\n</head>').replace('</body>', '<script defer src="./assets/atlas-metrics-v0.1.0.js"></script>\n<script defer src="./assets/atlas-integration-v1.1.4.js"></script>\n</body>').replace('Автономный файл', 'Веб-атлас')
    # A fresh, explicit sharing route without redirect or JavaScript-only metadata.
    share = html.replace('rel="canonical" href="' + release['public_url'] + '"',
                         'rel="canonical" href="' + release['public_url'] + 'atlas.html"')
    share = share.replace('property="og:url" content="' + release['public_url'] + '"',
                          'property="og:url" content="' + release['public_url'] + 'atlas.html"')
    files = {'index.html': html.encode('utf-8'), 'atlas.html': share.encode('utf-8'),
             css_name: css.encode('utf-8'), js_name: js.encode('utf-8')}
    for name in ['og-atlas-v1.1.3.png', 'atlas-icon.svg', 'atlas-metrics-v0.1.0.css', 'atlas-metrics-v0.1.0.js', 'atlas-integration-v1.1.4.js', 'citadel-victory-v1.2.0.webp']:
        files['assets/'+name] = (ROOT/'assets'/name).read_bytes()
    return files


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT.parent / 'output' / 'ЦМПОН_Интерактивный_атлас_требований_14.10.2026.html')
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(build())
    print(args.output.resolve(), args.output.stat().st_size)
