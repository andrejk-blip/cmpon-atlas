/* Original instrumental score: slow space / dub. No recordings or external assets. */
const SPACE_AUDIO={ready:false,music:true,volume:.24,bus:null,fx:null,track:null,theme:'',next:0,step:0,voices:new Set(),lastFx:{},serial:0};
const SPACE_THEMES={
 finaleBoss:{name:'Параллакс',bpm:82,root:40,chords:[0,3,1,7],motif:[12,19,null,13,24,null,19,15],kind:'hyper'},
 finaleLair:{name:'Архив нулевой редакции',bpm:57,root:43,chords:[0,5,1,7],motif:[19,null,13,null,24,null,20,null],kind:'deck'},
 finaleMRG:{name:'Протокол МРГ',bpm:86,root:42,chords:[0,3,7,1],motif:[12,24,19,null,15,22,19,null],kind:'hyper'},
 finaleVictory:{name:'Команда на связи',bpm:62,root:48,chords:[0,5,7,0],motif:[16,null,19,24,null,28,24,null],kind:'port'},
 port:{name:'Порт ЦСИИ',bpm:60,root:45,chords:[0,5,3,7],motif:[12,null,19,15,null,22,19,null],kind:'port'},
 orbit0:{name:'Дальний периметр',bpm:66,root:45,chords:[0,5,3,7],motif:[12,null,19,null,22,19,null,15],kind:'orbit'},
 orbit1:{name:'Линия орбиты',bpm:64,root:42,chords:[0,3,7,5],motif:[19,14,null,17,null,22,17,null],kind:'orbit'},
 orbit2:{name:'Тихая граница',bpm:62,root:47,chords:[0,7,5,3],motif:[12,19,null,22,null,15,14,null],kind:'orbit'},
 orbit3:{name:'Последняя редакция',bpm:68,root:44,chords:[0,5,7,3],motif:[24,null,19,17,null,15,19,null],kind:'orbit'},
 deck0:{name:'Архив ФЗ',bpm:58,root:45,chords:[5,0,3,7],motif:[19,null,null,15,12,null,22,null],kind:'deck'},
 deck1:{name:'Коридоры исполнителя',bpm:60,root:42,chords:[3,7,0,5],motif:[15,null,22,null,19,null,14,null],kind:'deck'},
 deck2:{name:'Переход смежников',bpm:56,root:47,chords:[5,3,0,7],motif:[14,null,19,22,null,null,17,null],kind:'deck'},
 deck3:{name:'Зал согласования',bpm:62,root:44,chords:[3,5,0,7],motif:[19,null,24,null,22,19,null,15],kind:'deck'},
 hyper0:{name:'Тихий караван',bpm:76,root:45,chords:[0,7,3,5],motif:[12,19,null,22,19,null,15,null],kind:'hyper'},
 hyper1:{name:'Между системами',bpm:72,root:42,chords:[5,0,7,3],motif:[14,null,22,19,null,17,19,null],kind:'hyper'},
 hyper2:{name:'Курс к Цитадели',bpm:78,root:47,chords:[0,3,5,7],motif:[19,22,null,24,null,19,15,null],kind:'hyper'}
};
function spaceAudioRead(){try{const s=JSON.parse(localStorage.getItem('cmpon.citadel.audio.v1')||'null');if(s&&typeof s.music==='boolean'&&typeof s.effects==='boolean'){SPACE_AUDIO.music=s.music;ARCADE.sound=s.effects;if(Number.isFinite(s.volume))SPACE_AUDIO.volume=arcadeClamp(s.volume,.08,.5)}}catch{}}
function spaceAudioSave(){try{localStorage.setItem('cmpon.citadel.audio.v1',JSON.stringify({music:SPACE_AUDIO.music,effects:ARCADE.sound,volume:SPACE_AUDIO.volume}))}catch{}}
function spaceAudioInit(c){if(SPACE_AUDIO.ready)return;const bus=c.createGain(),fx=c.createGain(),limit=c.createDynamicsCompressor();bus.gain.value=1;fx.gain.value=.3;limit.threshold.value=-15;limit.knee.value=18;limit.ratio.value=3;limit.attack.value=.01;limit.release.value=.25;bus.connect(limit);fx.connect(limit);limit.connect(c.destination);Object.assign(SPACE_AUDIO,{ready:true,bus,fx,limit})}
function spaceAudioScene(e){if(!e||e.status==='menu')return 'port';if(e.finale)return ['upload','victory'].includes(e.finale.phase)?'finaleVictory':e.finale.phase==='mrg'?'finaleMRG':['maze','landing'].includes(e.finale.phase)?'finaleLair':'finaleBoss';if(e.phase==='escort')return 'hyper'+Math.min(2,e.stage);if(citadelInside(e)||e.status==='remark'||e.status==='docking')return 'deck'+e.stage;return 'orbit'+e.stage}
function spaceAudioGain(param,value,time,fade=.25){param.cancelScheduledValues(time);param.setTargetAtTime(Math.max(0,value),time,fade)}
function spaceAudioRetire(track,now){if(!track||track.retired)return;track.retired=true;spaceAudioGain(track.gain.gain,0,now,.16);for(const voice of [...SPACE_AUDIO.voices])if(voice.track===track){try{voice.osc.stop(now+.7)}catch{}}setTimeout(()=>{for(const node of track.nodes)try{node.disconnect()}catch{}},1800)}
function spaceAudioTrack(key,c){const old=SPACE_AUDIO.track;spaceAudioRetire(old,c.currentTime);const gain=c.createGain(),filter=c.createBiquadFilter(),delay=c.createDelay(2),feedback=c.createGain(),wet=c.createGain();filter.type='lowpass';filter.frequency.value=2700;filter.Q.value=.4;gain.gain.value=0;delay.delayTime.value=60/SPACE_THEMES[key].bpm*.75;feedback.gain.value=.23;wet.gain.value=.19;gain.connect(filter);filter.connect(SPACE_AUDIO.bus);filter.connect(delay);delay.connect(feedback);feedback.connect(delay);delay.connect(wet);wet.connect(SPACE_AUDIO.bus);SPACE_AUDIO.track={key,gain,nodes:[gain,filter,delay,feedback,wet],retired:false};SPACE_AUDIO.theme=key;SPACE_AUDIO.step=0;SPACE_AUDIO.next=c.currentTime+.045;return SPACE_AUDIO.track}
function spaceAudioVoice(c,track,note,time,duration,amp,type='sine',pan=0,attack=.04,glide=null){
 if(SPACE_AUDIO.voices.size>=72)return;const osc=c.createOscillator(),gain=c.createGain(),panner=c.createStereoPanner?.();const freq=440*Math.pow(2,(note-69)/12);osc.type=type;osc.frequency.setValueAtTime(freq,time);if(glide!==null)osc.frequency.exponentialRampToValueAtTime(glide,time+duration);gain.gain.setValueAtTime(.0001,time);gain.gain.linearRampToValueAtTime(amp,time+Math.min(attack,duration*.25));gain.gain.exponentialRampToValueAtTime(.0001,time+duration);osc.connect(gain);if(panner){panner.pan.value=pan;gain.connect(panner);panner.connect(track.gain)}else gain.connect(track.gain);
 const voice={osc,gain,panner,track};SPACE_AUDIO.voices.add(voice);osc.onended=()=>{osc.disconnect();gain.disconnect();panner?.disconnect();SPACE_AUDIO.voices.delete(voice)};osc.start(time);osc.stop(time+duration+.03);
}
function spaceScoreStep(theme,index){
 const beat=60/theme.bpm,bar=Math.floor(index/8),step=index%8,root=theme.root+theme.chords[Math.floor(bar/2)%4],notes=[];
 const add=(note,duration,amp,type='sine',pan=0,attack=.04,glide=null)=>notes.push({note,duration,amp,type,pan,attack,glide});
 // Eight bars per phrase; upper voice and rhythm change on alternate phrases.
 if(index%16===0){for(const [j,n]of [0,3,7,14].entries())add(root+12+n,beat*7.8,.035,j%2?'triangle':'sine',(j-1.5)*.35,.8)}
 if(step===0||step===5&&theme.kind!=='port')add(root-12+(step===5?7:0),beat*1.6,.16,'sine',0,.07);
 const motif=theme.motif[(step+bar%4*2)%8];if(motif!==null&&(step%2===0||theme.kind==='hyper'&&bar%2===1)){add(root+motif+(Math.floor(bar/8)%2?12:0),beat*1.9,.045,'sine',step%4<2?-.35:.35,.035);add(root+motif+12,beat*.55,.012,'triangle',.15,.018)}
 if(theme.kind!=='port'&&(step===0||step===4&&theme.kind!=='deck'))add(35,beat*.24,.075,'sine',0,.008,32);
 if(theme.kind==='hyper'&&step===6||theme.kind==='orbit'&&step===6&&bar%2===1)add(70,beat*.09,.008,'triangle',.4,.003);
 return notes;
}
function spaceAudioSync(e=ARCADE.engine){
 const c=ARCADE.audio;if(!c||!SPACE_AUDIO.ready)return;
 if(STATE.view!=='arcade'||document.hidden||!SPACE_AUDIO.music){if(SPACE_AUDIO.track){spaceAudioRetire(SPACE_AUDIO.track,c.currentTime);SPACE_AUDIO.track=null;SPACE_AUDIO.theme=''}return}
 if(c.state!=='running')return;const key=spaceAudioScene(e),track=SPACE_AUDIO.track?.key===key?SPACE_AUDIO.track:spaceAudioTrack(key,c),theme=SPACE_THEMES[key];const duck=['lesson','remark','finalcheck','paused'].includes(e?.status)?.28:['menu','briefing','escortbrief','finalebrief'].includes(e?.status)?.65:1;
 if(track.volume!==SPACE_AUDIO.volume*duck){track.volume=SPACE_AUDIO.volume*duck;spaceAudioGain(track.gain.gain,track.volume,c.currentTime,.35)}
 if(SPACE_AUDIO.next<c.currentTime-.2)SPACE_AUDIO.next=c.currentTime+.04;
 let count=0;while(SPACE_AUDIO.next<c.currentTime+.32&&count++<8){for(const n of spaceScoreStep(theme,SPACE_AUDIO.step))spaceAudioVoice(c,track,n.note,SPACE_AUDIO.next,n.duration,n.amp,n.type,n.pan,n.attack,n.glide);SPACE_AUDIO.next+=30/theme.bpm;SPACE_AUDIO.step++}
}
function spaceAudioStop(){const c=ARCADE.audio;if(!c)return;spaceAudioRetire(SPACE_AUDIO.track,c.currentTime);SPACE_AUDIO.track=null;SPACE_AUDIO.theme='';if(SPACE_AUDIO.fx)spaceAudioGain(SPACE_AUDIO.fx.gain,0,c.currentTime,.03);}
function spaceAudioUnlock(){const c=arcadeAudio()||ARCADE.audio;if(c){if(SPACE_AUDIO.fx)spaceAudioGain(SPACE_AUDIO.fx.gain,ARCADE.sound?.3:0,c.currentTime,.05);spaceAudioSync()}return c}
function spacePlayEffect(type){if(!ARCADE.sound||document.hidden||STATE.view!=='arcade')return;const c=arcadeAudio();if(!c||c.state!=='running')return;const now=c.currentTime,min=type==='shot'?.24:type==='destroy'?.12:.06;if(now-(SPACE_AUDIO.lastFx[type]??-99)<min)return;SPACE_AUDIO.lastFx[type]=now;const i=SPACE_AUDIO.serial++%3;const spec={shot:[70+i*2,.075,.018,'triangle',250+i*18],missile:[43,.35,.08,'triangle',48],destroy:[34,.45,.055,'sine',28],rescue:[69,.6,.08,'sine',660],damage:[40,.22,.06,'triangle',65],pulse:[39,.55,.065,'sine',330],flip:[52,.32,.035,'sine',220],pickup:[72,.5,.06,'sine',660],boss:[33,.9,.08,'triangle',82],dock:[40,1.4,.065,'sine',140],gate:[45,.8,.04,'triangle',65],terminal:[76,.55,.06,'sine',660],hyper:[36,1.6,.07,'sine',440],crash:[48,.8,.07,'triangle',40],detonate:[33,1.3,.09,'sine',24]}[type];if(!spec)return;spaceAudioVoice(c,{gain:SPACE_AUDIO.fx},spec[0],now+.005,spec[1],spec[2],spec[3],(i-1)*.1,.015,spec[4])}
function spaceAudioMarkup(){return '<section class="space-audio-panel" aria-label="Музыка и звуки"><div><span>DEEP SPACE</span><small id="space-track-name">'+SPACE_THEMES[spaceAudioScene(ARCADE.engine)].name+'</small></div><div class="space-audio-buttons"><button data-action="arcade-music" id="space-music-toggle" aria-pressed="'+SPACE_AUDIO.music+'">Музыка '+(SPACE_AUDIO.music?'вкл':'выкл')+'</button><button data-action="arcade-sound" id="space-effects-toggle" aria-pressed="'+ARCADE.sound+'">Звуки '+(ARCADE.sound?'вкл':'выкл')+'</button><button data-action="arcade-music-volume" id="space-volume">Тихо</button></div></section>'}
function spaceAudioControls(){const label=SPACE_THEMES[spaceAudioScene(ARCADE.engine)].name;const track=document.getElementById('space-track-name');if(track)track.textContent=label;for(const id of ['space-music-toggle','mobile-music','arcade-music']){const b=document.getElementById(id);if(b){b.setAttribute('aria-pressed',String(SPACE_AUDIO.music));b.textContent=(id==='arcade-music'?'♫ ': 'Музыка ')+(SPACE_AUDIO.music?'вкл':'выкл');b.setAttribute('aria-label','Музыка: '+(SPACE_AUDIO.music?'включена':'выключена'))}}for(const id of ['space-effects-toggle','arcade-sound']){const b=document.getElementById(id);if(b){b.setAttribute('aria-pressed',String(ARCADE.sound));b.textContent=id==='arcade-sound'?(ARCADE.sound?'◖))':'◖×'):'Звуки '+(ARCADE.sound?'вкл':'выкл');b.setAttribute('aria-label','Звуковые эффекты: '+(ARCADE.sound?'включены':'выключены'))}}const v=document.getElementById('space-volume');if(v)v.textContent=SPACE_AUDIO.volume<.2?'Едва слышно':SPACE_AUDIO.volume<.35?'Тихо':'Громче'}
function spaceAudioAction(action){if(!['arcade-music','arcade-sound','arcade-music-volume'].includes(action))return false;if(action==='arcade-music')SPACE_AUDIO.music=!SPACE_AUDIO.music;else if(action==='arcade-sound')ARCADE.sound=!ARCADE.sound;else SPACE_AUDIO.volume=SPACE_AUDIO.volume<.2?.24:SPACE_AUDIO.volume<.35?.4:.12;spaceAudioSave();spaceAudioUnlock();spaceAudioSync();spaceAudioControls();return true}
