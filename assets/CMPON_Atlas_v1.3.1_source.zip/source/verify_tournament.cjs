const h=require('./campaign-harness.cjs');const {run,plain,assert,context}=h;
(async()=>{
const {checkedCheckpoint,checkedResult,LEVELS}=await import('./test-support/tournament-rules.mjs');
run(`var recordings=[];cupEnqueue=function(result){if(result)recordings.push({clock:Math.round(CUP.clock),snapshot:cupPack(ARCADE.engine),result})};
function tournamentPlay(seed,assist){let e=new RequirementArcade(seed);ARCADE.engine=e;e.start(assist);CUP.run={id:'simulation',seed,mode:assist?'calm':'normal',progress:0,status:'active'};CUP.attached=true;CUP.conflict=false;CUP.clock=0;CUP.startClock=0;CUP.startScore=0;CUP.progress=0;recordings=[];e.launch();let last='',restores=0,maxBytes=0;
for(let frame=0;frame<60*2100;frame++){
 const phase=e.stage+':'+e.phase+':'+e.status+':'+e.finale?.phase;
 if(phase!==last){const s=cupPack(e);maxBytes=Math.max(maxBytes,JSON.stringify(s).length);e=cupUnpack(s,CUP.run,()=>{});ARCADE.engine=e;last=phase;restores++;}
 if(e.status==='won'||e.status==='lost')break;
 if(e.status==='stageclear'){e.chooseUpgrade(['weapons','armor','weapons'][e.stage]);e.next();e.launch();continue}
 if(e.status==='escortbrief'){e.launch();continue}if(e.status==='escortclear'){e.completeEscort();e.launch();continue}
 if(e.status==='lesson'){cupTick(1);e.answerLesson(CITADEL_LESSONS[e.lesson.caseIndex].correct);e.continueLesson();continue}
 if(e.status==='remark'){cupTick(1);e.answer(CITADEL_REMARKS[e.board.question].correct);e.continueRemark();continue}
 if(e.status==='finalebrief'){e.launchFinale();continue}if(e.status==='finalcheck'){cupTick(1);e.answerFinale(FINALE_TRIALS[e.board.completed.length].correct);e.continueFinaleCheck();continue}
 let input={fire:true,pulse:true,missile:!!e.target()};if(e.status==='boarding'){e.board.guide=true;input.missile=!!e.finale?.open}else if(e.status==='playing'){e.autopilot=true;if(e.phase==='battle'&&frame%180===0){const danger=e.enemies.filter(x=>!x.dead&&x.channel).sort((a,b)=>e.nodes[a.node].integrity-e.nodes[b.node].integrity)[0];if(danger)e.selectedTarget=danger.id}}
 cupTick(1/60);e.step(1/60,input);
}return {seed,assist,status:e.status,phase:e.phase,finale:e.finale?.phase,score:e.score,clock:Math.round(CUP.clock),progress:CUP.progress,restores,maxBytes,records:recordings};}
`);
for(const assist of [true,false]){
const r=plain(run(`tournamentPlay(417147,${assist})`));console.log({mode:assist?'calm':'normal',status:r.status,progress:r.progress,score:r.score,seconds:r.clock/1000,restores:r.restores,maxBytes:r.maxBytes});assert.equal(r.status,'won');assert.equal(r.progress,14);assert.equal(r.records.length,14);let previous=null;for(let i=0;i<14;i++){const rec=r.records[i],serverRun={seed:r.seed,mode:assist?'calm':'normal',clock:previous?.clock||0,progress:i,created_at:0};checkedCheckpoint(rec,serverRun,rec.clock+30000);checkedResult(rec.result,serverRun,previous);assert.equal(rec.result.level,i);previous={...rec.result,campaign_score:rec.result.campaignScore};}h.fs.writeFileSync('qa130-'+(assist?'calm':'normal')+'.json',JSON.stringify({...r,records:r.records.map(x=>x.result)},null,2));
}
// RNG continuation, byte limits and safe application of snapshot properties.
run(`var e=new RequirementArcade(417147);e.start(true);e.beginBoarding();var s=cupPack(e);s.engine.step='malicious';var re=cupUnpack(s,{seed:417147,mode:'calm'},()=>{});`);
assert.equal(run('typeof re.step'),'function');assert(run('re.board.cells instanceof Map'));assert(run('re.board.nav instanceof Map'));assert(run('e.random()===re.random()'));
// Guest/new-game entry must stay inside the game online, while offline gameplay stays available.
run('CUP.run=null;CUP.attached=false;CUP.player=null;ARCADE.engine=new RequirementArcade(417147);var viewAsked="";setView=(v)=>viewAsked=v');context.location.protocol='https:';run("arcadeAction('arcade-start')");assert.equal(run('viewAsked'),'');assert.equal(h.doc.activeElement.id,'cup-name');context.location.protocol='file:';
console.log('PASS: full calm + normal campaigns with restore at every phase, all 14 score boundaries satisfy server rules, deterministic RNG, sets/nav, safe property restore, online name entry and offline compatibility.');
})().catch(e=>{console.error(e);process.exitCode=1});
