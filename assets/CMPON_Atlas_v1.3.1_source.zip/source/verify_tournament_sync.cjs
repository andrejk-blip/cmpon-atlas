const h=require('./campaign-harness.cjs');const {run,plain,context,assert}=h;
(async()=>{
let revision=0,receipts=new Set(),calls=0,lose=true;
context.fetch=async (_url,options)=>{calls++;const b=JSON.parse(options.body);if(!receipts.has(b.requestId)){assert.equal(b.revision,revision);receipts.add(b.requestId);revision++;}if(lose){lose=false;throw Error('lost response');}return new Response(JSON.stringify({run:{id:'sync-run',revision,progress:0,status:'active'}}),{status:200});};
run(`CUP.player={id:'pilot',name:'Пилот'};CUP.token='test';CUP.run={id:'sync-run',revision:0,seed:417147,mode:'calm',status:'active'};CUP.attached=true;ARCADE.engine=new RequirementArcade(417147);ARCADE.engine.start(true);cupEnqueue();`);
while(run('CUP.sending'))await new Promise(r=>setTimeout(r,0));assert.equal(run('CUP.queue.length'),1);assert.equal(revision,1);
run('CUP.clock=500;cupEnqueue()');while(run('CUP.sending'))await new Promise(r=>setTimeout(r,0));
assert.equal(run('CUP.queue.length'),0);assert.equal(revision,2);assert.equal(calls,3);assert.equal(receipts.size,2);
// Cross-tab conflict must pause without overwriting authoritative data.
context.fetch=async()=>new Response(JSON.stringify({error:'Конфликт вкладок'}),{status:409});run('ARCADE.engine.launch();cupEnqueue()');while(run('CUP.sending'))await new Promise(r=>setTimeout(r,0));assert(run('CUP.conflict'));assert.equal(run('ARCADE.engine.status'),'paused');
// Non-result autosaves cannot queue behind the final completed level.
run('CUP.queue=[];CUP.conflict=false;CUP.progress=14;cupEnqueue()');assert.equal(run('CUP.queue.length'),0);
// Map geometry and RNG persist, while method replacement from a save is ignored.
run(`var e=new RequirementArcade(417147);e.start(true);e.beginBoarding();var s=cupPack(e);s.engine.step='bad';var restored=cupUnpack(s,{seed:417147,mode:'calm'},()=>{});`);assert(run('restored.board.cells instanceof Map'));assert(run('restored.board.nav instanceof Map'));assert.equal(run('typeof restored.step'),'function');assert(run('e.random()===restored.random()'));
// Public entry stays in game; isolated offline mode keeps its guest launch.
run('CUP.player=null;CUP.run=null;CUP.attached=false;var asked="";setView=(v)=>asked=v');context.location.protocol='https:';run("arcadeAction('arcade-start')");assert.equal(run('asked'),'');assert.equal(h.doc.activeElement.id,'cup-name');
console.log('PASS: lost response retry, one ledger entry/request, ordered queue revisions, tab conflict pause, final autosave guard, snapshot maps/RNG, profile entry.');
})().catch(e=>{console.error(e);process.exitCode=1});
