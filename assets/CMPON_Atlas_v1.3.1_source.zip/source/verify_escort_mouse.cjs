const {fs,assert,root,run,plain,node,event}=require('./campaign-harness.cjs');
run('ARCADE.sound=false;ARCADE.forceCPU=true;initialize();setView("arcade");startArcade()');
const pointer=(button=2,type='mouse')=>{const ev={button,pointerType:type,pointerId:11,clientX:600,clientY:350,preventDefault(){}};for(const f of node('arcade-canvas').handlers.pointerdown||[])f(ev);if(type==='mouse')for(const f of node('arcade-canvas').handlers.mousedown||[])f(ev)};
// Right click is deliberately scoped to active escort flight.
for(const state of ['briefing','paused','boarding','docking','lesson','lost','crashing']){run(`ARCADE.engine.status='${state}';ARCADE.engine.phase='escort';clearArcadeInput()`);pointer();assert(!run('ARCADE.missileQueued'),state)}
run("ARCADE.engine.status='playing';ARCADE.engine.phase='battle';clearArcadeInput()");pointer();assert(!run('ARCADE.missileQueued'));
run("ARCADE.engine.status='stageclear';ARCADE.engine.stage=0;ARCADE.engine.upgradeChoice='rockets';ARCADE.engine.beginEscort();ARCADE.engine.launch();clearArcadeInput()");
assert.equal(run('ARCADE.engine.phase'),'escort');assert.equal(run('ARCADE.engine.status'),'playing');
// Same pointer pipeline as real controls: one click -> one queued command.
pointer();assert(run('ARCADE.missileQueued'));assert(!run('arcadeInput().fire'));assert(!run('ARCADE.missileQueued'));
pointer();const input=plain(run('arcadeInput()'));assert(input.missile);assert(!input.fire);assert(!run('arcadeInput().missile'));
run('clearArcadeInput()');pointer(2,'touch');assert(!run('ARCADE.missileQueued'));
node('detail').open=true;pointer();assert(!run('ARCADE.missileQueued'));node('detail').open=false;
run("STATE.view='map'");pointer();assert(!run('ARCADE.missileQueued'));run("STATE.view='arcade'");
// Ammo, lock and cooldown are still owned by the unchanged weapon implementation.
run("ARCADE.engine.enemies=[];ARCADE.engine.selectedTarget=null;ARCADE.engine.autopilot=false;ARCADE.engine.player.missileCooldown=0");const ammo=run('ARCADE.engine.player.missiles');pointer();run('ARCADE.engine.step(1/60,arcadeInput())');assert.equal(run('ARCADE.engine.player.missiles'),ammo,'No target must not consume ammo');
run("globalThis.e=ARCADE.engine;e.spawnEscortEnemy(2);globalThis.target=e.enemies[e.enemies.length-1];target.pos=V3.add(e.player.pos,[0,0,-65]);target.warp=0;e.selectedTarget=target.id;e.player.yaw=0;e.player.pitch=0;e.player.missileCooldown=0");
pointer();run('ARCADE.engine.step(1/60,arcadeInput())');assert.equal(run('ARCADE.engine.player.missiles'),ammo-1);assert(run("ARCADE.engine.bullets.some(b=>b.type==='missile')"));
pointer();run('ARCADE.engine.step(1/60,arcadeInput())');assert.equal(run('ARCADE.engine.player.missiles'),ammo-1,'Cooldown must prevent repeat missile');
run('ARCADE.engine.player.missiles=0;ARCADE.engine.player.missileCooldown=0');pointer();run('ARCADE.engine.step(1/60,arcadeInput())');assert.equal(run('ARCADE.engine.player.missiles'),0);
// Left fire and Q remain available.
pointer(0);assert(run('arcadeInput().fire'));for(const f of node('arcade-canvas').handlers.mousedown||[])f({button:2,preventDefault(){}});const together=plain(run('arcadeInput()'));assert(together.fire&&together.missile,'RMB must work while LMB is held');run('clearArcadeInput()');event('keydown',{code:'KeyQ'});assert(run('arcadeInput().missile'));
run('clearArcadeInput()');pointer();run('ARCADE.engine.pause();clearArcadeInput()');assert(!run('ARCADE.missileQueued'));
const report={rightClickEscort:'passed',oneShotQueue:'passed',noTargetNoAmmoConsumption:'passed',cooldown:'passed',emptyMagazine:'passed',inactiveStates:'passed',leftClickAndQ:'passed',touchUnchanged:'passed',rightClickWhileHoldingLeft:'passed'};fs.writeFileSync(root+'/qa_escort_mouse.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
