export const GAME_VERSION='1.3.0';
export const LEVELS=[
 {id:'orbit-1',title:'Орбита ФЗ',min:6,max:60000},
 {id:'deck-1',title:'Архив ФЗ',min:6,max:30000},
 {id:'convoy-1',title:'Коридор исполнения',min:54,max:12000},
 {id:'orbit-2',title:'Орбита исполнителя',min:6,max:65000},
 {id:'deck-2',title:'Машинный зал',min:6,max:30000},
 {id:'convoy-2',title:'Переход интеграций',min:60,max:12000},
 {id:'orbit-3',title:'Орбита смежников',min:6,max:70000},
 {id:'deck-3',title:'Палуба интеграций',min:6,max:30000},
 {id:'convoy-3',title:'Последняя миля',min:66,max:14000},
 {id:'orbit-4',title:'Итоговая орбита',min:8,max:85000},
 {id:'deck-4',title:'Палуба менеджмента',min:6,max:30000},
 {id:'parallax',title:'Параллакс',min:8,max:40000},
 {id:'maze',title:'Лабиринт логова',min:6,max:30000},
 {id:'mrg',title:'Главный компьютер МРГ',min:8,max:15000},
];
export const FIRST_CUP={id:'cmpon-cup-2026-10',title:'Кубок ЦМПОН -10.26',startsAt:Date.parse('2026-10-19T00:00:00+03:00'),endsAt:Date.parse('2026-11-02T00:00:00+03:00'),mode:'calm',seed:417147,announced:true,message:'Две недели на пути к согласованным ФТ. Пройдите кампанию, улучшайте результат и соревнуйтесь с коллегами.'};
export class CupError extends Error {constructor(message,status=400){super(message);this.status=status;}}
export const integer=(v,min,max)=>Number.isInteger(v)&&v>=min&&v<=max;
export function displayName(v){if(typeof v!=='string')throw new CupError('Укажите имя.');const s=v.normalize('NFKC').trim().replace(/\s+/g,' ');if(s.length<2||s.length>32||!/^[\p{L}\p{N} ._\-]+$/u.test(s))throw new CupError('Имя: 2–32 символа, буквы, цифры, пробел, точка, дефис.');return s;}
export function password(v){if(typeof v!=='string'||v.length<8||v.length>128)throw new CupError('Пароль: от 8 до 128 символов.');return v;}
export function cupState(c,now=Date.now()){return c.state==='cancelled'?'cancelled':c.state==='finalized'||now>=c.ends_at?'finished':now<c.starts_at?'upcoming':'active';}
export function publicCup(c,now=Date.now()){return {id:c.id,title:c.title,startsAt:c.starts_at,endsAt:c.ends_at,mode:c.mode,seed:c.seed,announced:!!c.announced,message:c.message,state:cupState(c,now),revision:c.revision};}
export function checkedCup(body){
 const title=typeof body.title==='string'?body.title.trim():'';
 if(title.length<3||title.length>100)throw new CupError('Название турнира: 3–100 символов.');
 if(!integer(body.startsAt,Date.UTC(2026,0),Date.UTC(2036,0))||!integer(body.endsAt,body.startsAt+60000,body.startsAt+90*86400000))throw new CupError('Проверьте даты турнира: окончание должно быть позже начала, период — не больше 90 дней.');
 if(!['calm','normal'].includes(body.mode)||!integer(body.seed,0,4294967295))throw new CupError('Проверьте сложность и набор ситуаций.');
 if(typeof body.announced!=='boolean'||typeof body.message!=='string'||body.message.length>500)throw new CupError('Текст анонса — не больше 500 символов.');
 return {title,startsAt:body.startsAt,endsAt:body.endsAt,mode:body.mode,seed:body.seed,announced:body.announced,message:body.message.trim()};
}
function safeTree(value,depth=0){if(depth>24)throw new CupError('Повреждено сохранение.');if(typeof value==='number'&&!Number.isFinite(value))throw new CupError('Повреждено сохранение.');if(value&&typeof value==='object')for(const [k,v]of Object.entries(value)){if(['__proto__','prototype','constructor'].includes(k))throw new CupError('Повреждено сохранение.');safeTree(v,depth+1);}}
export function checkedCheckpoint(input,run,now){
 if(!input||!integer(input.clock,0,90*86400000)||input.clock<run.clock)throw new CupError('Время попытки не может уменьшаться.');
 if(input.clock>now-run.created_at+30000)throw new CupError('Игровое время превышает длительность попытки.');
 const s=input.snapshot,e=s?.engine;
 if(s?.schema!==1||!e||e.seed!==run.seed||e.assist!==(run.mode==='calm')||!integer(e.stage,0,3)||!integer(e.score,0,600000)||!Number.isFinite(e.elapsed)||e.elapsed<0||e.elapsed>90*86400)throw new CupError('Сохранение не соответствует попытке.');
 if(!['menu','briefing','playing','paused','lesson','remark','boarding','docking','stageclear','escortbrief','escortclear','finalebrief','finalcheck','crashing','lost','won'].includes(e.status))throw new CupError('Неизвестный этап сохранения.');
 if(!Array.isArray(e.rescued)||e.rescued.length>12||!Array.isArray(e.completedRemarks)||e.completedRemarks.length>12||!Array.isArray(e.decisions)||e.decisions.length>8)throw new CupError('Повреждено сохранение решений.');
 safeTree(s);const serialized=JSON.stringify(s);if(serialized.length>220000)throw new CupError('Сохранение слишком большое.');
 return {clock:input.clock,snapshot:serialized};
}
export function checkedResult(body,run,previous){
 if(!body||!integer(body.level,0,13)||body.level!==run.progress)throw new CupError('Этапы необходимо проходить по порядку.',409);
 const rule=LEVELS[body.level];
 if(!integer(body.score,0,rule.max)||!integer(body.campaignScore,0,600000)||!integer(body.duration,rule.min*1000,30*86400000)||!integer(body.clock,body.duration,90*86400000))throw new CupError('Результат выходит за допустимые границы.');
 if(body.clock-(previous?.clock||0)<body.duration-1000)throw new CupError('Время этапа не согласовано с попыткой.');
 return body;
}
