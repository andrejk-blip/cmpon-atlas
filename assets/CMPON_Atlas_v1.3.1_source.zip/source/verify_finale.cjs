const {run,plain,assert,fs,createCanvas,root,node}=require('./campaign-harness.cjs');
run(`ARCADE.sound=false;ARCADE.fx=true;ARCADE.forceCPU=true;initialize();setView('arcade');
function completeEditions(e){e.start(true);e.beginStage(3);e.rescued=e.plan.flat();e.completedRemarks=Array.from({length:12},(_,i)=>i);e.decisions=Array.from({length:8},(_,i)=>({caseIndex:i,stage:Math.floor(i/2),reqId:e.plan[Math.floor(i/2)][i%2?2:0],firstTry:true,decision:CITADEL_LESSONS[i].correct}));e.modules().forEach(x=>x.dead=true);e.upgrades={weapons:2,armor:1,rockets:0};e.beginBoarding();e.board.completed=[9,10,11];e.board.enemies=[];}
globalThis.e=new RequirementArcade(417);ARCADE.engine=e;completeEditions(e);e.finishBoarding();`);
assert.equal(run('e.status'),'finalebrief');assert.equal(run('e.finale.phase'),'boss');assert(run('!!finaleReadSave()'));
run(`e.launchFinale();globalThis.bossStart=e.player.hp;for(let i=0;i<60*180&&e.finale.phase==='boss'&&e.status==='playing';i++)e.step(1/60,{fire:true,missile:e.player.missiles>0,pulse:e.player.hp<65});`);
console.log('boss',plain(run('({status:e.status,phase:e.finale.phase,time:e.finale.time,hp:e.player.hp,cores:e.enemies.map(x=>x.hp),boss:e.boss?.hp})')));
assert.equal(run('e.finale.phase'),'breach');
run(`for(let i=0;i<60*40&&e.finale.phase==='breach';i++)e.step(1/60,{});`);assert.equal(run('e.finale.phase'),'landing');
run(`e.pause();globalThis.freeze=e.finale.time;e.step(.04,{});`);assert.equal(run('e.finale.time'),run('freeze'));run('e.resume()');
run(`for(let i=0;i<60*15&&e.finale.phase==='landing';i++)e.step(1/60,{});`);assert.equal(run('e.finale.phase'),'maze');assert(!run('e.board.guide'));
const spawn=plain(run('e.board.pos'));run('for(let i=0;i<120;i++)e.step(1/60,{})');assert.deepStrictEqual(plain(run('e.board.pos')),spawn);
for(let trial=0;trial<3;trial++){
 run(`e.board.guide=true;for(let i=0;i<60*180&&e.status==='boarding';i++)e.step(1/60,{fire:true,pulse:true});`);
 console.log('maze',trial,plain(run('({status:e.status,hp:e.board.hp,pos:e.board.pos,n:e.board.completed.length,time:e.board.time,route:e.board.guideRoute?.length})')));
 assert.equal(run('e.status'),'finalcheck');const before=run('e.board.completed.length');run('e.answerFinale((FINALE_TRIALS[e.board.completed.length].correct+1)%3);e.continueFinaleCheck()');assert.equal(run('e.board.completed.length'),before);assert.equal(run('e.status'),'finalcheck');run('e.answerFinale(FINALE_TRIALS[e.board.completed.length].correct);e.continueFinaleCheck()');assert(!run('e.board.guide'));
}
run(`e.board.guide=true;for(let i=0;i<60*100&&e.finale.phase==='maze'&&e.status==='boarding';i++)e.step(1/60,{fire:true,pulse:true});`);assert.equal(run('e.finale.phase'),'mrg');assert(!run('e.board.guide'));
run(`e.board.guide=true;for(let i=0;i<60*180&&e.finale.phase==='mrg'&&e.status==='boarding';i++)e.step(1/60,{fire:true,pulse:true,missile:e.finale.open});`);
console.log('MRG',plain(run('({status:e.status,phase:e.finale.phase,time:e.finale.time,hp:e.board.hp,mrg:e.finale.mrg.hp})')));assert.equal(run('e.finale.phase'),'upload');run('for(let i=0;i<500;i++)e.step(1/60,{})');assert.equal(run('e.status'),'won');assert.equal(run('e.finale.phase'),'victory');assert(run('arcadeOverlayHTML().includes("finale-comic")'));
run(`ARCADE.finaleCheckpoint=null;finaleRestore();`);assert.equal(run('ARCADE.engine.finale.phase'),'upload');
// All sixty authored cases preserve answer semantics and original text lookup.
const cases=plain(run(`(()=>{const questions=new Set();for(let seed=0;seed<100;seed++){const e={seed};for(let i=0;i<8;i++){const q=citadelLessonCase(e,i);if(q.correct!==CITADEL_LESSONS[i].correct||q.choices.length!==4)throw Error('lesson');questions.add(q.situation)}for(let i=0;i<12;i++){const q=citadelRemarkCase(e,i);if(q.correct!==CITADEL_REMARKS[i].correct||q.choices.length!==3)throw Error('remark');questions.add(q.q)}}return questions.size})()`));assert.equal(cases,60);
// Deterministic source render samples are real engine output, not mockups.
fs.mkdirSync(root+'/qa120',{recursive:true});
function render(name,expr){run(expr);run('ARCADE.engine=e');const canvas=createCanvas(1280,720);const ctx=canvas.getContext('2d');const items=run('spaceScene(e,e.elapsed,true)'),cam=run('spaceCamera(e,e.elapsed)');run('ARCADE.hudTime=0;updateArcadeHUD();updateArcadeOverlay()');require('vm').runInContext('void 0',require('./campaign-harness.cjs').context);require('./campaign-harness.cjs').context.qaCtx=ctx;run('spaceDrawCPU(qaCtx,spaceScene(e,e.elapsed,true),spaceCamera(e,e.elapsed),1280,720)');fs.writeFileSync(root+'/qa120/'+name+'.png',canvas.toBuffer('image/png'));console.log('render',name,items.length);}
render('boss',`e=new RequirementArcade(417);completeEditions(e);e.beginFinale();e.launchFinale();for(let i=0;i<90;i++)e.step(1/60,{});e.missile();for(let i=0;i<10;i++)e.step(1/60,{})`);
render('landing',`e.beginBreach();e.player.pos=[0,0,-126];e.beginFinalLanding();for(let i=0;i<360;i++)e.step(1/60,{})`);
render('maze',`e.beginLair();for(let i=0;i<120;i++)e.step(1/60,{moveZ:-1});`);
render('mrg',`e.beginMRG();for(let i=0;i<230;i++)e.step(1/60,{fire:true});`);
console.log('PASS: natural finale flow, pause, manual ground entry, wrong answers, three tests, MRG, upload, save restoration, 60 cases and renders');
