import ctypes as C, json, os
from pathlib import Path
os.environ['EGL_PLATFORM']='surfaceless'
E=C.CDLL('libEGL.so.1')
def egl(name,restype,args):
 f=getattr(E,name);f.restype=restype;f.argtypes=args;return f
ptr=C.c_void_p;I=C.c_int;U=C.c_uint;F=C.c_float
get=egl('eglGetDisplay',ptr,[ptr]);init=egl('eglInitialize',U,[ptr,C.POINTER(I),C.POINTER(I)]);choose=egl('eglChooseConfig',U,[ptr,C.POINTER(I),C.POINTER(ptr),I,C.POINTER(I)]);bind=egl('eglBindAPI',U,[U]);context=egl('eglCreateContext',ptr,[ptr,ptr,ptr,C.POINTER(I)]);surface=egl('eglCreatePbufferSurface',ptr,[ptr,ptr,C.POINTER(I)]);current=egl('eglMakeCurrent',U,[ptr,ptr,ptr,ptr]);getproc=egl('eglGetProcAddress',ptr,[C.c_char_p])
d=get(None);a=I();b=I();assert init(d,C.byref(a),C.byref(b)),'EGL init';attrs=(I*17)(0x3033,1,0x3040,4,0x3024,8,0x3023,8,0x3022,8,0x3021,8,0x3025,24,0x3038,0,0);config=ptr();count=I();assert choose(d,attrs,C.byref(config),1,C.byref(count)) and count.value,'EGL config';assert bind(0x30A0);ctx=context(d,config,None,(I*3)(0x3098,2,0x3038));assert ctx,'EGL ES2 context';surf=surface(d,config,(I*5)(0x3057,1280,0x3056,720,0x3038));assert current(d,surf,surf,ctx)
def gl(n,r,*types):
 p=getproc(n.encode());assert p,n;return C.CFUNCTYPE(r,*types)(p)
createShader=gl('glCreateShader',U,U);shaderSource=gl('glShaderSource',None,U,I,C.POINTER(C.c_char_p),ptr);compileShader=gl('glCompileShader',None,U);getShaderiv=gl('glGetShaderiv',None,U,U,C.POINTER(I));info=gl('glGetShaderInfoLog',None,U,I,ptr,C.c_char_p);createProgram=gl('glCreateProgram',U);attach=gl('glAttachShader',None,U,U);link=gl('glLinkProgram',None,U);getP=gl('glGetProgramiv',None,U,U,C.POINTER(I));getPi=gl('glGetProgramInfoLog',None,U,I,ptr,C.c_char_p);use=gl('glUseProgram',None,U);getA=gl('glGetAttribLocation',I,U,C.c_char_p);getU=gl('glGetUniformLocation',I,U,C.c_char_p);uniform1=gl('glUniform1f',None,I,F);uniform3=gl('glUniform3fv',None,I,I,C.POINTER(F));matrix=gl('glUniformMatrix4fv',None,I,I,C.c_ubyte,C.POINTER(F));gen=gl('glGenBuffers',None,I,C.POINTER(U));bindB=gl('glBindBuffer',None,U,U);bufferData=gl('glBufferData',None,U,C.c_ssize_t,ptr,U);enableA=gl('glEnableVertexAttribArray',None,U);attrib=gl('glVertexAttribPointer',None,U,I,U,C.c_ubyte,I,ptr);draw=gl('glDrawArrays',None,U,I,I);enable=gl('glEnable',None,U);disable=gl('glDisable',None,U);depth=gl('glDepthMask',None,C.c_ubyte);blend=gl('glBlendFunc',None,U,U);clear=gl('glClear',None,U);clearcol=gl('glClearColor',None,F,F,F,F);viewport=gl('glViewport',None,I,I,I,I);read=gl('glReadPixels',None,I,I,I,I,U,U,ptr);error=gl('glGetError',U);getstr=gl('glGetString',C.c_char_p,U)
root=Path(__file__).parent; payload=json.loads((root/(os.environ.get('QA_SCENE','boss')+'.json')).read_text())
def prog(vs,fs):
 p=createProgram()
 for typ,src in [(0x8B31,vs),(0x8B30,fs)]:
  sh=createShader(typ);s=C.c_char_p(src.encode());shaderSource(sh,1,C.byref(s),None);compileShader(sh);ok=I();getShaderiv(sh,0x8B81,C.byref(ok));log=C.create_string_buffer(4000);info(sh,4000,None,log);assert ok.value,log.value.decode();attach(p,sh)
 link(p);ok=I();getP(p,0x8B82,C.byref(ok));log=C.create_string_buffer(4000);getPi(p,4000,None,log);assert ok.value,log.value.decode();return p
p=prog(payload['vertex'],payload['fragment']);sky=prog(payload['skyVertex'],payload['skyFragment']);post=prog(payload['postVertex'],payload['postFragment']);print('Shaders compiled and linked:',getstr(0x1F02).decode())
def floats(v): return (F*len(v))(*v)
def buf(values):
 b=U();gen(1,C.byref(b));bindB(0x8892,b.value);a=floats(values);bufferData(0x8892,C.sizeof(a),a,0x88E4);return b.value
buffers={n:(buf(m['p']),buf(m['n']),len(m['p'])//3) for n,m in payload['meshes'].items()}
def uniform(p,n,values):
 loc=getU(p,n.encode())
 if isinstance(values,(float,int)):uniform1(loc,values)
 elif len(values)==3:uniform3(loc,1,floats(values))
 elif len(values)==16:matrix(loc,1,0,floats(values))

genTex=gl('glGenTextures',None,I,C.POINTER(U));bindTex=gl('glBindTexture',None,U,U);texParam=gl('glTexParameteri',None,U,U,I);texImage=gl('glTexImage2D',None,U,I,I,I,I,I,U,U,ptr);activeTex=gl('glActiveTexture',None,U);genFBO=gl('glGenFramebuffers',None,I,C.POINTER(U));bindFBO=gl('glBindFramebuffer',None,U,U);fboTex=gl('glFramebufferTexture2D',None,U,U,U,U,I);checkFBO=gl('glCheckFramebufferStatus',U,U);genDepth=gl('glGenRenderbuffers',None,I,C.POINTER(U));bindDepth=gl('glBindRenderbuffer',None,U,U);depthStorage=gl('glRenderbufferStorage',None,U,U,I,I);fboDepth=gl('glFramebufferRenderbuffer',None,U,U,U,U);uniform2=gl('glUniform2f',None,I,F,F);uniformInt=gl('glUniform1i',None,I,I);disableA=gl('glDisableVertexAttribArray',None,U)
def target(w,h,with_depth=False):
 tex=U();genTex(1,C.byref(tex));bindTex(0x0DE1,tex.value)
 for k,v in [(0x2801,0x2601),(0x2800,0x2601),(0x2802,0x812F),(0x2803,0x812F)]:texParam(0x0DE1,k,v)
 texImage(0x0DE1,0,0x1908,w,h,0,0x1908,0x1401,None);fbo=U();genFBO(1,C.byref(fbo));bindFBO(0x8D40,fbo.value);fboTex(0x8D40,0x8CE0,0x0DE1,tex.value,0)
 if with_depth:
  db=U();genDepth(1,C.byref(db));bindDepth(0x8D41,db.value);depthStorage(0x8D41,0x81A5,w,h);fboDepth(0x8D40,0x8D00,0x8D41,db.value)
 assert checkFBO(0x8D40)==0x8CD5,'Framebuffer incomplete'
 return {'texture':tex.value,'framebuffer':fbo.value,'w':w,'h':h}
sceneTarget=target(1280,720,True);aTarget=target(640,360);bTarget=target(640,360);bindFBO(0x8D40,sceneTarget['framebuffer'])

import math
cam=payload['camera'];viewport(0,0,1280,720);clearcol(.01,.02,.04,1);clear(0x4000|0x0100);disable(0x0B71);disable(0x0BE2);use(sky);idx=getA(sky,b'aPos');enableA(idx);bindB(0x8892,buf([-1,-1,3,-1,-1,3]));attrib(idx,2,0x1406,0,0,None)
for n,v in [('uForward',cam['f']),('uRight',cam['r']),('uUp',cam['u']),('uAspect',1280/720),('uTan',math.tan(cam['fov']/2))]:uniform(sky,n,v)
draw(4,0,3);use(p);enable(0x0B71);disable(0x0B44);blend(0x0302,0x0303);pa=getA(p,b'aPosition');na=getA(p,b'aNormal');enableA(pa);enableA(na);r,u,f,pos=cam['r'],cam['u'],cam['f'],cam['pos'];dot=lambda a,b:sum(x*y for x,y in zip(a,b));view=[r[0],u[0],-f[0],0,r[1],u[1],-f[1],0,r[2],u[2],-f[2],0,-dot(r,pos),-dot(u,pos),dot(f,pos),1];near=cam.get("near",3.5);far=cam.get("far",6000);t=1/math.tan(cam['fov']/2);projection=[t*720/1280,0,0,0,0,t,0,0,0,0,(far+near)/(near-far),-1,0,0,2*far*near/(near-far),0]
uniform(p,'uView',view);uniform(p,'uProjection',projection);uniform(p,'uEye',pos);uniform(p,'uInterior',cam.get('interior',0))
for i,suffix in enumerate(['A','B','C']):
 light=(cam.get('lights',[])+[{}]*3)[i];uniform(p,'uLight'+suffix,light.get('pos',[0,0,0]));uniform(p,'uTint'+suffix,light.get('color',[0,0,0]))
items=payload['scene'];ordered=[i for i in items if i['alpha']==1]+sorted([i for i in items if i['alpha']<1],key=lambda i:-sum((a-b)**2 for a,b in zip(i['pos'],pos)))
for i in ordered:
 if i['alpha']<1:enable(0x0BE2);depth(0)
 bp,bn,count=buffers[i['mesh']];bindB(0x8892,bp);attrib(pa,3,0x1406,0,0,None);bindB(0x8892,bn);attrib(na,3,0x1406,0,0,None)
 for name,value in [('uModel',i['model']),('uColor',i['color']),('uEmissive',i['emissive']),('uAlpha',i['alpha']),('uKind',i['kind'])]:uniform(p,name,value)
 draw(4,0,count)

depth(1)
quad=buf([-1,-1,3,-1,-1,3])
def postPass(target,source,mode,dx=0,dy=0,bloom=None):
 bloom=bloom or source;bindFBO(0x8D40,target['framebuffer'] if target else 0);viewport(0,0,target['w'] if target else 1280,target['h'] if target else 720);use(post);disable(0x0B71);disable(0x0BE2);disableA(na);at=getA(post,b'aPos');enableA(at);bindB(0x8892,quad);attrib(at,2,0x1406,0,0,None)
 activeTex(0x84C0);bindTex(0x0DE1,source['texture']);uniformInt(getU(post,b'uScene'),0);activeTex(0x84C1);bindTex(0x0DE1,bloom['texture']);uniformInt(getU(post,b'uBloom'),1);uniform2(getU(post,b'uTexel'),1/source['w'],1/source['h']);uniform2(getU(post,b'uDirection'),dx,dy);uniform1(getU(post,b'uMode'),mode);draw(4,0,3);activeTex(0x84C0)
postPass(aTarget,sceneTarget,0);postPass(bTarget,aTarget,1,1,0);postPass(aTarget,bTarget,1,0,1);postPass(bTarget,aTarget,1,2,0);postPass(aTarget,bTarget,1,0,2);postPass(None,sceneTarget,2,bloom=aTarget)

assert error()==0,'GL error'
rgba=(C.c_ubyte*(1280*720*4))();read(0,0,1280,720,0x1908,0x1401,rgba)
from PIL import Image
im=Image.frombytes('RGBA',(1280,720),bytes(rgba)).transpose(Image.Transpose.FLIP_TOP_BOTTOM);im.save(root/(os.environ.get('QA_SCENE','boss')+'-gl.png'));print('Native GLES production shaders and meshes rendered successfully')
