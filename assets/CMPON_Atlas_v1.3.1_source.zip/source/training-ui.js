/* Phone review cards: question, source text and explanation are separate views. */
const REVIEW_CARD={key:'',pane:'question',page:0};
const MOBILE_REMARK_CHOICES=[
 ['Запросить сценарий, затруднение и результат','Добавить слово «удобный» и закрыть','Отклонить любую просьбу об удобстве'],
 ['Отклонить: смысл можно угадать','Унифицировать термин и связанные ссылки','Переписать весь раздел'],
 ['Снова изменить ФТ','Оставить открытым бессрочно','Связать дубль с решением и местом правки'],
 ['Отклонить удаление; запросить варианты и влияние','Удалить ради оценки сроков','Назвать удаление редакционной правкой'],
 ['Отклонить: ФТ уже отправлены','Устранить конфликт, проверить ФТ и ПМИ','Удалить оба требования'],
 ['Согласовать: так короче','Убрать критерии из ПМИ','Отклонить замену, сохранить проверяемость'],
 ['Развести термины, границы и требования','Отклонить: оба контура непубличные','Назвать оба контура «вторым»'],
 ['Принять: роль уже есть','Отклонить трактовку, проверить особые права','Временно дать доступ всем'],
 ['Удалить поздний комментарий','Принять оптимистичную оценку','Сохранить аргументы и проверить основание'],
 ['В развитие; сначала оценить влияние','Добавить без изменения сроков','Удалить предложение навсегда'],
 ['Закрыть блокер формально','Отработать блокер до согласования','Скрыть запись в реестре'],
 ['Начать новый круг без основания','Удалить историю обсуждения','Отклонить повтор со ссылкой на решение']
];
function reviewCardReset(e){const key=e.status+'|'+(e.status==='lesson'?e.lesson?.caseIndex:e.board?.question)+'|'+(e.lesson?.attempts||0)+'|'+(e.remarkFeedback?.index??'');if(REVIEW_CARD.key!==key){REVIEW_CARD.key=key;REVIEW_CARD.pane='question';REVIEW_CARD.page=0}}
function reviewTextPages(text,width,height){
 // Conservative character budget; preserve the exact source including whitespace.
 const cols=Math.max(18,Math.floor((width-40)/8)),lines=Math.max(3,Math.floor((height-148)/21)),limit=Math.max(60,Math.min(1200,cols*lines));const pages=[];let offset=0;
 while(offset<text.length){let end=Math.min(text.length,offset+limit);if(end<text.length){const space=text.lastIndexOf(' ',end);if(space>offset+limit*.6)end=space+1}pages.push(text.slice(offset,end));offset=end}return pages.length?pages:[''];
}
function reviewViewport(){const rect=document.getElementById('arcade-screen')?.getBoundingClientRect();return {w:Math.min(rect?.width||globalThis.innerWidth||390,globalThis.innerWidth||390),h:Math.min(rect?.height||globalThis.visualViewport?.height||700,globalThis.visualViewport?.height||globalThis.innerHeight||700)-44}}
function mobileReviewHTML(e){
 reviewCardReset(e);const lesson=e.status==='lesson',l=e.lesson,q=lesson?citadelLessonCase(e,l.caseIndex):citadelRemarkCase(e,e.board.question),r=lesson?REQS.get(l.reqId):null,feedback=lesson?l.feedback:e.remarkFeedback,solved=lesson?l.solved:feedback?.correct,index=lesson?l.caseIndex+1:e.board.question+1;
 const heading='<header class="review-card-heading"><span>'+ (lesson?'МОДУЛЬ '+r.number:'ТЕРМИНАЛ '+(e.board.question%3+1))+'</span><b>'+index+' / '+(lesson?8:12)+' · ПАУЗА</b></header>';
 const buttons=(current,total)=>'<nav class="review-page-nav" aria-label="Страницы текста"><button data-action="citadel-review-page" data-value="-1" aria-label="Предыдущая страница" '+(current===0?'disabled':'')+'>←</button><span>'+ (current+1)+' / '+total+'</span><button data-action="citadel-review-page" data-value="1" aria-label="Следующая страница" '+(current===total-1?'disabled':'')+'>→</button></nav>';
 if(REVIEW_CARD.pane==='source'){
  const size=reviewViewport(),pages=reviewTextPages(r.text,size.w,size.h),page=arcadeClamp(REVIEW_CARD.page,0,pages.length-1);REVIEW_CARD.page=page;
  return '<section class="review-card review-reader">'+heading+'<div class="review-reader-title"><h3>'+r.number+' · исходный текст</h3><button data-action="citadel-review-question">К вопросу ↗</button></div><p class="review-source-text">'+esc(pages[page])+'</p>'+buttons(page,pages.length)+'<small>Текст ФТ без изменений. Перелистывайте стрелками.</small></section>';
 }
 if(feedback){
  const text=q.why+(solved&&q.followup?'\n\n'+q.followup:''),size=reviewViewport(),pages=reviewTextPages(text,size.w,size.h-20),page=arcadeClamp(REVIEW_CARD.page,0,pages.length-1);REVIEW_CARD.page=page;
  return '<section class="review-card review-result '+(solved?'is-correct':'is-wrong')+'">'+heading+'<h3>'+(solved?'Решение обосновано':'Попробуйте другой аргумент')+'</h3><p class="review-source-text" role="status">'+esc(pages[page])+'</p>'+(pages.length>1?buttons(page,pages.length):'')+'<button class="review-continue" data-action="'+(lesson?(solved?'citadel-lesson-next':'citadel-lesson-retry'):'citadel-remark-next')+'">'+(solved?(lesson?'Вернуться в полёт':'Дальше по коридору'):'Вернуться к вариантам')+' ↗</button><small>'+(solved?(lesson?'Щит восстановлен · усиленная плазма на 12 секунд':'Решение внесено в учебный реестр'):'Бой остановлен. Можно спокойно разобраться.')+'</small></section>';
 }
 const choices=lesson?['Учесть в этой редакции','Запросить уточнение','Отклонить с основанием','В отдельное развитие']:q.choices;
 return '<section class="review-card review-question '+(lesson?'is-lesson':'is-remark')+'">'+heading+'<div class="review-prompt">'+citadelCommentMeta(q)+'<h3>'+(lesson?'Как отработать замечание?':esc(q.q))+'</h3>'+(lesson?'<p>'+esc(q.situation)+'</p><button class="review-source-button" data-action="citadel-review-source">Прочитать '+r.number+' ↗</button>':'')+'</div><div class="review-choice-area"><span>ВЫБЕРИТЕ РЕШЕНИЕ</span><div class="review-choices">'+choices.map((x,i)=>'<button data-action="'+(lesson?'citadel-lesson-answer':'citadel-answer')+'" data-value="'+i+'" aria-label="'+attr(q.choices[i])+'"><b>'+(i+1)+'</b><span>'+esc(x)+'</span></button>').join('')+'</div></div><small class="review-disclaimer">Учебная ситуация. Оценки и текст атласа не меняются.</small></section>';
}
function mobileReviewAction(action,value){if(!['citadel-review-source','citadel-review-question','citadel-review-page','citadel-lesson-retry'].includes(action))return false;const e=ARCADE.engine;if(!['lesson','remark'].includes(e?.status))return true;if(action==='citadel-review-source'&&e.status==='lesson'){REVIEW_CARD.pane='source';REVIEW_CARD.page=0}else if(action==='citadel-review-question'){REVIEW_CARD.pane='question';REVIEW_CARD.page=0}else if(action==='citadel-review-page'){REVIEW_CARD.page=Math.max(0,REVIEW_CARD.page+(Number(value)===-1?-1:1))}else if(action==='citadel-lesson-retry'&&e.status==='lesson'&&!e.lesson.solved){e.lesson.feedback=null;REVIEW_CARD.page=0}ARCADE.overlayToken='';updateArcadeOverlay();return true}
