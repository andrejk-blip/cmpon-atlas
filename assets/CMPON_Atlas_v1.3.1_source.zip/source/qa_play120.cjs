const h=require('./campaign-harness.cjs');const files=require('fs').readFileSync('campaign-harness.cjs','utf8').match(/source=(\[[\s\S]*?\])\.map/)[1];const list=Function('return '+files)();const source=list.map(f=>h.fs.readFileSync(f,'utf8')).join('\n');const test=`
function play(seed,assist){const e=new RequirementArcade(seed);e.start(assist);e.launch();let trace=[],last='',longest=0,stationAt=0,phaseSince=0;
for(let frame=0;frame<60*2000;frame++){const stamp=e.stage+':'+e.phase+':'+e.status+':'+(e.finale?.phase||'')+':'+(e.board?.completed.length||0);if(stamp!==last){trace.push({t:Math.round(e.elapsed),s:stamp,hp:Math.round(e.board?.hp??e.player.hp)});longest=Math.max(longest,e.elapsed-phaseSince);phaseSince=e.elapsed;last=stamp;}
if(e.status==='won'||e.status==='lost')break;
if(e.status==='stageclear'){e.chooseUpgrade(['weapons','armor','weapons'][e.stage]);e.next();e.launch();continue}
if(e.status==='escortbrief'){e.launch();continue}if(e.status==='escortclear'){e.completeEscort();e.launch();continue}
if(e.status==='lesson'){e.answerLesson(CITADEL_LESSONS[e.lesson.caseIndex].correct);e.continueLesson();continue}
if(e.status==='remark'){e.answer(CITADEL_REMARKS[e.board.question].correct);e.continueRemark();continue}
if(e.status==='finalebrief'){e.launchFinale();continue}if(e.status==='finalcheck'){e.answerFinale(FINALE_TRIALS[e.board.completed.length].correct);e.continueFinaleCheck();continue}
let input={fire:true,pulse:true,missile:!!e.target()};if(e.status==='boarding'){e.board.guide=true;input.missile=!!e.finale?.open}else if(e.status==='playing'){e.autopilot=true;if(e.phase==='battle'&&frame%180===0){const danger=e.enemies.filter(x=>!x.dead&&x.channel).sort((a,b)=>e.nodes[a.node].integrity-e.nodes[b.node].integrity)[0];if(danger)e.selectedTarget=danger.id}}
e.step(1/60,input);
}
return {seed,assist,status:e.status,phase:e.phase,finale:e.finale?.phase,time:Math.round(e.elapsed),stage:e.stage,modules:e.rescued.length,remarks:e.completedRemarks.length,decisions:e.decisions.length,collisions:e.collisionCount||0,recoveries:e.navRecoveries||0,pos:e.player.pos,target:e.navTarget()?.pos,longest,reason:e.lossReason,trace}}
return [[417,true],[20261015,false],[19,true]].map(([s,a])=>play(s,a));`;
const result=h.vm.compileFunction(source+'\n'+test,Object.keys(h.context))(...Object.values(h.context));h.fs.writeFileSync('qa120/campaign-runs.json',JSON.stringify(result,null,2));for(const r of result)console.log(JSON.stringify(r));if(result.some(r=>r.status!=='won'))process.exitCode=1;
