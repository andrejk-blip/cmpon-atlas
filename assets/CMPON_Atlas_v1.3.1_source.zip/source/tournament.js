/* Tournament integration v1.1.0. In-game records and name-only device entry; no owner test shortcuts. */
const CUP_API='https://cmpon-metrics-service.carlafloriano1958.chatgpt.site/api/tournament/';
const CUP={config:null,player:null,token:'',runs:[],run:null,clock:0,startClock:0,startScore:0,progress:0,queue:[],sending:false,conflict:false,saveText:'',board:-1,selected:'',mode:'calm',rows:null,error:'',ready:false,lastSave:0,attached:false,panel:null,panelState:null,panelFocus:null,uiRevision:0,boardSerial:0,boardError:'',busy:false,nameDraft:'',deviceKey:'',verified:false,recovered:false,authPromise:null,refreshPromise:null,flushPromise:null};
const CUP_LEVELS=['Орбита ФЗ','Архив ФЗ','Коридор исполнения','Орбита исполнителя','Машинный зал','Переход интеграций','Орбита смежников','Палуба интеграций','Последняя миля','Итоговая орбита','Палуба менеджмента','Параллакс','Лабиринт логова','Главный компьютер МРГ'];
const CUP_ENGINE_KEYS='seed plan status stage assist score rescued lastRescued elapsed totalKills shots hits combo maxCombo comboTime player stageKills stageTime enemies bullets hostile pickups particles trails boss bossDefeated entityId flash shake hitFlash spawnClock pulseWave lock warning asteroids station portal phase wave waveSpawned waveClock phaseClock stationHp nodes upgrades upgradeChoice selectedTarget autopilot captain captainClock lossReason explosions board remarkFeedback lastDamage completedRemarks decisions lessonQueue lesson navMode toast firstActionTime resumeStatus escorts escort crash speechUntil finale navWatch missileFlash caseBank dock stageStart waveSpawnTimer idleHintClock location'.split(' ');
const CUP_OMIT=new Set(['hullCache','detour','nav','pathCache','guideRoute']);
function cupPack(e){const engine={};for(const k of CUP_ENGINE_KEYS)if(e[k]!==undefined)engine[k]=e[k];return JSON.parse(JSON.stringify({schema:1,engine,rng:e.random.getState(),meta:{clock:CUP.clock,startClock:CUP.startClock,startScore:CUP.startScore,progress:CUP.progress}},(k,v)=>CUP_OMIT.has(k)?undefined:v instanceof Set?{_cupSet:[...v]}:v instanceof Map?{_cupMap:[...v]}:v));}
function cupUnpack(snapshot,run,emit=arcadeEvent){if(snapshot?.schema!==1||snapshot.engine.seed!==run.seed||snapshot.engine.assist!==(run.mode==='calm'))throw Error('Сохранение несовместимо с попыткой.');const saved=JSON.parse(JSON.stringify(snapshot),(_,v)=>v&&Array.isArray(v._cupSet)?new Set(v._cupSet):v&&Array.isArray(v._cupMap)?new Map(v._cupMap):v);const e=new RequirementArcade(run.seed);e.start(run.mode==='calm');for(const k of CUP_ENGINE_KEYS)if(Object.hasOwn(saved.engine,k))e[k]=saved.engine[k];e.random=arcadeSeed(snapshot.rng);e.hullCache=null;e.detour=null;if(e.board?.cells)stationBuildNav(e.board);e.emit=emit;return e;}
function cupPersist(){try{localStorage.setItem('cmpon.cup.session.v1',JSON.stringify({token:CUP.token,player:CUP.player}));if(CUP.run)localStorage.setItem('cmpon.cup.outbox.v1',JSON.stringify({playerId:CUP.player?.id,run:CUP.run,queue:CUP.queue,progress:CUP.progress,clock:CUP.clock,startClock:CUP.startClock,startScore:CUP.startScore}));}catch{CUP.saveText='Память браузера заполнена — не закрывайте игру до синхронизации.';}}
async function cupAPI(path,body){const r=await fetch(CUP_API+path,{method:body?'POST':'GET',mode:'cors',credentials:'omit',headers:{...(body?{'Content-Type':'application/json'}:{}),...(CUP.token?{Authorization:'Bearer '+CUP.token}:{})},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(15000)});let data;try{data=await r.json();}catch{throw Error('Не удалось прочитать ответ сервера.');}if(!r.ok){const err=Error(data.error||'Не удалось выполнить запрос.');err.status=r.status;throw err;}return data;}
function cupStatus(t){CUP.saveText=t;const el=document.getElementById('cup-save-status');if(el)el.textContent=t;const bar=document.getElementById('arcade-renderer');if(bar&&CUP.attached){bar.textContent=t;bar.title=t;}}
function cupEnqueue(result){if(CUP.progress===14&&!result)return;if(!CUP.attached||!CUP.run||CUP.conflict||!ARCADE.engine||CUP.run.status==='complete')return;const job={id:CUP.run.id,requestId:crypto.randomUUID(),clock:Math.round(CUP.clock),snapshot:cupPack(ARCADE.engine),...(result?{result}:{})};const last=CUP.queue.at(-1);if(!result&&last&&!last.result&&!last.revisionAssigned)CUP.queue[CUP.queue.length-1]=job;else CUP.queue.push(job);cupPersist();cupStatus('Сохраняем…');void cupFlush();}
function cupFlush(){
 if(CUP.flushPromise)return CUP.flushPromise;
 if(CUP.conflict||!CUP.run||!CUP.queue.length)return Promise.resolve();
 CUP.sending=true;
 CUP.flushPromise=(async()=>{try{
  while(CUP.queue.length){
   const job=CUP.queue[0];if(!job.revisionAssigned){job.revision=CUP.run.revision;job.revisionAssigned=true;cupPersist();}
   const {revisionAssigned,...body}=job;let data;
   try{data=await cupAPI('save',body);}catch(e){if(e.status!==401)throw e;CUP.verified=false;await cupEnsureProfile();data=await cupAPI('save',body);}
   CUP.run={...CUP.run,...data.run};CUP.queue.shift();cupPersist();
  }
  cupStatus(CUP.run.status==='complete'?'Победа сохранена · результат в рекордах':'Сохранено · '+CUP.progress+'/14 этапов');
 }catch(e){
  if([400,409,413].includes(e.status)){CUP.conflict=true;ARCADE.engine?.pause();cupStatus(e.message+' Вернитесь в меню игры и продолжите из облака.');}
  else if(e.status===401){ARCADE.engine?.pause();cupStatus('Не удалось восстановить вход. Сохранение осталось в этом браузере.');}
  else cupStatus('Нет связи · сохранено на устройстве, повторим отправку.');
 }finally{CUP.sending=false;}})();
 return CUP.flushPromise.finally(()=>{CUP.flushPromise=null;});
}
function cupComplete(level,e){if(e!==ARCADE.engine||!CUP.attached||!CUP.run||CUP.progress!==level||CUP.conflict)return;const clock=Math.round(CUP.clock),result={level,score:Math.max(0,Math.round(e.score-CUP.startScore)),campaignScore:Math.round(e.score),duration:Math.max(0,clock-Math.round(CUP.startClock)),clock};CUP.progress++;CUP.startClock=CUP.clock;CUP.startScore=e.score;cupEnqueue(result);}
function cupHook(name,levelFn,success){const original=RequirementArcade.prototype[name];RequirementArcade.prototype[name]=function(...args){const level=levelFn(this),before=this.status;const result=original.apply(this,args);if(level!==null&&success(this,result,before)){if(name==='beginBoarding'&&this===ARCADE.engine&&CUP.attached&&CUP.progress===level+1){CUP.startScore=this.score;}cupComplete(level,this);}return result;};}
cupHook('beginBoarding',e=>e.finale?null:e.stage*3,(e)=>e.status==='boarding');
cupHook('finishBoarding',e=>e.finale?null:e.stage*3+1,(_,r)=>r===true);
cupHook('finishEscort',e=>e.stage*3+2,e=>e.status==='escortclear');
cupHook('beginBreach',()=>11,e=>e.finale?.phase==='breach');
cupHook('beginMRG',()=>12,e=>e.finale?.phase==='mrg');
cupHook('beginUpload',()=>13,(e,r)=>r===true&&e.finale?.phase==='upload');
function cupTick(dt){if(!CUP.panel&&CUP.attached&&CUP.run&&!CUP.conflict&&!document.hidden&&['playing','boarding','docking','lesson','remark','finalcheck','crashing'].includes(ARCADE.engine?.status))CUP.clock+=dt*1000;}
const cupOriginalFrame=arcadeFrame;arcadeFrame=function(now){if(ARCADE.canvas&&STATE.view==='arcade')cupTick(Math.min(.04,Math.max(0,(now-ARCADE.lastTime)/1000)));cupOriginalFrame(now);};
const cupOriginalRetry=citadelRetry;citadelRetry=function(calm=false){if(CUP.run){const old=ARCADE.engine;cupOriginalRetry(CUP.run.mode==='calm');ARCADE.engine.assist=CUP.run.mode==='calm';// Retrying a deck repeats its orbit. Previously credited levels are not submitted again.
 if(!old.finale&&old.phase!=='escort'&&CUP.progress===old.stage*3+1)CUP.startScore=ARCADE.engine.score;cupEnqueue();return;}return cupOriginalRetry(calm);};
// A player's random device key owns their progress; a display name is never an access key.
const CUP_GAME_VERSION='1.3.0'; // Preserve existing 1.3.0 campaigns across this UI update.
const CUP_DEVICE_KEY='cmpon.cup.device.v1';
const cupOriginalMobileAction=mobileAction;mobileAction=function(action,value){if(CUP.panel&&action.startsWith('mobile-')&&!['mobile-menu','mobile-menu-close','mobile-play'].includes(action))return true;if(CUP.panel&&action==='mobile-play')cupClosePanel(false);return cupOriginalMobileAction(action,value);};
function cupDeviceKey(){
 if(CUP.deviceKey)return CUP.deviceKey;
 const bytes=crypto.getRandomValues(new Uint8Array(32));
 CUP.deviceKey='cpd_'+Array.from(bytes,x=>x.toString(16).padStart(2,'0')).join('');
 try{localStorage.setItem(CUP_DEVICE_KEY,CUP.deviceKey);}catch{CUP.error='Браузер не сохранил вход. Не закрывайте эту вкладку до конца игры.';}
 return CUP.deviceKey;
}
async function cupEnsureProfile(name){
 if(CUP.authPromise)return CUP.authPromise;
 if(CUP.verified&&CUP.token)return CUP.player;
 CUP.authPromise=(async()=>{
  // Bind an already signed-in legacy player without changing their identity or scores.
  if(CUP.token&&!CUP.deviceKey){try{const m=await cupAPI('me');CUP.player=m.player;}catch(e){if(e.status!==401)throw e;CUP.token='';CUP.player=null;cupPersist();}}
  if(!name&&!CUP.deviceKey&&!CUP.token)return null;
  try{
   const auth=await cupAPI('enter',{deviceKey:cupDeviceKey(),...(name?{name}:{})});
   CUP.token=auth.token;CUP.player=auth.player;CUP.verified=true;cupPersist();return CUP.player;
  }catch(e){if(!name&&[400,401].includes(e.status)){CUP.token='';CUP.player=null;CUP.verified=false;cupPersist();return null;}throw e;}
 })();
 try{return await CUP.authPromise;}finally{CUP.authPromise=null;}
}
function cupDate(n){return new Intl.DateTimeFormat('ru-RU',{day:'numeric',month:'long',hour:'2-digit',minute:'2-digit',timeZone:'Europe/Moscow'}).format(n);}
function cupTime(ms){const s=Math.floor(ms/1000);return `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;}
function cupCurrent(){return CUP.config?.cups.find(c=>c.state==='active')||CUP.config?.cups.find(c=>c.announced&&c.state==='upcoming')||CUP.config?.cups.find(c=>c.announced&&c.state==='finished')||null;}
function cupNotice(c=cupCurrent()){
 if(!CUP.ready)return '<span>Подключаем результаты…</span>';
 if(!c)return '<span>Результаты сохраняются в общей таблице рекордов.</span>';
 const text=c.state==='active'?`Турнир идёт · итоги фиксируются ${cupDate(c.endsAt)} МСК`:c.state==='upcoming'?`Старт ${cupDate(c.startsAt)} МСК · итоги ${cupDate(c.endsAt)} МСК`:`Итоги зафиксированы ${cupDate(c.endsAt)} МСК`;
 return `<strong>${esc(c.title)}</strong><span>${esc(text)}</span>`;
}
function cupPlayableRun(){const id=CUP.config?.cups.find(c=>c.state==='active')?.id||null;return [CUP.run,...CUP.runs].find(r=>r&&r.cupId===id&&r.status==='active'&&r.progress<14&&r.gameVersion===CUP_GAME_VERSION)||null;}
function cupLobbyHTML(){
 const c=cupCurrent(),r=cupPlayableRun(),active=c?.state==='active';
 return `<div class="arcade-menu campaign-menu cup-lobby"><div class="cup-lobby-heading"><span class="arcade-serial">РЕДАКЦИЯ ПОД ЗАЩИТОЙ</span><h3>ЦИТАДЕЛЬ <span>ЦСИИ</span></h3><p>Защитите ФТ от лишних замечаний и доведите документ до согласования.</p></div>
 <div class="cup-notice" id="cup-notice" role="status">${cupNotice()}</div>
 <div class="cup-entry">${CUP.player?`<div class="cup-identity"><span>Аналитик <b>${esc(CUP.player.name)}</b></span><button class="cup-link" data-action="cup-rename">Изменить имя</button></div><button class="arcade-play" data-action="cup-play"${CUP.busy?' disabled':''}>${CUP.busy?'Подключаем…':r?(CUP.conflict?'Продолжить из облака':'Продолжить игру')+' · '+r.progress+'/14': 'Начать игру →'}</button>${r?'<button class="cup-link" data-action="cup-new">Начать заново</button>':''}`:`<form id="cup-entry-form"><label for="cup-name">Как вас записать в таблице?</label><div class="cup-name-row"><input id="cup-name" name="name" autocomplete="nickname" enterkeyhint="go" minlength="2" maxlength="32" required placeholder="Имя или позывной" value="${attr(CUP.nameDraft||'')}" aria-describedby="cup-entry-hint"><button class="arcade-play" type="submit"${CUP.busy?' disabled':''}>${CUP.busy?'Подключаем…':'Начать игру →'}</button></div></form>`}
 <small id="cup-entry-hint">${active?'Участвуете автоматически. ':''}Имя и прогресс запомнятся в этом браузере.</small>
 ${active?'<small class="cup-mode-hint">Для всех участников включён '+(c.mode==='calm'?'учебный':'боевой')+' режим.</small>':`<div class="arcade-mode"><button data-action="arcade-mode" data-value="calm" class="${ARCADE.mode==='calm'?'active':''}">Учебный</button><button data-action="arcade-mode" data-value="normal" class="${ARCADE.mode==='normal'?'active':''}">Боевой</button></div>`}
 <p id="cup-message" class="cup-message" role="status">${esc(CUP.error)}</p></div>
 <div class="cup-lobby-footer"><button class="arcade-secondary" data-action="cup-records">Рекорды</button>${CUP.error?'<button class="cup-link" data-action="cup-refresh">Повторить подключение</button><button class="cup-link" data-action="cup-guest">Пока без рейтинга</button>':'<small>4 редакции · 14 этапов · финал с МРГ</small>'}</div>
 <small class="app-release">Приложение v${esc(APP_RELEASE.version)} · ФТ 2.0.2</small></div>`;
}
function cupBoardHTML(){
 if(CUP.boardError)return `<p class="cup-empty" role="status">${esc(CUP.boardError)} <button class="cup-link" data-action="cup-refresh-board">Повторить</button></p>`;
 if(!CUP.rows)return '<p class="cup-empty" role="status">Загружаем результаты…</p>';
 if(!CUP.rows.length)return '<div class="cup-empty"><b>Пока нет завершённых этапов.</b><p>Пройдите первый этап — результат появится здесь.</p></div>';
 return `<table class="cup-table"><caption class="sr-only">${CUP.board===-1?'Вся кампания':esc(CUP_LEVELS[CUP.board])}</caption><thead><tr><th scope="col">№</th><th scope="col">Аналитик</th><th scope="col">${CUP.board===-1?'Этапы':'Этап'}</th><th scope="col">Очки</th><th scope="col">Время</th></tr></thead><tbody>${CUP.rows.map(r=>`<tr class="${r.player_id===CUP.player?.id?'cup-you':''}"><td>${r.rank}</td><th scope="row">${esc(r.name)}${r.player_id===CUP.player?.id?'<small>вы</small>':''}</th><td>${CUP.board===-1?r.progress+'/14':CUP.board+1}</td><td>${r.score.toLocaleString('ru-RU')}</td><td>${cupTime(r.duration)}</td></tr>`).join('')}</tbody></table>`;
}
function cupPanelHTML(){
 const c=CUP.config?.cups.find(c=>c.id===CUP.selected);
 if(location.protocol==='file:')return `<section class="cup-panel" role="dialog" aria-modal="true" aria-labelledby="cup-panel-title"><header class="cup-panel-head"><h3 id="cup-panel-title">Рекорды</h3><button class="cup-close" data-action="cup-close" aria-label="Вернуться в игру">×</button></header><p>Общая таблица доступна в онлайн-версии Цитадели.</p><a class="arcade-secondary" href="https://andrejk-blip.github.io/cmpon-atlas/#arcade">Открыть онлайн-игру</a></section>`;
 return `<section class="cup-panel" role="dialog" aria-modal="true" aria-labelledby="cup-panel-title"><header class="cup-panel-head"><div><span class="arcade-serial">ЦИТАДЕЛЬ ЦСИИ</span><h3 id="cup-panel-title">Рекорды</h3></div><button class="cup-close" data-action="cup-close" aria-label="Вернуться в игру">×</button></header>
 <div class="cup-panel-notice">${c?cupNotice(c):'Общий зачёт вне турнира'}</div>
 <div class="cup-filters"><label>Зачёт<select id="cup-select">${(CUP.config?.cups||[]).map(x=>`<option value="${attr(x.id)}"${x.id===CUP.selected?' selected':''}>${esc(x.title)}</option>`).join('')}<option value=""${CUP.selected?'':' selected'}>Вне турнира</option></select></label><label>Уровень<select id="cup-level"><option value="-1"${CUP.board===-1?' selected':''}>Вся кампания</option>${CUP_LEVELS.map((x,i)=>`<option value="${i}"${i===CUP.board?' selected':''}>${i+1}. ${esc(x)}</option>`).join('')}</select></label>${!CUP.selected?`<label>Режим<select id="cup-mode"><option value="calm"${CUP.mode==='calm'?' selected':''}>Учебный</option><option value="normal"${CUP.mode==='normal'?' selected':''}>Боевой</option></select></label>`:''}<button class="cup-refresh" data-action="cup-refresh-board" aria-label="Обновить рекорды">↻</button></div>
 <div id="cup-board" class="cup-table-scroll" tabindex="0" aria-label="Результаты">${cupBoardHTML()}</div>
 <footer class="cup-panel-footer"><small>${CUP.board===-1?'Место: этапы → очки → время.':'Место: очки → время.'} Лучший результат каждого участника · до 500 мест.</small><div><span id="cup-save-status" role="status">${esc(CUP.saveText||'')}</span><button class="arcade-secondary" data-action="cup-close">Вернуться в игру</button></div></footer></section>`;
}
function cupRenameHTML(){return `<section class="cup-panel cup-rename" role="dialog" aria-modal="true" aria-labelledby="cup-panel-title"><header class="cup-panel-head"><h3 id="cup-panel-title">Имя в рекордах</h3><button class="cup-close" data-action="cup-close" aria-label="Закрыть">×</button></header><form id="cup-rename-form"><label for="cup-new-name">Имя или позывной</label><input id="cup-new-name" name="name" autocomplete="nickname" minlength="2" maxlength="32" required value="${attr(CUP.player?.name||'')}"><small>Прогресс и очки сохранятся.</small><p id="cup-message" class="cup-message" role="status">${esc(CUP.error)}</p><button class="arcade-play" type="submit"${CUP.busy?' disabled':''}>Сохранить имя</button></form></section>`;}
const cupOriginalOverlayHTML=arcadeOverlayHTML;arcadeOverlayHTML=function(){
 if(CUP.panel)return CUP.panel==='rename'?cupRenameHTML():cupPanelHTML();
 if(location.protocol!=='file:'&&ARCADE.engine?.status==='menu')return cupLobbyHTML();
 return cupOriginalOverlayHTML();
};
const cupOriginalUpdateOverlay=updateArcadeOverlay;updateArcadeOverlay=function(){
 const el=document.getElementById('arcade-overlay');
 el?.classList.toggle('cup-panel-open',!!CUP.panel);
 if(!CUP.panel)return cupOriginalUpdateOverlay();
 if(!el)return;
 const token='cup-panel|'+CUP.uiRevision;
 if(ARCADE.overlayToken!==token){ARCADE.overlayToken=token;el.innerHTML=arcadeOverlayHTML();}
 el.hidden=false;
 document.getElementById('arcade-touch')?.classList.remove('flight-active');updateMobileArcade();
};
function cupRefreshUI(force=false){
 if(STATE.view!=='arcade')return;
 const m=document.getElementById('cup-message');if(m)m.textContent=CUP.error;
 if(!force&&document.activeElement?.id==='cup-name'){const notice=document.getElementById('cup-notice');if(notice)notice.innerHTML=cupNotice();return;}
 if(CUP.panel||ARCADE.engine?.status==='menu'){CUP.uiRevision++;ARCADE.overlayToken='';updateArcadeOverlay();}
}
function cupOpenPanel(kind='records'){
 if(!CUP.panel){const e=ARCADE.engine;CUP.panelFocus=document.activeElement;CUP.panelState=e?{engine:e,status:e.status,resumeStatus:e.resumeStatus}:null;if(e&&!['menu','paused'].includes(e.status)){e.resumeStatus=e.status;e.status='paused';}clearArcadeInput();cupEnqueue();}
 CUP.panel=kind;CUP.error='';cupRefreshUI(true);
 document.querySelector(kind==='rename'?'#cup-new-name':'.cup-close')?.focus({preventScroll:true});
 if(kind==='records'&&location.protocol!=='file:')void cupRefreshBoard();
}
function cupClosePanel(resume=true){
 const state=CUP.panelState;CUP.panel=null;CUP.panelState=null;
 if(state&&state.engine===ARCADE.engine){const e=state.engine;if(resume&&!document.hidden||['menu','paused','won','lost'].includes(state.status)){e.status=state.status;e.resumeStatus=state.resumeStatus;}else{e.status='paused';e.resumeStatus=state.status==='paused'?state.resumeStatus:state.status;}}
 clearArcadeInput();CUP.uiRevision++;ARCADE.overlayToken='';updateArcadeOverlay();
 if(resume){const f=CUP.panelFocus;if(f?.isConnected)f.focus({preventScroll:true});else ARCADE.canvas?.focus({preventScroll:true});}
 CUP.panelFocus=null;
}
async function cupRefreshBoard(){
 const serial=++CUP.boardSerial;CUP.boardError='';
 try{const d=await cupAPI('board?cup='+encodeURIComponent(CUP.selected)+'&level='+CUP.board+'&mode='+CUP.mode);if(serial!==CUP.boardSerial)return;CUP.rows=d.rows;}
 catch(e){if(serial!==CUP.boardSerial)return;CUP.boardError=e.message;}
 if(CUP.panel==='records'){const el=document.getElementById('cup-board');if(el)el.innerHTML=cupBoardHTML();}
}
async function cupRefresh(){
 if(CUP.refreshPromise)return CUP.refreshPromise;
 CUP.refreshPromise=(async()=>{
  const d=await cupAPI('config');CUP.config=d;if(!CUP.ready)CUP.selected=cupCurrent()?.id||'';CUP.ready=true;
  await cupEnsureProfile();
  if(CUP.player){if(!CUP.recovered){await cupRecoverOutbox();CUP.recovered=true;}let m;try{m=await cupAPI('me');}catch(e){if(e.status!==401)throw e;CUP.verified=false;await cupEnsureProfile();m=await cupAPI('me');}CUP.player=m.player;CUP.runs=m.runs;cupPersist();}
  CUP.error='';cupRefreshUI();
 })();
 try{return await CUP.refreshPromise;}finally{CUP.refreshPromise=null;}
}
async function cupLaunch(run,resume=false){
 CUP.run=run;CUP.attached=true;CUP.conflict=false;CUP.queue=[];CUP.clock=run.clock||0;CUP.progress=run.progress||0;CUP.startClock=CUP.clock;CUP.startScore=0;
 let e;if(resume&&run.snapshot){e=cupUnpack(run.snapshot,run);const m=run.snapshot.meta||{};CUP.clock=m.clock??run.clock;CUP.startClock=m.startClock??CUP.clock;CUP.startScore=m.startScore??e.score;}
 else{e=new RequirementArcade(run.seed);e.start(run.mode==='calm');e.emit=arcadeEvent;}
 if(CUP.panel)cupClosePanel(false);
 ARCADE.engine=e;ARCADE.mode=run.mode;ARCADE.feed=[];ARCADE.camera=null;ARCADE.overlayToken='';ARCADE.rescueToken='';ARCADE.captainSerial=-1;clearArcadeInput();e.pause();cupPersist();cupStatus('Сохранено · '+CUP.progress+'/14 этапов');
 if(STATE.view!=='arcade')setView('arcade',true);else{updateArcadeHUD();updateArcadeOverlay();}
 cupEnqueue();
}
async function cupStartDefault(forceNew=false){
 if(CUP.busy)return;
 if(!CUP.player){if(ARCADE.engine?.status!=='menu')cupOriginalAction('arcade-menu');cupRefreshUI(true);document.getElementById('cup-name')?.focus();return;}
 CUP.busy=true;CUP.error='';cupRefreshUI(true);
 try{
  await cupRefresh();
  if(!CUP.player)throw Error('Введите имя, чтобы начать игру.');
  // Explicit "continue from cloud" resolves a stale tab without overwriting the server.
  if(CUP.conflict){CUP.queue=[];CUP.run=null;CUP.conflict=false;CUP.attached=false;localStorage.removeItem('cmpon.cup.outbox.v1');}
  cupEnqueue();await cupFlush();if(CUP.queue.length)throw Error('Сохранение ждёт связи. Нажмите ещё раз после подключения.');
  const r=!forceNew&&cupPlayableRun();
  if(r){const d=await cupAPI('run?id='+encodeURIComponent(r.id));if(d.run.status!=='active')throw Error('Попытка уже завершена. Обновите подключение.');await cupLaunch(d.run,true);}
  else{const d=await cupAPI('start',{autoTournament:true,mode:ARCADE.mode,gameVersion:CUP_GAME_VERSION});await cupLaunch(d.run);}
 }catch(e){CUP.error=e.message;}finally{CUP.busy=false;cupRefreshUI(true);}
}
async function cupAction(action){
 try{
  if(action==='cup-records'){cupOpenPanel();return;}
  if(action==='cup-close'){cupClosePanel();return;}
  if(action==='cup-rename'){cupOpenPanel('rename');return;}
  if(action==='cup-refresh-board'){CUP.rows=null;const el=document.getElementById('cup-board');if(el)el.innerHTML=cupBoardHTML();await cupRefreshBoard();return;}
  if(action==='cup-refresh'){await cupRefresh();return;}
  if(action==='cup-play'||action==='cup-new'){await cupStartDefault(action==='cup-new');return;}
  if(action==='cup-guest'){cupEnqueue();await cupFlush();if(CUP.queue.length)throw Error('Сохранение ещё не отправлено. Дождитесь подключения.');if(CUP.panel)cupClosePanel(false);CUP.attached=false;CUP.run=null;startArcade();return;}
 }catch(e){CUP.error=e.message;cupRefreshUI(true);}
}
const cupOriginalAction=arcadeAction;arcadeAction=function(action,value){
 if(action.startsWith('cup-')){void cupAction(action,value);return true;}
 if(CUP.panel&&action!=='arcade-expand'&&!action.startsWith('arcade-music'))return true;
 if(action==='arcade-start'&&location.protocol!=='file:'){void cupStartDefault(ARCADE.engine?.status!=='menu');return true;}
 if(['citadel-continue','finale-restore'].includes(action)&&(CUP.run||CUP.player)){void cupStartDefault();return true;}
 if(action==='arcade-menu'&&location.protocol!=='file:'){cupEnqueue();CUP.attached=false;void cupRefresh().catch(e=>{CUP.error=e.message;cupRefreshUI();});}
 if(CUP.attached&&action==='arcade-mode'){toast('Сложность зафиксирована для этой попытки.');return true;}
 return cupOriginalAction(action,value);
};
const cupOriginalSetView=setView;setView=function(view,scroll){
 const records=view==='tournament';if(records)view='arcade';
 if(view!=='arcade'&&CUP.panel)cupClosePanel(false);
 cupOriginalSetView(view,scroll);if(records)cupOpenPanel();
};
const cupOriginalRenderArcade=renderArcade;renderArcade=function(){
 return cupOriginalRenderArcade().replace('<button data-action="arcade-pause"', '<button class="cup-top-button" data-action="cup-records" aria-label="Рекорды" title="Рекорды"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M4 20V12H9V20M9 20V5H15V20M15 20V9H20V20M2 20H22"/></svg><span>Рекорды</span></button><button data-action="arcade-pause"');
};
function setupTournament(){
 if(STATE.view==='tournament'||['#arcade','#tournament'].includes(location.hash))STATE.view='arcade';
 if(location.hash==='#tournament')CUP.panel='records';
 addEventListener('hashchange',()=>{if(['#arcade','#tournament'].includes(location.hash))setView(location.hash==='#tournament'?'tournament':'arcade',true);});
 try{const v=JSON.parse(localStorage.getItem('cmpon.cup.session.v1')||'null');if(v?.token){CUP.token=v.token;CUP.player=v.player;}const k=localStorage.getItem(CUP_DEVICE_KEY);if(/^cpd_[a-f0-9]{64}$/.test(k||''))CUP.deviceKey=k;}catch{}
 document.addEventListener('input',ev=>{if(ev.target.id==='cup-name')CUP.nameDraft=ev.target.value;});
 document.addEventListener('submit',async ev=>{
  if(!['cup-entry-form','cup-rename-form'].includes(ev.target.id))return;ev.preventDefault();if(CUP.busy)return;
  const rename=ev.target.id==='cup-rename-form',name=String(new FormData(ev.target).get('name')||'');CUP.nameDraft=name;CUP.busy=true;CUP.error='';
  const buttons=[...ev.target.querySelectorAll('button')];buttons.forEach(b=>b.disabled=true);
  try{
   if(rename){const d=await cupAPI('profile',{name});CUP.player=d.player;cupPersist();cupClosePanel();}
   else{await cupEnsureProfile(name);CUP.busy=false;await cupStartDefault();}
  }catch(e){CUP.error=e.message;}finally{CUP.busy=false;buttons.forEach(b=>b.disabled=false);cupRefreshUI(true);}
 });
 document.addEventListener('change',ev=>{
  const id=ev.target.id;if(!['cup-select','cup-level','cup-mode'].includes(id))return;
  if(id==='cup-select')CUP.selected=ev.target.value;if(id==='cup-level')CUP.board=Number(ev.target.value);if(id==='cup-mode')CUP.mode=ev.target.value;
  CUP.rows=null;CUP.boardError='';cupRefreshUI(true);document.getElementById(id)?.focus();void cupRefreshBoard();
 });
 document.addEventListener('keydown',ev=>{
  if(!CUP.panel||STATE.view!=='arcade'||MOBILE.menu||MOBILE.command)return;ev.stopImmediatePropagation();
  if(ev.code==='Escape'){ev.preventDefault();cupClosePanel();return;}
  if(ev.code==='Tab'){const list=[...document.querySelectorAll('.cup-panel button:not([disabled]),.cup-panel select,.cup-panel input,.cup-panel a,.cup-panel [tabindex="0"]')];if(list.length){const i=list.indexOf(document.activeElement);if(ev.shiftKey&&(i<=0)){ev.preventDefault();list.at(-1).focus();}else if(!ev.shiftKey&&(i<0||i===list.length-1)){ev.preventDefault();list[0].focus();}}}
 },true);
 addEventListener('online',()=>void cupFlush());document.addEventListener('visibilitychange',()=>{if(document.hidden){ARCADE.engine?.pause();cupEnqueue();}});addEventListener('pagehide',()=>cupEnqueue());
 if(location.protocol!=='file:'){
  void cupRefresh().then(()=>{if(CUP.panel==='records')void cupRefreshBoard();}).catch(e=>{CUP.error=e.message;cupRefreshUI();});
  setInterval(()=>{if(CUP.run&&!CUP.conflict){cupEnqueue();void cupFlush();}},20000);
 }
}
async function cupRecoverOutbox(){
 if(!CUP.player)return;
 let p;try{p=JSON.parse(localStorage.getItem('cmpon.cup.outbox.v1')||'null');}catch{return;}
 if(p?.playerId!==CUP.player.id||!p.queue?.length)return;
 CUP.run=p.run;CUP.queue=p.queue;CUP.progress=p.progress;CUP.clock=p.clock;CUP.startClock=p.startClock;CUP.startScore=p.startScore;
 await cupFlush();if(!CUP.queue.length)CUP.run=null;
}
