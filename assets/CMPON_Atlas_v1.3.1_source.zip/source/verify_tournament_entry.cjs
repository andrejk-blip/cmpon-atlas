/* Behavioral integration checks for name entry, cloud ownership and in-game panels. */
const h=require('./campaign-harness.cjs');const {run,plain,context,assert,node,store,doc,listeners}=h;
(async()=>{
 context.location.protocol='https:';context.location.hash='#tournament';
 const calls=[],players=new Map(),devicePlayers=new Map(),tokens=new Map(),runs=[];let profileCount=0,runCount=0;
 const active={id:'cup-active',title:'Кубок ЦМПОН -10.26',state:'active',announced:true,mode:'calm',seed:417147,startsAt:1792098000000,endsAt:1793566800000};
 let config={cups:[active],entry:'device-name-v1',gameVersion:'1.3.0'};
 const ok=data=>new Response(JSON.stringify(data),{status:200});const fail=(error,status)=>new Response(JSON.stringify({error}),{status});
 context.fetch=async(url,o={})=>{
  const p=String(url).split('/api/tournament/')[1],b=o.body?JSON.parse(o.body):null;calls.push({p,b});
  const owner=tokens.get((o.headers?.Authorization||'').replace('Bearer ',''));
  if(p==='config')return ok(config);
  if(p.startsWith('board?'))return ok({rows:[]});
  if(p==='enter'){
   assert(/^cpd_[a-f0-9]{64}$/.test(b.deviceKey));let id=devicePlayers.get(b.deviceKey)||owner;
   if(!id){if(!b.name)return fail('Введите имя',400);id='player-'+(++profileCount);players.set(id,{id,name:b.name});}
   devicePlayers.set(b.deviceKey,id);const token='session-'+Math.random();tokens.set(token,id);return ok({player:players.get(id),token});
  }
  if(!owner)return fail('Expired',401);
  if(p==='me')return ok({player:players.get(owner),runs:runs.filter(r=>r.playerId===owner)});
  if(p==='start'){
   assert.equal(b.autoTournament,true);assert.equal(b.gameVersion,'1.3.0');const c=config.cups.find(c=>c.state==='active');
   const r={id:'run-'+(++runCount),playerId:owner,cupId:c?.id||null,mode:c?.mode||b.mode,seed:c?.seed||417147,progress:0,revision:0,clock:0,status:'active',gameVersion:'1.3.0',snapshot:null};runs.push(r);return ok({run:r});
  }
  if(p.startsWith('run?id='))return ok({run:runs.find(r=>r.id===p.split('=')[1]&&r.playerId===owner)});
  if(p==='save'){const r=runs.find(r=>r.id===b.id);assert.equal(r.playerId,owner);r.snapshot=b.snapshot;r.revision++;r.clock=b.clock;return ok({run:r});}
  if(p==='profile'){const player=players.get(owner);player.name=b.name;return ok({player});}
  throw Error('Unexpected route '+p);
 };
 run(`STATE.view='arcade';ARCADE.engine=new RequirementArcade(417147);updateArcadeHUD=()=>{};updateMobileArcade=()=>{};setupTournament();`);
 await run('CUP.refreshPromise');
 assert.equal(run('STATE.view'),'arcade');assert.equal(run('CUP.panel'),'records');assert(!run("NAV.some(n=>n[0]==='tournament')"));
 assert(run('cupPanelHTML()').includes('Кубок ЦМПОН'));assert(!run('cupPanelHTML()').includes('type="password"'));
 run('cupClosePanel();');assert.equal(run('ARCADE.engine.status'),'menu');
 assert(run('cupLobbyHTML()').includes('cup-entry-form'));assert(!run('cupLobbyHTML()').includes('password'));
 assert(run('cupLobbyHTML()').includes('Участвуете автоматически'));
 assert.equal(calls.filter(c=>c.p==='enter'||c.p==='start').length,0,'visiting game does not create an account or run');
 const me=await run("cupEnsureProfile('Тестовый пилот')");assert.equal(me.name,'Тестовый пилот');assert(store.get('cmpon.cup.device.v1'));
 await run('cupStartDefault()');await run('cupFlush()');
 assert.equal(run('CUP.run.cupId'),'cup-active');assert.equal(run('CUP.run.mode'),'calm');assert.equal(runCount,1);assert.equal(run('STATE.view'),'arcade');
 const id=run('CUP.run.id');
 run('ARCADE.engine.launch();CUP.clock=1000;');await run('cupFlush()');
 run('cupOpenPanel();');assert.equal(run('ARCADE.engine.status'),'paused');assert.equal(run('CUP.panel'),'records');
 const clock=run('CUP.clock');run('cupTick(5);');assert.equal(run('CUP.clock'),clock);
 run("arcadeAction('arcade-resume')");assert.equal(run('ARCADE.engine.status'),'paused');
 let stopped=false;listeners.keydown.at(-1)({code:'Space',stopImmediatePropagation(){stopped=true},preventDefault(){}});assert(stopped);
 run('cupClosePanel();');assert.equal(run('ARCADE.engine.status'),'playing');
 run("ARCADE.engine.collect(ARCADE.engine.modules()[0]);ARCADE.engine.openNextLesson();cupOpenPanel();cupClosePanel();");assert.equal(run('ARCADE.engine.status'),'lesson');
 run("ARCADE.engine.beginBoarding();ARCADE.engine.pause();cupOpenPanel();cupClosePanel();");assert.equal(run('ARCADE.engine.status'),'paused');assert.equal(run('ARCADE.engine.resumeStatus'),'boarding');
 // Returning from the game menu resumes the same cloud campaign, not a new attempt.
 run("arcadeAction('arcade-menu')");await run('CUP.refreshPromise');await run('cupFlush()');await run('cupStartDefault()');await run('cupFlush()');
 assert.equal(run('CUP.run.id'),id);assert.equal(runCount,1);
 // Device identity survives loss/expiry of bearer sessions and keeps its run.
 tokens.clear();run("CUP.token='expired';CUP.verified=false;CUP.player=null;");
 const returned=await run('cupEnsureProfile()');assert.equal(returned.id,me.id);assert.equal(profileCount,1);
 // Legacy valid token attaches this same player, without looking up anyone by name.
 run("CUP.deviceKey='';CUP.verified=false;");const bound=await run('cupEnsureProfile()');assert.equal(bound.id,me.id);
 // Ending the cup selects a practice run, never resumes a closed tournament attempt.
 config={...config,cups:[{...active,state:'finished'}]};await run('cupRefresh()');run('CUP.attached=false;');await run('cupStartDefault()');await run('cupFlush()');assert.equal(run('CUP.run.cupId'),null);assert.equal(runCount,2);
 // A pending flush really is awaited by a second caller.
 let unblock;const oldFetch=context.fetch;context.fetch=(url,o)=>String(url).endsWith('/save')?new Promise(resolve=>{unblock=async()=>resolve(await oldFetch(url,o));}):oldFetch(url,o);
 run('CUP.clock+=100;cupEnqueue();');let finished=false;const waiting=run('cupFlush()').then(()=>finished=true);await Promise.resolve();assert(!finished);assert(unblock);await unblock();await waiting;assert(finished);assert.equal(run('CUP.queue.length'),0);context.fetch=oldFetch;
 // Stale board responses must not replace the user's new filter.
 let firstResolve,secondResolve;context.fetch=()=>new Promise(r=>{if(!firstResolve)firstResolve=r;else secondResolve=r;});
 const first=run('cupRefreshBoard()');run('CUP.board=2');const second=run('cupRefreshBoard()');secondResolve(ok({rows:[{name:'new'}]}));await second;firstResolve(ok({rows:[{name:'old'}]}));await first;assert.equal(run('CUP.rows[0].name'),'new');
 console.log('PASS: in-game deep link and nav; name only; no unsolicited registration; device return + legacy binding; automatic cup; cloud resume; exact panel pause/restore including questions; keyboard isolation; cutoff practice; awaited flush; board request race.');
})().catch(e=>{console.error(e);process.exitCode=1});
