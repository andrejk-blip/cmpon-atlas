const {fs,assert,crypto,root,run,plain,node,event,doc,globalEvents,store,frames,context}=require('./campaign-harness.cjs');
const before=JSON.stringify(run('DATA'));
assert.equal(crypto.createHash('sha256').update(fs.readFileSync(root+'/data.json')).digest('hex'),'16a17c22336a89a79ddc46b79643adb59b6ddd5dd9dbda16bac131e062a444eb');
run('ARCADE.sound=false;ARCADE.forceCPU=true;initialize();setView("arcade")');
assert(node('content').innerHTML.includes('citadel-radar-canvas'));
assert(node('content').innerHTML.includes('КАПИТАН ВЕКТОР'));
assert(node('content').innerHTML.includes('data:image/png;base64,'));
assert(node('arcade-overlay').innerHTML.includes('ПОЛУЧИТЬ ЗАДАНИЕ'));
assert.equal(frames.size,1);
run('arcadeAction("arcade-mode","calm");arcadeAction("arcade-start")');
assert.equal(run('ARCADE.engine.status'),'briefing');
assert(node('arcade-overlay').innerHTML.includes('Сначала — первый кристалл'));
run('arcadeAction("citadel-launch")');
assert.equal(run('ARCADE.engine.status'),'playing');
assert(node('arcade-overlay').hidden);
run('for(let i=0;i<600&&ARCADE.engine.status!=="lesson";i++)ARCADE.engine.step(1/60,{})');
assert.equal(run('ARCADE.engine.status'),'lesson');assert(run('ARCADE.engine.elapsed<8'));assert.equal(run('ARCADE.engine.rescued.length'),1);
const frozen=plain(run('ARCADE.engine.player.pos'));run('ARCADE.engine.step(.04,{fire:true})');assert.deepStrictEqual(plain(run('ARCADE.engine.player.pos')),frozen);
assert(!run('ARCADE.engine.answerLesson(0)'));assert.equal(run('ARCADE.engine.decisions.length'),0);run('ARCADE.engine.continueLesson()');assert.equal(run('ARCADE.engine.status'),'lesson');
event('keydown',{code:'Digit2'});assert.equal(run('ARCADE.engine.decisions.length'),1);run('arcadeAction("citadel-lesson-next")');
assert(run('ARCADE.engine.enemies.some(e=>e.role==="hacker")&&ARCADE.engine.enemies.some(e=>e.role==="bomber")'));
assert(run('ARCADE.engine.autopilot'));event('keydown',{code:'KeyG'});assert(!run('ARCADE.engine.autopilot'));event('keydown',{code:'KeyG'});assert(run('ARCADE.engine.autopilot'));
event('keydown',{code:'KeyW'});assert(!run('ARCADE.engine.autopilot'));assert.equal(run('arcadeInput().pitch'),1);event('keyup',{code:'KeyW'});
event('keydown',{code:'Tab'});assert(run('ARCADE.engine.selectedTarget')!==null);
event('keydown',{code:'KeyE'});assert(run('arcadeInput().pulse'));event('keydown',{code:'KeyE',repeat:true});assert(!run('arcadeInput().pulse'));
function pointer(id,type,props){for(const fn of node(id).handlers[type]||[])fn({button:0,pointerType:'mouse',pointerId:1,clientX:900,clientY:200,preventDefault(){},...props})}
pointer('arcade-canvas','pointerdown');assert(run('arcadeInput().fire'));assert(run('arcadeInput().turn')>0);pointer('arcade-canvas','pointerup');assert(!run('arcadeInput().fire'));
event('keydown',{code:'KeyP'});assert.equal(run('ARCADE.engine.status'),'paused');event('keydown',{code:'KeyP'});assert.equal(run('ARCADE.engine.status'),'playing');
// Sabotage and bombing must damage objectives even when the player is not firing.
run('globalThis.g=new RequirementArcade(19);g.start();g.launch();g.phase="battle";g.nextWave();g.autopilot=false;g.asteroids=[];const hacker=g.enemies.find(x=>x.role==="hacker");hacker.warp=0;hacker.pos=g.nodes[hacker.node].pos.slice();');
run('for(let i=0;i<120;i++)g.step(1/60,{brake:true})');assert(run('g.nodes.some(n=>n.integrity<100)'));
run('g.hostile.push({stationShot:true,pos:g.station.pos.slice(),vel:[0,0,0],life:1,r:1,damage:1});g.step(1/60,{})');assert(run('g.stationHp<100'));
run('g.collect(g.modules()[0]);g.openNextLesson()');assert.equal(run('g.rescued.length'),1,'Green modules collect during combat');assert.equal(run('g.status'),'lesson');assert(!run('g.nodes[0].dead'),'Defence nodes remain active after collection');run('g.answerLesson(1);g.continueLesson();g.collect(g.modules()[0])');assert.equal(run('g.rescued.length'),1,'Duplicate collection is ignored');
run('g.stationHp=0;g.checkStage()');assert.equal(run('g.status'),'lost');assert(run('g.lossReason').includes('Редакцию'));
// No advancement by number of kills alone; the living wave must be defeated.
run('g=new RequirementArcade(1);g.start();g.launch();g.phase="battle";g.nextWave();g.stageKills=999;g.checkStage()');assert.equal(run('g.phase'),'battle');assert.equal(run('g.wave'),1);
// Final cruiser gate and docking/landing gate are distinct from collection.
run('g.beginStage(3);g.launch();g.wave=3;g.waveSpawned=g.waveTotal();g.enemies=[];g.checkStage()');assert(run('!!g.boss'));assert.equal(run('g.phase'),'battle');
run('g.hit(g.boss,2000);g.checkStage()');assert.equal(run('g.phase'),'retrieve');
run('for(const n of g.modules())g.collect(n);g.openNextLesson();while(g.status==="lesson"){g.answerLesson(CITADEL_LESSONS[g.lesson.caseIndex].correct);g.continueLesson()}g.checkStage()');assert.equal(run('g.phase'),'dock');assert(!run('g.interact()'));
run('g.player.pos=g.dockPoint();g.interact()');assert.equal(run('g.status'),'docking');
run('g.pause();g.step(.04,{})');assert.equal(run('g.status'),'paused');run('g.resume();for(let i=0;i<320;i++)g.step(.04,{})');assert.equal(run('g.status'),'boarding');
// Walls and solid cover block fire; the clear docking corridor remains traversable.
assert(!run('g.boardLOS([-11,0,-12],[-5,0,-12])'));
assert(run('g.boardLOS([0,0,20],[0,0,8])'));
const boardPos=plain(run('g.board.pos'));run('g.pause();g.step(.04,{moveX:1,fire:true})');assert.deepStrictEqual(plain(run('g.board.pos')),boardPos);run('g.resume()');
assert(!run('g.boardInteract()'),'Cannot open a terminal from the docking room');
// Projectile combat, cover collision and terminal proximity use production simulation.
run('g.beginStage(0);g.beginBoarding();g.board.guide=false;g.board.pos=[0,0,-8];g.board.enemies=g.board.enemies.slice(0,1);Object.assign(g.board.enemies[0],{pos:[0,0,-15],hp:44,shot:999,stun:999});');
run('for(let i=0;i<120;i++)g.step(1/60,{fire:true})');assert.equal(run('g.board.enemies.length'),0);assert.equal(run('g.board.kills'),1);
assert(!run('g.boardInteract()'),'Must approach a terminal');
run('g.board.pos=g.board.terminals[0].slice();g.boardInteract()');assert.equal(run('g.status'),'remark');
assert(!run('g.answer(1)'));assert.equal(run('g.completedRemarks.length'),0);assert(run('g.remarkFeedback.why.length')>30);assert(!run('g.answer(0)'),'Cannot answer twice without returning');
run('g.continueRemark()');assert.equal(run('g.status'),'remark');assert.equal(run('g.board.enemies.length'),0,'Wrong response does not repeat combat');
run('g.answer(0)');assert.equal(run('g.completedRemarks.length'),1);run('g.continueRemark()');assert.equal(run('g.status'),'boarding');
// Restore, retry and upgrade state; test corrupted and blocked storage too.
run('ARCADE.engine=g;g.rescued=g.plan[0].slice();g.decisions=[0,1].map(caseIndex=>({reqId:g.plan[0][caseIndex?2:0],caseIndex,stage:0,firstTry:true,decision:CITADEL_LESSONS[caseIndex].correct}));g.completedRemarks=[0,1,2];g.board.completed=[0,1,2];g.board.enemies=[];g.board.pos=g.board.exit.slice();g.boardInteract();citadelSave()');
assert.equal(run('g.status'),'stageclear');assert(run('citadelReadSave()')!==null);
assert(!run('g.chooseUpgrade("__proto__")'));
assert(run('g.chooseUpgrade("weapons")'));assert(!run('g.chooseUpgrade("armor")'));run('citadelSave();ARCADE.checkpoint=null;citadelRestore()');assert.equal(run('ARCADE.engine.upgrades.weapons'),1);assert.equal(run('ARCADE.engine.decisions.length'),2);
run('ARCADE.engine.next();ARCADE.engine.launch();ARCADE.engine.finishEscort();ARCADE.engine.completeEscort();ARCADE.engine.launch();ARCADE.engine.score+=200;citadelRetry()');assert.equal(run('ARCADE.engine.stage'),1);assert.equal(run('ARCADE.engine.completedRemarks.length'),3);assert.equal(run('ARCADE.engine.rescued.length'),3);assert.equal(run('ARCADE.engine.upgrades.weapons'),1);
const saved=store.get('cmpon.citadel.review.v3');store.set('cmpon.citadel.review.v3','{"schema":"citadel-review-v3","stage":-9}');assert.equal(run('citadelReadSave()'),null);store.set('cmpon.citadel.review.v3',saved);
// Landing input does not inherit stale mouse aim when firing with the keyboard.
run('ARCADE.engine.beginBoarding();ARCADE.camera=spaceCamera(ARCADE.engine,1);ARCADE.boardAim=[15,0,1];ARCADE.firePointer=null');
event('keydown',{code:'Space'});assert.equal(run('arcadeInput().aim'),null);assert(run('arcadeInput().fire'));event('keyup',{code:'Space'});
event('keydown',{code:'KeyW'});assert.equal(run('arcadeInput().moveZ'),-1);event('keyup',{code:'KeyW'});
run('updateArcadeHUD()');assert.equal(node('arcade-boost-touch').textContent,'РЫВОК');assert(node('citadel-quickbar').classList.contains('station-controls'));assert(!run('ARCADE.engine.board.guide'));event('keydown',{code:'KeyG'});assert(run('ARCADE.engine.board.guide'));run('arcadeAction("arcade-pulse")');assert(run('arcadeInput().pulse'));

pointer('arcade-canvas','pointerdown');assert(run('arcadeInput().aim')!==null);pointer('arcade-canvas','pointerup');assert.equal(run('arcadeInput().aim'),null);
pointer('arcade-fire-touch','pointerdown');assert(run('arcadeInput().fire'));pointer('arcade-fire-touch','pointercancel');assert(!run('arcadeInput().fire'));
if(!run('ARCADE.expanded'))run('arcadeAction("arcade-expand")');assert(node('arcade-layout').classList.contains('is-expanded'));run('arcadeAction("arcade-requirement",ARCADE.engine.plan[0][0])');assert(!run('ARCADE.expanded'));assert.equal(run('ARCADE.engine.status'),'paused');assert(node('detail').open);
run('closeDetail();arcadeAction("arcade-resume")');doc.hidden=true;event('visibilitychange');assert.equal(run('ARCADE.engine.status'),'paused');doc.hidden=false;
run('arcadeAction("arcade-resume")');globalEvents.blur();assert.equal(run('ARCADE.engine.status'),'paused');
run('arcadeAction("arcade-resume");setView("requirements")');assert.equal(frames.size,0);assert.equal(run('ARCADE.engine.status'),'paused');
context.localStorage.setItem=()=>{throw Error('blocked')};run('ARCADE.engine.status="stageclear";citadelSave()');assert(!run('ARCADE.storage'));assert(run('ARCADE.checkpoint')!==null);
assert.equal(JSON.stringify(run('DATA')),before);assert.equal(run('REVIEW.records.length'),0);
console.log(JSON.stringify({campaignBriefingAndObjectives:'passed',captainAndRadar:'passed',severityPressureSimulation:'passed',firstCrystalAndLesson:'passed',collectionDuringCombat:'passed',missionGatesAndBoss:'passed',dockingAndLanding:'passed',wallsAndCover:'passed',projectileBoardingCombat:'passed',wrongAndCorrectRemarks:'passed',upgradesRestoreAndRetry:'passed',keyboardMouseTouch:'passed',pauseAndAtlasNavigation:'passed',corruptAndBlockedStorage:'passed',analyticalDataUnchanged:'passed',browserLayoutQA:'unavailable'},null,2));
