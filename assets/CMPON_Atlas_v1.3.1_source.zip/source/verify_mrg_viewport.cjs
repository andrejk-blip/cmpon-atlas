const {run,plain,assert}=require('./campaign-harness.cjs');
run(`ARCADE.sound=false;ARCADE.fx=true;ARCADE.forceCPU=true;initialize();setView('arcade');globalThis.e=new RequirementArcade(417);e.start(true);e.beginStage(3);e.beginFinale();e.beginMRG();ARCADE.engine=e;`);
for(const [w,h]of [[320,364],[390,460],[430,536],[592,244],[1280,720]]){
 run(`ARCADE.canvas.width=${w};ARCADE.canvas.height=${h};`);
 const points=plain(run(`(()=>{const c=spaceCamera(e);return [[-32,2,0],[24,8,0],[17,14,0]].map(p=>spaceProject(p,c,${w},${h}))})()`));
 assert(points.every(p=>p.z>0&&p.x>10&&p.x<w-10&&p.y>60&&p.y<h-40),'Keep player, MRG and jump in the gameplay frame at '+w+'x'+h);
 console.log(w+'x'+h+': player, computer and jump fit');
}
