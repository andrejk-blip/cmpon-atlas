const {fs,assert,crypto,root,run,plain,node,frames,context,event}=require('./campaign-harness.cjs');
const {Path2D}=require(require.resolve('@napi-rs/canvas',{paths:[process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES]}));
const geometryContext=require('./campaign-harness.cjs').createCanvas(1200,820).getContext('2d');
const dataHash=crypto.createHash('sha256').update(fs.readFileSync(root+'/data.json')).digest('hex');
assert.equal(dataHash,'16a17c22336a89a79ddc46b79643adb59b6ddd5dd9dbda16bac131e062a444eb');
run("initialize();SPACE.motion=false;STATE.view='cosmos';setSpaceSector('overview')");
assert.equal(run('GEO_LAYOUT.size'),9);
assert.equal(run('new Set([...SECTOR_IDS.values()].flatMap(x=>[...x])).size'),417);
const reached=new Set(),cityIds=new Set();
for(const g of plain(run('GEO_LANDS'))){
 run(`setSpaceSector('${g.id}')`);const html=run('renderCosmos()');
 assert(html.includes('География <em>требований.'));
 const expected=plain(run(`Array.from(SECTOR_IDS.get('${g.id}'))`));
 assert.equal(run('spaceRows().length'),expected.length);
 const layout=plain(run(`GEO_LAYOUT.get('${g.id}')`));
 assert.equal(new Set(layout.pins.map(p=>p.id)).size,expected.length);
 const landPath=new Path2D(run(`geoPath(GEO_BY_ID.get('${g.id}'))`));
 for(const p of layout.pins){assert(geometryContext.isPointInPath(landPath,p.x,p.y),'Pin outside curved coast: '+p.id);assert(run(`geoInside([${p.x},${p.y}],GEO_BY_ID.get('${g.id}').points)`));reached.add(p.id);assert(html.includes(`data-action="space-select" data-value="${p.id}"`))}
 for(const c of layout.cities){cityIds.add(c.id);assert(html.includes(`data-action="space-concept" data-value="${c.id}"`));run(`spaceAction('space-concept','${c.id}')`);const ids=plain(run('spaceRows().map(r=>r.id)'));assert.deepStrictEqual(new Set(ids),new Set(plain(run(`CONCEPTS.get('${c.id}').requirements`))));run("spaceAction('space-concept','all')")}
}
assert.equal(reached.size,417);assert.equal(cityIds.size,50);
run("setSpaceSector('sampling');spaceAction('space-concept','K34')");assert.equal(run('spaceRows().length'),0);assert(run('renderCosmos().includes("У концепции нет связанных ФТ")'));assert(run('renderCosmos().includes(\'data-action="concept" data-value="K34"\')'));
run("setSpaceSector('all');STATE.scope='ftt';STATE.status='N'");assert.equal(run('spaceRows().length'),44);run("STATE.scope='c39'");assert.equal(run('spaceRows().length'),98);
run("STATE.status='all';STATE.scope='best';STATE.query='ФТ-85';render()");assert.deepStrictEqual(plain(run('spaceRows().map(r=>r.id)')),['ВСТЕ-01']);run("geoSelect('ВСТЕ-01')");assert.equal(run('SPACE.selected'),'ВСТЕ-01');assert(run('geoDossier(spaceRows()).includes("Достоверность:")'));
run("STATE.query='ZZZ';render()");assert.equal(run('SPACE.selected'),null);assert(run('renderCosmos().includes("По этим фильтрам нет требований")'));
run("resetFilters();setSpaceSector('all');appendOpinion({kind:'requirement',targetId:'ФТ-001',source:'c39',status:'wrong',comment:'Проверка разделения источников',author:'Тест'});SPACE.review='disputed';STATE.scope='ftt'");assert(!run("spaceRows().some(r=>r.id==='ФТ-001')"));run("STATE.scope='c39'");assert(run("spaceRows().some(r=>r.id==='ФТ-001')"));run("spacePickNext('disputed')");assert.equal(run('SPACE.selected'),'ФТ-001');
run("SPACE.review='all';STATE.scope='best';setSpaceSector('architecture');spaceAction('space-concept','K01');resetFilters()");assert.equal(run('SPACE.concept'),null);
// Header search escapes the selected concept and searches all requirements.
run("setSpaceSector('architecture');spaceAction('space-concept','K01')");
for(const f of node('search').handlers.input)f({target:{value:'ФТ-85'}});
assert.equal(run('SPACE.sector'),'all');assert.equal(run('SPACE.concept'),null);assert.equal(run('SPACE.camera.w'),1200);assert.deepStrictEqual(plain(run('spaceRows().map(r=>r.id)')),['ВСТЕ-01']);
// CSV uses the visible geographic subset, including concept/review filters.
context.document.createElement=()=>({click(){},remove(){}});context.document.body.append=()=>{};
context.URL={createObjectURL(){return 'test:csv'},revokeObjectURL(){}};
run("resetFilters();setSpaceSector('sampling');globalThis.originalCSV=csvContent;globalThis.csvIDs=[];csvContent=function(rows){csvIDs=rows.map(r=>r.id);return originalCSV(rows)};exportCSV()");
assert.equal(run('csvIDs.length'),18);assert.deepStrictEqual(new Set(plain(run('csvIDs'))),new Set(plain(run("Array.from(SECTOR_IDS.get('sampling'))"))));
run("spaceAction('space-concept','K32');exportCSV()");assert.equal(run('csvIDs.length'),15);run('csvContent=originalCSV');
// Overlap navigation retains one selected ID and separate source assessments.
const overlapping=plain(run('DATA.rows.find(r=>SPACE_SECTORS.filter(g=>SECTOR_IDS.get(g.id).has(r.id)).length>1)'));
run(`setSpaceSector('all');geoSelect('${overlapping.id}')`);const related=plain(run(`SPACE_SECTORS.filter(g=>SECTOR_IDS.get(g.id).has('${overlapping.id}')).map(g=>g.id)`));run(`spaceAction('space-follow','${related[1]}')`);assert.equal(run('SPACE.selected'),overlapping.id);assert.equal(run('SPACE.sector'),related[1]);assert(run('geoRoutes(geoGlobalRows()).includes("geo-route-selected")'));
// Every global list page is reachable without omissions or duplicates.
run("setSpaceSector('all')");const listed=new Set();for(let p=1;p<=18;p++){run(`SPACE.page=${p}`);for(const m of run('geoLedger(spaceRows())').matchAll(/data-action="space-select" data-value="([^"]+)"/g))listed.add(m[1])}assert.equal(listed.size,417);
run("setSpaceSector('overview');spaceZoom(100)");assert.equal(run('SPACE.camera.w'),220);run('spaceZoom(.0001)');assert.equal(run('SPACE.camera.w'),1600);run('spaceZoom(NaN)');assert.equal(run('SPACE.camera.w'),1600);
run('spaceResetCamera();mountCosmos()');const svg=node('universe');const dispatch=(type,props)=>{for(const fn of svg.handlers[type]||[])fn({button:0,target:{closest(){return null}},pointerId:71,clientX:100,clientY:100,preventDefault(){},...props})};dispatch('pointerdown',{});dispatch('pointermove',{clientX:140,clientY:130});assert(run('SPACE.camera.x<0&&SPACE.camera.y<0'));dispatch('pointercancel',{});const old=plain(run('SPACE.camera'));dispatch('pointermove',{clientX:300,clientY:200});assert.deepStrictEqual(plain(run('SPACE.camera')),old);
run("SPACE.motion=true;setSpaceSector('registers')");assert(frames.size>0);for(const t of [1000,1200,1800]){const queued=[...frames.values()];frames.clear();for(const f of queued)f(t)}assert(Math.abs(run("SPACE.camera.w-geoCamera(GEO_BY_ID.get('registers')).w"))<.0001);assert.equal(frames.size,0);
run("setSpaceSector('design');setView('map')");assert.equal(frames.size,0,'Leaving the map must cancel animation');
// SVG keyboard actions and reduced motion use the same routes as pointer controls.
context.matchMedia=()=>({matches:true});run("STATE.view='cosmos';setSpaceSector('architecture')");assert.equal(frames.size,0);assert.equal(run('SPACE.camera.w'),run("geoCamera(GEO_BY_ID.get('architecture')).w"));
run("SPACE.motion=false;SPACE.review='all';STATE.scope='best';STATE.status='all';SPACE.selected=null;setSpaceSector('overview')");
function snapshot(name){const s=run('geoMapSvg()').replace('<svg ','<svg width="1200" height="820" ').replace(/(<svg[^>]*>)/,'$1<style>'+fs.readFileSync(root+'/geography.css','utf8')+'</style>');fs.writeFileSync(root+'/qa_geo_'+name+'.svg',s);fs.writeFileSync(root+'/qa_geo_'+name+'.html',run('renderCosmos()'))}
snapshot('overview');run("setSpaceSector('architecture');geoSelect(spaceRows()[3].id)");snapshot('country');run("spaceAction('space-concept','K01')");snapshot('concept');
assert.equal(crypto.createHash('sha256').update(fs.readFileSync(root+'/data.json')).digest('hex'),dataHash);
const report={uniqueRequirements:reached.size,conceptCities:cityIds.size,countries:9,allListPages:listed.size,sourceAndReviewFilters:'passed',emptyConcept:'passed',globalSearchAfterConcept:'passed',geographicCSVExport:'passed',overlapNavigation:'passed',boundedZoomAndPan:'passed',pinsInsideCurvedCoasts:'passed',animationCleanup:'passed',reducedMotion:'passed',dataset:'unchanged',browserQA:'unavailable'};
fs.writeFileSync(root+'/qa_geography.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
