const {run,assert,plain,store,node}=require('./campaign-harness.cjs');
run(`globalThis.e=new RequirementArcade(417);e.start(true);e.launch();e.phase='battle';e.wave=3;e.waveSpawned=0;e.asteroids=[];e.station.pos=[1000,0,0];e.modules().forEach(m=>m.dead=true);e.player.pos=[0,0,0];e.player.speed=22;e.enemies=[{id:100,pos:[0,0,-80],vel:[0,0,0],hp:20,r:3,warp:0,dead:false,color:'#fff',points:100,role:'fighter'},{id:101,pos:[0,0,130],vel:[0,0,0],hp:1000,r:3,warp:0,dead:false,color:'#fff',points:100,role:'fighter'}];e.selectedTarget=100;e.detour=[-50,55,25];e.hit(e.enemies[0],50);`);
assert.equal(run('e.detour'),null);assert.equal(run('e.selectedTarget'),null);
run(`for(let i=0;i<60*15;i++){const dt=1/60,c=e.guidance({}),p=e.player;p.yaw+=c.turn*1.28*dt;p.pitch+=c.pitch*1.05*dt;p.speed+=(c.cruiseSpeed-p.speed)*dt*4;p.pos=V3.add(p.pos,V3.scale(flightBasis(p.yaw,p.pitch).f,p.speed*dt));e.elapsed+=dt}`);
assert(run('V3.len(V3.sub(e.player.pos,e.enemies[1].pos))<50'));
run('e.enemies=[];globalThis.c=e.guidance({boost:true})');assert.equal(run('c.cruiseSpeed'),0);assert.equal(run('c.boost'),false);assert.equal(run('e.detour'),null);
run(`e=new RequirementArcade(417);e.start(true);e.launch();for(let i=0;i<180&&e.status==='playing';i++)e.step(1/60,{})`);assert.equal(run('e.status'),'lesson');assert(run('e.elapsed<3'));
run(`e.caseBank=0;`);assert.equal(run('citadelLessonCase(e,0).situation'),run('CITADEL_LESSONS[0].situation'));assert.equal(run('e.checkpoint().caseBank'),0);
console.log('PASS: immediate pickup, target loss, 180-degree retarget, stale detour, idle stop and legacy scenario bank');
