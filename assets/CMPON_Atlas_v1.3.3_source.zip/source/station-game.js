// Traversable station decks. Combat and review decisions stay separate.
const CITADEL_DECKS=[
 {name:'Архив функционального заказчика',short:'АРХИВ ФЗ',theme:'archive',accent:'#62d9eb',warm:'#efbb74',
  zones:['Приёмный док','Зал потребностей','Галерея сценариев','Архив решений'],
  rects:[[-3,3,2,6,0],[-1,1,-2,1,0],[-4,2,-7,-2,1],[3,6,-5,-3,1],[6,10,-9,-2,2],[7,8,-12,-10,2],[4,11,-18,-12,3]],
  spawn:[0,0,20],terminals:[[-12,0,-24],[32,0,-28],[32,0,-64]],exit:[32,0,-70],
  centers:[[-4,0,-18],[32,0,-20],[30,0,-56]],
  covers:[[-8,-12,2,2],[4,-24,1.6,2.4],[28,-16,1.8,2.7],[36,-32,1.8,1.7],[24,-52,2,2.5],[40,-60,2,2]],
  doors:[[0,4,5.5,.65],[14,-16,.65,5.5],[30,-42,3.5,.65]]},
 {name:'Машинный зал исполнителя',short:'МАШИННЫЙ ЗАЛ',theme:'reactor',accent:'#f5b46e',warm:'#65dfd1',
  zones:['Грузовой док','Производственный блок','Реакторный переход','Зал испытаний'],
  rects:[[-2,2,2,6,0],[-1,1,-2,1,0],[-5,2,-7,-2,1],[-4,-3,-11,-8,1],[-7,-1,-16,-10,2],[0,4,-15,-13,2],[4,10,-20,-10,3]],
  spawn:[0,0,20],terminals:[[-12,0,-24],[-20,0,-52],[28,0,-68]],exit:[32,0,-74],
  centers:[[-4,0,-18],[-16,0,-48],[26,0,-56]],
  covers:[[-8,-12,2,2],[4,-24,1.8,2],[-20,-44,2,2.5],[-8,-56,1.7,2],[24,-48,2.2,2],[32,-60,2,2.8]],
  doors:[[0,4,5.5,.65],[-14,-34,3.5,.65],[8,-56,.65,5.5]]},
 {name:'Узел полномочий и интеграций',short:'УЗЕЛ ПОЛНОМОЧИЙ',theme:'security',accent:'#bd9df7',warm:'#66e6de',
  zones:['Контрольный док','Зал полномочий','Кольцевой переход','Узел интеграций'],
  rects:[[-2,2,2,6,0],[-1,1,-3,1,0],[-4,4,-9,-3,1],[-4,-3,-14,-10,1],[3,4,-14,-10,1],[-5,5,-19,-14,2],[-1,1,-23,-20,2],[-4,4,-29,-23,3]],
  spawn:[0,0,20],terminals:[[0,0,-28],[-12,0,-64],[8,0,-104]],exit:[0,0,-112],
  centers:[[0,0,-20],[0,0,-64],[0,0,-98]],
  covers:[[-8,-20,1.7,2],[8,-32,2,1.8],[-8,-60,1.8,2],[12,-68,1.8,2],[-8,-100,1.8,2],[8,-96,1.8,1.8]],
  doors:[[0,4,5.5,.65],[-14,-42,3.5,.65],[14,-42,3.5,.65],[0,-84,5.5,.65]]},
 {name:'Командный мостик согласования',short:'КОМАНДНЫЙ МОСТИК',theme:'bridge',accent:'#efce87',warm:'#79bffc',
  zones:['Парадный док','Зал приоритетов','Обсерватория решений','Совет согласования'],
  rects:[[-3,3,2,6,0],[-1,1,-2,1,0],[-4,4,-7,-2,1],[-8,-5,-6,-4,1],[-12,-8,-12,-2,2],[-11,-9,-17,-13,2],[-15,-5,-25,-17,3]],
  spawn:[0,0,20],terminals:[[12,0,-20],[-40,0,-36],[-40,0,-88]],exit:[-40,0,-96],
  centers:[[0,0,-18],[-40,0,-24],[-40,0,-80]],
  covers:[[-8,-12,2,2],[4,-24,1.8,2.4],[-44,-20,1.8,2.5],[-36,-32,1.8,2],[-48,-80,2.5,2],[-32,-84,2.5,2]],
  doors:[[0,4,5.5,.65],[-22,-20,.65,5.5],[-40,-58,5.5,.65]]}
];
const CITADEL_DRONES={
 scout:{name:'Обходчик',hp:70,speed:4.4,range:8,cool:1.7,damage:5,color:'#ff9b9e'},
 shield:{name:'Блокер',hp:150,speed:2.2,range:9,cool:2.7,damage:6,color:'#efbc75'},
 sniper:{name:'Снайпер',hp:60,speed:3,range:18,cool:3.4,damage:13,color:'#e68ff1'},
 relay:{name:'Ретранслятор',hp:60,speed:3.5,range:15,cool:2.5,damage:4,color:'#70e4c9'},
 hunter:{name:'Преследователь',hp:85,speed:5.5,range:4.8,cool:1.15,damage:5,color:'#f28e65'}
};
const stationSmooth=t=>{t=arcadeClamp(t,0,1);return t*t*(3-2*t)};
function stationCellKey(x,z){return x+','+z}
function stationMakeDeck(stage){
 const d=CITADEL_DECKS[stage],cells=new Map();for(const [x0,x1,z0,z1,zone]of d.rects)for(let x=x0;x<=x1;x++)for(let z=z0;z<=z1;z++)cells.set(stationCellKey(x,z),{x,z,zone});
 const b={definition:d,cells,crates:d.covers.map(([x,z,w,h])=>({x,z,w,h})),props:[],doors:d.doors.map(([x,z,w,h])=>({x,z,w,h,open:0,latched:false})),bounds:{minX:Math.min(...Array.from(cells.values(),c=>c.x))*4-2,maxX:Math.max(...Array.from(cells.values(),c=>c.x))*4+2,minZ:Math.min(...Array.from(cells.values(),c=>c.z))*4-2,maxZ:Math.max(...Array.from(cells.values(),c=>c.z))*4+2}};
 const prop=(x,z,w,h,kind,side)=>{if(!stationFloor(b,[x,0,z])||d.terminals.some(p=>Math.abs(p[0]-x)<w+4&&Math.abs(p[2]-z)<h+4)||b.crates.some(c=>Math.abs(c.x-x)<c.w+w+1&&Math.abs(c.z-z)<c.h+h+1))return;const c={x,z,w,h,kind,side};b.props.push(c);b.crates.push(c)};
 for(let i=0;i<3;i++){const p=d.centers[i];if(d.theme==='archive'||d.theme==='security')for(const side of [-1,1])for(let k=0;k<3;k++)prop(p[0]+side*(7+i%2),p[2]-7+k*4,.6,1.25,'rack',side);if(d.theme==='bridge')for(const side of [-1,1])prop(p[0]+side*6,p[2]-1,1.4,3,'console',side)}
 return b;
}
function stationFloor(b,pos){return b.cells.has(stationCellKey(Math.floor((pos[0]+2)/4),Math.floor((pos[2]+2)/4)))}
function stationWalkable(b,pos,r=.7,ignoreDoors=false){for(const [dx,dz]of [[0,0],[r,0],[-r,0],[0,r],[0,-r],[r*.707,r*.707],[-r*.707,r*.707],[r*.707,-r*.707],[-r*.707,-r*.707]])if(!stationFloor(b,[pos[0]+dx,0,pos[2]+dz]))return false;for(const c of b.crates)if(Math.abs(pos[0]-c.x)<c.w+r&&Math.abs(pos[2]-c.z)<c.h+r)return false;if(!ignoreDoors)for(const c of b.doors)if(c.open<.82&&Math.abs(pos[0]-c.x)<c.w+r&&Math.abs(pos[2]-c.z)<c.h+r)return false;return true}
function stationLine(b,a,c,pad=.08,ignoreDoors=false){const dist=V3.len(V3.sub(c,a)),steps=Math.max(1,Math.ceil(dist/.55));for(let i=0;i<=steps;i++)if(!stationWalkable(b,V3.lerp(a,c,i/steps),pad,ignoreDoors))return false;return true}
function stationBuildNav(b){
 const nodes=new Map(),extras=[];
 const add=(key,pos)=>{const n={key,x:pos[0]/2,z:pos[2]/2,pos,links:[]};nodes.set(key,n);return n};
 for(let x=Math.ceil(b.bounds.minX/2);x<=b.bounds.maxX/2;x++)for(let z=Math.ceil(b.bounds.minZ/2);z<=b.bounds.maxZ/2;z++){
  const pos=[x*2,0,z*2];if(stationWalkable(b,pos,.7,true))add(stationCellKey(x,z),pos);
 }
 const link=(a,c)=>{const cost=V3.len(V3.sub(a.pos,c.pos))/2;a.links.push({key:c.key,cost});c.links.push({key:a.key,cost})};
 for(const n of nodes.values())for(const [dx,dz]of [[1,0],[0,1],[1,1],[1,-1]]){const next=nodes.get(stationCellKey(n.x+dx,n.z+dz));if(next&&stationLine(b,n.pos,next.pos,.68,true))link(n,next)}
 // A 2 m grid misses valid narrow gaps beside shelves. Add clearance points at
 // obstacle corners and connect them by visible, physically traversable segments.
 for(const [i,c]of b.crates.entries())for(const sx of [-1,1])for(const sz of [-1,1]){
  const pos=[c.x+sx*(c.w+.68),0,c.z+sz*(c.h+.68)];
  if(stationWalkable(b,pos,.65,true))extras.push(add('corner:'+i+':'+sx+':'+sz,pos));
 }
 for(const n of extras)for(const other of nodes.values()){
  if(n===other||other.key.startsWith('corner:')&&other.key<n.key)continue;
  if(V3.len(V3.sub(n.pos,other.pos))<=10&&stationLine(b,n.pos,other.pos,.65,true))link(n,other);
 }
 b.nav=nodes;b.navExtras=extras.map(n=>n.key);
}
function stationNearestNode(b,pos){
 let nearest=null,best=Infinity;const x=Math.round(pos[0]/2),z=Math.round(pos[2]/2),candidates=[];
 for(let dx=-3;dx<=3;dx++)for(let dz=-3;dz<=3;dz++){const n=b.nav.get(stationCellKey(x+dx,z+dz));if(n)candidates.push(n)}
 for(const key of b.navExtras||[]){const n=b.nav.get(key);if(n&&V3.len(V3.sub(pos,n.pos))<8)candidates.push(n)}
 for(const n of candidates){const score=V3.len(V3.sub(pos,n.pos));if(score<best&&stationLine(b,pos,n.pos,.65,true)){best=score;nearest=n}}
 return nearest;
}
function stationPath(b,from,goal){
 if(stationLine(b,from,goal,.68,true))return [goal.slice()];
 const start=stationNearestNode(b,from),end=stationNearestNode(b,goal);if(!start||!end)return [];
 const heap=[],closed=new Set(),came=new Map(),g=new Map([[start.key,0]]);
 const push=v=>{heap.push(v);let i=heap.length-1;while(i){const p=(i-1)>>1;if(heap[p].f<=v.f)break;heap[i]=heap[p];i=p}heap[i]=v};
 const pop=()=>{const first=heap[0],last=heap.pop();if(heap.length){let i=0;while(i*2+1<heap.length){let child=i*2+1;if(child+1<heap.length&&heap[child+1].f<heap[child].f)child++;if(heap[child].f>=last.f)break;heap[i]=heap[child];i=child}heap[i]=last}return first};
 push({key:start.key,f:0});let found=false;
 while(heap.length){const {key}=pop();if(closed.has(key))continue;if(key===end.key){found=true;break}closed.add(key);const n=b.nav.get(key);
  for(const link of n.links){if(closed.has(link.key))continue;const score=g.get(key)+link.cost;if(score<(g.get(link.key)??Infinity)){came.set(link.key,key);g.set(link.key,score);const q=b.nav.get(link.key);push({key:link.key,f:score+Math.hypot(q.x-end.x,q.z-end.z)})}}
 }
 if(!found)return [];const points=[end.pos];let key=end.key;
 while(came.has(key)){key=came.get(key);points.push(b.nav.get(key).pos)}points.reverse();
 // Keep nearby corner points: skipping them can cut through a shelf.
 while(points.length&&V3.len(V3.sub(points[0],from))<.05)points.shift();
 if(stationLine(b,end.pos,goal,.65,true))points.push(goal.slice());return points;
}
function stationGuideControl(e,dt,speed){
 const b=e.board,target=b.completed.length<3?b.terminals[b.completed.length]:b.exit,key=b.completed.length;
 let w=b.guideWatch;
 if(!w||w.key!==key)w=b.guideWatch={key,pos:b.pos.slice(),stalled:0,repath:0};
 const moved=V3.len(V3.sub(b.pos,w.pos));w.pos=b.pos.slice();w.stalled=moved<.002?w.stalled+dt:0;w.repath=Math.max(0,w.repath-dt);
 if(w.stalled>1){b.guideRoute=null;w.stalled=0;w.repath=0}
 if((!b.guideRoute?.length||b.guideGoal!==key)&&w.repath<=0){b.guideRoute=stationPath(b,b.pos,target);b.guideGoal=key;w.repath=.35}
 const route=b.guideRoute||[];
 while(route.length){const dist=V3.len(V3.sub(route[0],b.pos));if(dist<.08||dist<.55&&route.length>1&&stationLine(b,b.pos,route[1],.68,true))route.shift();else break}
 if(!route.length)return [0,0];
 const delta=V3.sub(route[0],b.pos),dist=V3.len(delta),scale=1/Math.max(dist,dt*speed,.001);
 return [delta[0]*scale,delta[2]*scale];
}
class CitadelStationBase extends RequirementCampaignBase{
 beginStage(n){this.dock=null;super.beginStage(n)}
 dockPoint(){return V3.add(this.station.pos,[0,1,-118])}
 interact(){if(this.status==='boarding')return this.boardInteract();const ok=super.interact();if(ok&&this.status==='docking'){this.dock={start:this.player.pos.slice(),duration:ARCADE.fx?11.8:3.8,gateSound:false,landingSound:false};this.phaseClock=0;this.hostile=[];this.say('Цитадель ЦСИИ, борт «Аналитик-01». Захожу в док. Готовьте '+CITADEL_DECKS[this.stage].short.toLowerCase()+'.','order',true);this.emit('dock')}return ok}
 dockProgress(){return arcadeClamp(this.phaseClock/(this.dock?.duration||11.8),0,1)}
 dockShip(t){const st=this.station.pos,points=[this.dock.start,V3.add(st,[0,1,-88]),V3.add(st,[0,1,-43]),V3.add(st,[0,.4,-10]),V3.add(st,[0,-2,20])],times=[0,.23,.47,.76,1];let i=0;while(i<3&&t>times[i+1])i++;return V3.lerp(points[i],points[i+1],stationSmooth((t-times[i])/(times[i+1]-times[i])))}
 step(delta,input={}){const dt=arcadeClamp(Number.isFinite(delta)?delta:0,0,.04);if(this.status==='docking'&&this.dock){this.elapsed+=dt;this.stageTime+=dt;this.phaseClock+=dt;const t=this.dockProgress(),a=this.dockShip(t),b=this.dockShip(Math.min(1,t+.003)),dir=V3.sub(b,a);this.player.pos=a;this.player.yaw=Math.atan2(dir[0],-dir[2]);this.player.pitch=Math.atan2(dir[1],Math.hypot(dir[0],dir[2]));this.player.bank=Math.sin(t*Math.PI*2)*.08;this.player.boosting=false;this.player.speed=V3.len(dir)*20;if(t>.2&&!this.dock.gateSound){this.dock.gateSound=true;this.emit('gate')}if(t>.82&&!this.dock.landingSound){this.dock.landingSound=true;this.emit('terminal')}if(t>=1)this.beginBoarding();return}if(this.status==='boarding'){this.captainClock=Math.max(0,this.captainClock-dt);this.flash=Math.max(0,this.flash-dt);this.stepBoard(dt,input);return}super.step(delta,input)}
 beginBoarding(){const deck=stationMakeDeck(this.stage),d=deck.definition;this.dock=null;this.status='boarding';this.phase='boarding';this.autopilot=false;this.player.hp=Math.max(80,this.player.hp);this.board={...deck,pos:d.spawn.slice(),previous:d.spawn.slice(),camera:d.spawn.slice(),yaw:Math.PI,hp:100,energy:100,cooldown:0,pulseCooldown:0,pulseWave:0,invulnerable:1.8,time:0,kills:0,enemies:[],bullets:[],hostile:[],sparks:[],terminal:0,completed:[],question:null,answered:false,returning:false,guide:false,guideRoute:null,terminals:d.terminals.map(p=>p.slice()),exit:d.exit.slice(),intro:1.5,zone:0,lastZone:0,zoneBanner:4,terminalGrace:0};stationBuildNav(this.board);this.spawnBoardWave(5+this.stage);this.say(d.name+'. Золотая линия ведёт к терминалу. G — проводник, пробел — перехват, E — импульс. Разбор начнётся при подходе.','order',true);this.emit('state','boarding')}
 boardClear(pos,r=.65){return stationWalkable(this.board,pos,r)}
 boardLOS(a,b,pad=.12){return stationLine(this.board,a,b,pad)}
 boardRoute(from,goal){return stationPath(this.board,from,goal)[0]||from.slice()}
 spawnBoardWave(count){const b=this.board,zone=b.completed.length;if(zone>=3)return;const center=b.definition.centers[zone],roles=this.stage===0?['scout','shield','sniper','scout']:this.stage===1?['shield','scout','relay','sniper','hunter']:['scout','sniper','shield','relay','hunter','scout'];for(let i=0;i<count;i++){const archetype=roles[i%roles.length],info=CITADEL_DRONES[archetype],angle=i/count*Math.PI*2,candidate=V3.add(center,[Math.sin(angle)*6,0,Math.cos(angle)*6]);let node=stationNearestNode(b,candidate)||stationNearestNode(b,center);if(!node)node=Array.from(b.nav.values()).find(n=>V3.len(V3.sub(n.pos,center))<12);if(!node)continue;b.enemies.push({...info,archetype,id:++this.entityId,pos:node.pos.slice(),maxHp:info.hp,shot:.65+this.random()*.8,hit:0,phase:this.random()*6.28,dead:false,zone,alert:false,lastSeen:null,route:[],repath:0,stun:0,charge:0,aim:null,yaw:0,heal:0,signal:'Патруль',strafe:i%2?1:-1})}b.returning=false;b.guideRoute=null}
 boardInteract(){const b=this.board;if(this.status!=='boarding'||!b)return false;if(b.completed.length===3){if(V3.len(V3.sub(b.pos,b.exit))<3.2){this.finishBoarding();return true}return false}const i=b.completed.length,point=b.terminals[i];if(V3.len(V3.sub(b.pos,point))>2.9||!stationLine(b,b.pos,point,.15))return false;b.question=this.stage*3+i;b.answered=false;this.remarkFeedback=null;this.status='remark';this.emit('terminal');this.emit('state','remark');return true}
 continueRemark(){if(this.status!=='remark'||!this.board.answered)return;const b=this.board;if(!this.remarkFeedback.correct){b.answered=false;this.remarkFeedback=null;this.emit('state','remark');return}this.status='boarding';b.enemies=[];b.hostile=[];b.bullets=[];b.hp=Math.min(100,b.hp+22);b.energy=100;b.invulnerable=2;b.guideRoute=null;b.guideWatch=null;b.terminalGrace=.45;if(b.completed.length<3){this.spawnBoardWave(5+this.stage);this.say(b.guide?'Решение занесено в реестр. Проводник ведёт к следующему терминалу.':'Решение занесено в реестр. Следующий терминал — дальше по коридору. WASD — движение; G — включить проводник.','success',true)}else{b.returning=true;this.say(b.guide?'Три замечания отработаны. Проводник ведёт к зелёному выходу.':'Три замечания отработаны. Пройди к зелёному шлюзу. G — включить проводник; у выхода переход начнётся сам.','success',true)}this.remarkFeedback=null;this.emit('state','boarding')}
 finishBoarding(){if(this.board.completed.length!==3||this.decisions.filter(x=>x.stage===this.stage).length!==2)return false;this.board.enemies=[];this.board.hostile=[];return super.finishBoarding()}
 boardPulse(){const b=this.board;if(b.pulseCooldown>0)return false;b.pulseCooldown=9;b.pulseWave=1;for(const e of b.enemies)if(V3.len(V3.sub(e.pos,b.pos))<11){e.stun=3;e.charge=0;e.aim=null;this.boardHit(e,42,b.pos,true)}b.hostile=b.hostile.filter(s=>V3.len(V3.sub(s.pos,b.pos))>12);b.invulnerable=Math.max(b.invulnerable,.7);this.emit('pulse');this.notify('ИМПУЛЬС','Щиты и заряды противников сбиты');return true}
 boardHit(e,amount,source,ignoreShield=false){if(e.dead)return;const front=[Math.sin(e.yaw),0,Math.cos(e.yaw)],toward=V3.norm(V3.sub(source,e.pos)),shield=e.archetype==='shield'&&!e.stun&&!ignoreShield&&V3.dot(front,toward)>.25;e.hp-=amount*(shield?.32:1);e.hit=.17;e.alert=true;e.lastSeen=this.board.pos.slice();this.board.sparks.push({pos:e.pos.slice(),life:.35,max:.35,color:shield?'#ffe2a1':e.color});if(e.hp<=0){e.dead=true;this.board.kills++;this.score+=e.archetype==='shield'?160:110;this.emit('destroy','board');this.notify('ПОТОК ПЕРЕХВАЧЕН',e.name+' · путь к терминалу свободнее')}}
 boardMoveToward(e,goal,dt,speed){const b=this.board;e.repath-=dt;if(!e.route.length||e.repath<=0||!e.routeGoal||V3.len(V3.sub(e.routeGoal,goal))>4){e.route=stationPath(b,e.pos,goal);e.routeGoal=goal.slice();e.repath=.7+(e.id%5)*.1}while(e.route.length&&V3.len(V3.sub(e.route[0],e.pos))<.6)e.route.shift();if(!e.route.length)return;const dir=V3.norm(V3.sub(e.route[0],e.pos));this.boardMove(e,V3.scale(dir,dt*speed),.68)}
 enemyBoardStep(e,dt){const b=this.board;e.hit=Math.max(0,e.hit-dt);e.stun=Math.max(0,e.stun-dt);e.heal=0;if(e.dead)return;const delta=V3.sub(b.pos,e.pos),dist=V3.len(delta),sees=dist<32&&this.boardLOS(e.pos,b.pos);if(sees||dist<23&&b.firing){e.alert=true;e.lastSeen=b.pos.slice();e.memory=5}e.memory=Math.max(0,(e.memory||0)-dt);if(e.stun){e.signal='Щит отключён';return}if(!e.alert){e.signal='Патруль';return}if(!e.memory&&!sees){e.signal='Поиск';if(e.lastSeen)this.boardMoveToward(e,e.lastSeen,dt,e.speed*.65);return}const dir=V3.norm(delta),side=[-dir[2],0,dir[0]];e.yaw=Math.atan2(delta[0],delta[2]);let goal=b.pos.slice(),move=true;e.shot-=dt;
  if(e.archetype==='relay'){const ally=b.enemies.filter(a=>a!==e&&!a.dead&&a.hp<a.maxHp&&V3.len(V3.sub(a.pos,e.pos))<13&&this.boardLOS(a.pos,e.pos)).sort((a,c)=>a.hp/a.maxHp-c.hp/c.maxHp)[0];if(ally){ally.hp=Math.min(ally.maxHp,ally.hp+dt*7);e.heal=ally.id;e.signal='Восстанавливает щит'}else e.signal='Поддержка';goal=V3.sub(b.pos,V3.scale(dir,16));if(dist>=12&&dist<22)move=false;
  }else if(e.archetype==='sniper'){e.signal=e.charge?'Заряжает выстрел':'Держит дистанцию';goal=V3.sub(b.pos,V3.scale(dir,18));if(dist>13&&dist<25&&sees)move=false;if(e.charge){e.charge-=dt;move=false;if(e.charge<=0&&e.aim){const velocity=V3.scale(V3.norm(V3.sub(e.aim,e.pos)),34);b.hostile.push({pos:e.pos.slice(),vel:velocity,life:2.1,damage:this.assist?7:13,color:e.color,r:.3});e.aim=null;e.shot=e.cool}}else if(sees&&e.shot<=0){e.charge=1.05;e.aim=V3.add(b.pos,V3.scale(b.velocity||[0,0,0],.15));}
  }else if(e.archetype==='scout'){e.signal='Заходит с фланга';goal=V3.add(V3.sub(b.pos,V3.scale(dir,7)),V3.scale(side,e.strafe*6));if(!stationWalkable(b,goal,.8,true))goal=b.pos.slice();if(dist<5)goal=V3.sub(b.pos,V3.scale(dir,8));
  }else if(e.archetype==='shield'){e.signal='Фронтальный щит';move=dist>7||!sees;
  }else{e.signal='Сокращает дистанцию';goal=V3.add(b.pos,V3.scale(side,e.strafe*3));if(!stationWalkable(b,goal,.8,true))goal=b.pos.slice();move=dist>4||!sees}
  if(move&&!e.charge)this.boardMoveToward(e,goal,dt,e.speed*(this.assist?.85:1));if(e.archetype!=='sniper'&&sees&&dist<25&&e.shot<=0){e.shot=e.cool*(this.assist?1.35:1);const lead=V3.add(b.pos,V3.scale(b.velocity||[0,0,0],Math.min(.85,dist/18)*.8)),aim=V3.norm(V3.sub(lead,e.pos));b.hostile.push({pos:e.pos.slice(),vel:V3.scale(aim,e.archetype==='shield'?15:18),life:2.2,damage:this.assist?e.damage*.65:e.damage,color:e.color,r:.2});if(e.archetype==='shield')for(const side of [-1,1])b.hostile.push({pos:e.pos.slice(),vel:V3.scale(V3.norm(V3.add(aim,[side*.12,0,0])),15),life:2.2,damage:this.assist?3:5,color:e.color,r:.2})}
 }
 stepBoard(dt,input){const b=this.board;b.time+=dt;this.elapsed+=dt;this.stageTime+=dt;b.intro=Math.max(0,b.intro-dt);b.zoneBanner=Math.max(0,b.zoneBanner-dt);b.terminalGrace=Math.max(0,b.terminalGrace-dt);b.cooldown=Math.max(0,b.cooldown-dt);b.pulseCooldown=Math.max(0,b.pulseCooldown-dt);b.pulseWave=Math.max(0,b.pulseWave-dt*1.5);b.invulnerable=Math.max(0,b.invulnerable-dt);b.firing=!!input.fire;
  for(const door of b.doors){if(V3.len(V3.sub(b.pos,[door.x,0,door.z]))<10||b.enemies.some(e=>e.alert&&V3.len(V3.sub(e.pos,[door.x,0,door.z]))<7))door.latched=true;door.open=arcadeClamp(door.open+(door.latched?dt*1.5:0),0,1)}
  let dx=input.moveX||0,dz=input.moveZ||0;const sprint=input.boost&&b.energy>4,speed=sprint?10.5:6.5;if(b.guide)[dx,dz]=stationGuideControl(this,dt,speed);else b.guideWatch=null;
  b.previous=b.pos.slice();const len=Math.max(1,Math.hypot(dx,dz));this.boardMove(b,[dx/len*dt*speed,0,dz/len*dt*speed]);b.velocity=dt?V3.scale(V3.sub(b.pos,b.previous),1/dt):[0,0,0];b.energy=arcadeClamp(b.energy+(sprint?-30:18)*dt,0,100);b.camera=V3.lerp(b.camera,b.pos,Math.min(1,dt*4));
  const cell=b.cells.get(stationCellKey(Math.floor((b.pos[0]+2)/4),Math.floor((b.pos[2]+2)/4)));b.zone=cell?.zone||0;if(b.zone!==b.lastZone){b.lastZone=b.zone;b.zoneBanner=3;this.say(b.definition.zones[b.zone]+'. Терминал запускается сам при подходе.','order')}
  const enemy=b.enemies.filter(e=>!e.dead&&V3.len(V3.sub(e.pos,b.pos))<25&&this.boardLOS(b.pos,e.pos)).sort((a,c)=>V3.len(V3.sub(a.pos,b.pos))-V3.len(V3.sub(c.pos,b.pos)))[0];if(input.aim){const d=V3.sub(input.aim,b.pos);b.yaw=Math.atan2(d[0],d[2])}else if(enemy){const d=V3.sub(enemy.pos,b.pos);b.yaw=Math.atan2(d[0],d[2])}else if(dx||dz)b.yaw=Math.atan2(dx,dz);
  if(input.pulse)this.boardPulse();if(input.fire&&b.cooldown<=0){b.cooldown=.15*Math.pow(.9,this.upgrades.weapons);const aim=input.aim?V3.norm(V3.sub(input.aim,b.pos)):enemy?V3.norm(V3.sub(enemy.pos,b.pos)):[Math.sin(b.yaw),0,Math.cos(b.yaw)];b.bullets.push({pos:V3.add(b.pos,V3.scale(aim,1)),vel:V3.scale(aim,54),life:1.1,damage:23*(1+.25*this.upgrades.weapons),origin:b.pos.slice()});this.emit('shot')}
  for(const e of b.enemies)this.enemyBoardStep(e,dt);
  for(const shot of b.bullets){const old=shot.pos;shot.pos=V3.add(old,V3.scale(shot.vel,dt));shot.life-=dt;if(!this.boardLOS(old,shot.pos,.05))shot.life=0;else for(const e of b.enemies)if(!e.dead&&flightSegment(old,shot.pos,e.pos,e.archetype==='shield'?1.25:.9)!==null){shot.life=0;this.boardHit(e,shot.damage,shot.origin);break}}
  for(const shot of b.hostile){const old=shot.pos;shot.pos=V3.add(old,V3.scale(shot.vel,dt));shot.life-=dt;if(!this.boardLOS(old,shot.pos,.05))shot.life=0;else if(flightSegment(old,shot.pos,b.pos,.75)!==null){shot.life=0;if(!b.invulnerable){b.hp=Math.max(0,b.hp-shot.damage*Math.pow(.8,this.upgrades.armor));b.invulnerable=.45;this.flash=.15;this.emit('damage')}}}
  b.enemies=b.enemies.filter(e=>!e.dead);b.bullets=b.bullets.filter(s=>s.life>0);b.hostile=b.hostile.filter(s=>s.life>0);for(const s of b.sparks)s.life-=dt;b.sparks=b.sparks.filter(s=>s.life>0).slice(-30);if(b.hp<=0){this.lossReason='Поток замечаний остановил продвижение. Используйте укрытия, E для отключения щитов и Shift для рывка.';this.status='lost';this.emit('state','lost');return}if(!b.terminalGrace)this.boardInteract();
 }
 objective(){if(this.status==='docking')return {title:'Цитадель ЦСИИ · заход в док',detail:'Автоматический пролёт через шлюз. Затем — '+CITADEL_DECKS[this.stage].name.toLowerCase()+'.',progress:Math.round(this.dockProgress()*100)+'% · СТЫКОВКА'};if(this.board&&['boarding','remark'].includes(this.status)||this.status==='paused'&&this.resumeStatus==='boarding'){const b=this.board,n=b.completed.length;return n<3?{title:'Доберитесь до терминала '+(n+1),detail:b.definition.zones[b.zone]+' · разбор начнётся автоматически. Пробел — перехват, E — импульс, G — проводник.',progress:n+' / 3 РАЗБОРОВ'}:{title:'Пройдите к зелёному выходу',detail:'Замечания отработаны. G включает проводник к шлюзу следующей редакции.',progress:'3 / 3 РАЗБОРОВ'}}return super.objective()}
}
